<template>
	<view  v-if="discount" class="discount-box">
		<view class="discount-title">
			<text class="title-img" ></text>
			<uni-count-down 
					class="discount-time"
					:day="day"
					:hour="hourse"
					:minute="minute"
					:second="second"
					 background-color="#565656"
					 color="#fff"
			></uni-count-down>
			<text class="iconfont iconright"  @click="entryDiscountList()" >查看更多</text>
		</view>
		<view class="discount-goods">
			<scroll-view class="scroll-view_H" scroll-x="true" scroll-y="false" @scroll="scroll" scroll-left="0">
				<block v-for="(item, index) in discount.goods_list" :key="index">
					<view  class="scroll-view-item_H" @click="entryDiscountGoodsDetail(item.goods_id)">
						<view class="img-box">
							<image class="goods-img" :src="$util.img(item.pic_cover_small)"  mode="aspectFit"></image>
						</view>							
						<text class="goods-name">{{ item.goods_name }}</text>					
						<view class="goods-price">
							<text class="discount-price">￥{{ item.promotion_price }}</text>
							<text class="discount-price">￥{{ item.price }}</text>
						</view>
					</view>							
				</block>								
			</scroll-view>
		</view>
	</view>
</template>
<script>
import http from 'common/js/http.js';
import uniCountdown from '@/components/uni-count-down/uni-count-down.vue';
export default{
	name: 'diy-discount',
	components: {
		uniCountdown
	},
	mixins: [http],
	props: {
		value: {
		}
	},
	data(){
		return {
			scrollTop: 0,
			old: {
				scrollTop: 0
			},
			discount : [],
			day: 0,
			hourse: 0,
			minute: 0,
			second: 0,
			currentTime: 0
		}
	},
	
	async onLoad() {
		await this.getCurrentTime();
	},
	
	created() {
		this.getDiscountList();
	},
	methods:{
		scroll: function(e) {
			this.old.scrollTop = e.detail.scrollTop
		},
		
		async getCurrentTime() {
			let res = await this.sendRequest({
				url: 'System.Goods.getCurrentTime',
				async: false
			});
			this.currentTime = res.data / 1000;
		},
		
		getDiscountList (){
			 this.sendRequest({
			 	url: 'System.Goods.newestDiscount',
			 	data: {},
			 	success: res => {
			 		//101
			 		let data = res.data;
			 		if (data != null) {
			 			this.discount = data;	
						this.day = Math.floor((this.discount.end_time - 1586834232) / 24 / 60 / 60);
						this.hourse = Math.floor(((this.discount.end_time - 1586834232) % (24 * 60 * 60)) / (60 * 60));
						this.minute = Math.floor((((this.discount.end_time - 1586834232) % (24 * 60 * 60)) % (60 * 60)) / 60);
						this.second = (((this.discount.end_time - 1586834232) % (24 * 60 * 60)) % (60 * 60)) % 60;
			 		} 
			 	}
			 });
		},
		
		entryDiscountList (){
			this.$util.redirectTo('/pages/goods/discount/discount');
		},
		
		entryDiscountGoodsDetail (goodsId){
			this.$util.redirectTo('/pages/goods/detail/detail', { goods_id: goodsId });
		}
	}
}
</script>

<style lang="scss">
.discount-box{
	background: #FFFFFF;
	overflow:hidden;
	position: relative;
	.discount-title{
		line-height: 1;
		padding: 20rpx;
		position: relative;
		.discount-time{
			position: absolute;
			top: 17rpx;
			.uni-countdown__number{
				height:35rpx;
				line-height: 36rpx;
				padding:0rpx 5rpx;
			}
		}		
		.title-img{
			width: 160rpx;
			height: 35rpx;
			display: inline-block;
			margin-right: 20rpx;
			background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAARIAAAA3CAYAAADAIcUSAAAMkklEQVR4nO2dQXLbuBKGf7qyH90gyAlGc4JgTpBkr1dWTmB7pbeLvBuv7DlBlBrv45wg8AnGOUHwTjCaC4hvASKkZRJoAA2QivVVqRKZIBqkyOaPRgOscKSPGYDt2I1gRjQfF1sAD9lbkpcZgLmnDPdxzhu7oUzlfCe3/wWAJYBTvjaRuQBwDUCOYLuPqvP/cwAfRrKdiyX8x6QA/J69JY+RPW1IYQ7gq6eMAu9xagAfAbyN2PcO5l7QjO2hMkf8PbiBaTcA40hEZEWpTMETHwlnvff9tae8DKx/yKnai36I94i/GZdwP0x9TmcL4B3MuQl9AL1tPjcALlFGCQuYdi4j97+Aae8j1gDqwp/Pje2vI9ge+ox5TkqwJrTD9yQHoY5c52JJ3E9GHOe5p3yI7J8D+B557P80bcnJurET076/MdBtPMnc6CHuR7J75HARGev2qWNfzGW/rt9gpH8oMxjV9R38vYS3Tb0fEBcPuYFRZr3n6kV8u5K4G8nuISAz1fuSUGa2Z/8BhxF0nlo3eQvT1foCEzsJvXEFjGpSMN2IlOOTMM5DRu6vYY5F+QquUVbGf+/Y/lrYNlVSlz4nXcY+D92PxFNKnosurmvla6ecJNjolgfMje4qn9LdmMF05VPOyUeEKzKJ9PvrGkQnOIYiCVUjlww2T5FXGh8Zl1TV5Ns/pivQrfsdTNfiY2Rdy+azgbkftKOsRJoCAQJUiCXEkVziacTeMocJxFAIjY8M2QzhNXgdiQJ9+FCCFsR8DvTlTWgA/yPsKxzbvkW2p8sWwzf5Lwz138FcNx8Qr3CWaB3KJzy+0SXSHQjgvs8H4VIkpwFlFZPNI+Ow70A1Hj8hXd2Th579qYjI/ag8YPgmDAm2utjCxDw+IS2Hatl8FEwc5hTpbVRIGELnciSSWE7hMIJ3R4ZRYzegh6kFW31Yh7qEUREish6JdAWiEdiN6YNj+FeA7g2/MNg78vyQnu0cDyeXM+JSJPtsYIaKSyWidbEjS6/A8HDgcCQyoKxisHfkyD4cN+G/jm0pwVYfW5iYxCvwDCxQ7F029jZclXJ0bd4Qy2nESVBXn/tnJNdcl1P4U6If0Jk/gel0GYRnO0c7KSM3OVWDdSgbpKWvu7iESSxjPw4ORyKJ5RSDreeAylSvJJTZZrSfgihgg5LdqjLat8mAbxA3+Y/CGUxi4hcwJ4WmOhIJuuw7xkeO5GAqqikGAeM0XiOf8+gyQzviAxhn8gXGQeqUilMdCbVbA0zzSXckjNRupiTU8TueXiuvHeW5ZPq+zX0koYwPqzqs4xCJ9aViZx4DxiErmDwvhcDzyqFIKBzKnI0jh8eUrysB0yV6DXOv5Br94WDefGyyXNexPMCjWFIcicBx2PdIGYRjG0dWq0U7bL107GdXZRMAfkV7U+Yc7QHamJbMYGvfsdis5Hu0SYjKFk5xJCF9upTAzrOaa1PX/INUVVViAbasiEJ2tMOWqw2fUXZxMBvb2DTfZzD34xnyqR7bLZOdvyk0o4wpjsTVb+3SN78ihHXCvhbuuTZHpsMhB1tDeIBJrb/D027GFsapbGCu8yUKPzxLKJLj2iOB1P/57zlogeztye3VO2dddY26rsmqxKWISimbbhuqqpKe4tu98sE2OvveY1hZyJDzyITLeQyhYR6+axh1cooC8ZlYRxLSrTmuhhbOHdzrk/5gt1gtT26vNnmb8wNKN/ODY5uGuTFcaGpjGqYcbI2BbUgWxhFZxSZg7ts3yNANi3Uk1G4NMI1h39xBL1ZObq/0brHagJbd+AGMqc4u6rpe+8pUVeV0JJQ69hCujXVdc3ZttGtjVVXCVyYCOzpinUcuNExW6w0eD0NLMKiVEork48Df30faDmUJflknkT91/xI0RyJ2i5U8ub1SeZszGqKgLe3ZLghlXHRHPhTi0iIEaNfFBsNt3cIoHxt2sI7FDlUHjzjFOBKBsB9X9vxNg/6DpCwKZIflfEwuYBehSlTO9liqqrpG/zl9X9e1JtbR+5vWdR06z2hyv1uDRju37F+03RTNULcA7ZUX1iaFfcdi7QiY+/dl57voqyDGkXCk8oYEYCWDPR9TzXOhqhJZUJXM0fObUJ1Iw5P9HZTIagUA1HWtPMFUiX6HfQHz0PqZEi819nJFOtgH9I9jjVlGICQ+MoQv4FaSLXpe9jMFTm6vNOjxD8pTigPBUIdmqAOYzk1r4xxTaU9ubCLcD0UY6khs4ksKGtOSpBeY9gVATciTu8VK5mxIg2CoQzPZ48xqtWjHNld267Mm1JFIBptTyit5j0IjHrE0qoR6zkqpkixUVdUXexGFm6Ed28Te9zXKvyKEGjNMfRVFyGcd6kjuYN7N2vehXuxT6NZomFcEbMZtBpk/ieVKqZJchA7TT0nZPmu4Fn+mdnm6CTJUVHBr3Pbvka6KNOgO8SUSV7s6ub1Su8VKgaYIi43gdMhij5LVmsGsM7s1g72fAi5HsiSWi1EjuZYeTEGDPgdIgmfZvEvQLuSSIzixaKZ6phzbelaUfq/NlOIjB0WgKjlFBpVAUAhUKC/EAspmtVqUZ/sMRwf2BA5HIkBP+tIJdmagvaFMYRpp+TmgqpLlbrG6bAK1h4TwfM9OXdcKjuvnJ1iSIQscjmRJLJcaZN2inRvg4hRmqf0ua0L9d5h48C4iVlJqGgIXIqBs0m91dAi8cDiSkt2a9wC+e8oItNOogfZtZi624Fn3pARBqgT8k8z6yOWAi2W1DrFbrOw8lDcAUP31xw/nXFXVGuWvGwnaEHDf2rfZSH1Bll1ezocCzwWtQctCPUM7lEjJraAOr45OE0RVxOKl8kpcL5fqg8MJZHMku8VK7har9W6x+hvAPzAroC1xXBxrkFRFQlUjnLkjdv6JK+dgBrOexzfQfvxNaqMK8wlEVQLe7o1gqoeqYFz22LJad4uVQPtaCIkDW3ZiCqQ6kiWxHOdozRbGmfgW/lmC9tTaoIz8Z6NZyGhDKVv/9QenacFZmY+6rvdjXVzMdotVd5EfkcnOsyF1qUWK574Dvwy9gVFDvtEiSvsOplvzDOCYEPqAp7lHs91i1V3EZw7TXcmJgD+eZ1EYJ1/qK+hJdq/geOCmOBLqy7FyTdG/QNpaJcDeDMYj0bCfw4RRlS0AtVus5njcXSlNSHyqxMvDh+xKYlnnKGCsI5lhnG5NF9XUnTIbeQrzfh5xoMOSoydoTSzOIUC/PxTGy3uytiWh7BLG8ei+jbmXWszRrelyEdCWfTQOL8g6Nr9wVEJYQMjL3rCsxLTiHIegRrr2JbHsoCqJdSRjd2ssGuZExAxzHmMj4XCvfRtEM7PZOo6SbdEwT26KghU4DDWy3wZJKLvEgCqJXbOVogK2KPPEv8HjvJEh7mCWDniusKiJzIjulybOIdG+dLsUdgWwLwBUd6qBHQVzKKpDUiOWZFWSc83WUhP0tjBdnKHV6i1vwfNG+RBmiFBL3K/tbBYMWrJW+hjNVI+w/9ktVmuUXahJoVli4uT2KjZ4LJBfjciIfXwoJKqSGEdCTUKjdGso8RMJ/wnfoH2jmItrAL8RbPqYgzZiFLysfyhVVZ3D39WUOdsQuPDzVLDrrN6f3F5xPfRyqhEB8zueBe5HJUmVhDoSAVrf1C5v7+Mb/ArnM4zi0APb7crdlBNhn8wbQttc2EAfB6lDp2fgCzSWfCuiQtlhWY1WdagMM6MF+NWIAD0Xpc9GaHmFSFUS6kio3pDq4Tfwe/EZ3N0Wu+6qav5deuq7Rv7RpBBU7I5Nl0WwtcT/u40abA3Exjms48idL5RDjcR27WIVVrQqCXUk30A7CdQD0aDd/C66r6y8hD/j1q5rsk6wycUWaaNH1G4mBUVYKGjqc1Ae0AZIVUG7AnnUCLXOfWKvKYVIVRLqSDaB5SlcIC0PQKCNo2iYk+jz5Nb56EibXKRO8+caydgifnIfq7Krqko2iwtR0DAPLas6xlKZOdRIbCzkBmkDClGqhGupxRS2MMOyHxEvnc/Qnjw7D0d49rnGuMPBGyS8mIuxW7MF8HtCwLTkFIPBYdkREeBXIyGZ4102MA/mFBQiVMkUHAnQTrQ6By0nZJ+3aF/wbAOvUxwOBtqnf+pIAUe3RiHgnb3MPIB2sSq0jmOK86JyqJFzhN0D9pqPfjDtEaxKXoB+I1HLxWJXKVvDHIQM3F+g7SZsYJKYhGefN+g/Lj3w9xQ02ldhcEjwGeLbeA/gLmTx5Kqqhuzt1+FqU7fst4Gy9txsTm6v1rTWjcYM5hpThLKaWG4G4NeAOjmvKYuCuYcEoawAMPs/UIH0xCmNs9YAAAAASUVORK5CYII=) center no-repeat;
			background-size: 100% 100%;
		};	
		.iconfont{
			position: absolute;
			right: 20rpx;
			font-size: 24rpx;
			padding-right: 28rpx;
			color: #ff0036;
			line-height: 35rpx;
		};
		.iconfont:before {
		position: absolute;
		right: 0px;		
		}
	};
	.discount-goods{
		
		padding:0rpx 20rpx;
		.scroll-view_H{
			white-space: nowrap;
			width: 100%;
			.scroll-view-item_H{
				position: relative;
				width: 30vw;
				margin-right: 20rpx;
				display: inline-block;
				.img-box{
					border: 1rpx solid #ebebeb;
					line-height: 1;
					background-color: #f8f8f8;
					padding: 1rpx;
					.goods-img{
						width:100%;
						height:30vw;
						border-radius: 6px;
						overflow: hidden;
					}
				};
				.goods-name{
					display: block;
					font-weight: bold;
					display: -webkit-box;
					-webkit-box-orient: vertical;
					-webkit-line-clamp: 1;
					overflow: hidden;
					font-size:24rpx;
					margin-top: 8rpx;
				};
				.goods-price{					
					width: 100%;
					text:nth-child(1){
						color: #FF0036;
						display: block;
						font-size: 26rpx;
					}
					text:nth-child(2){
						color: #898989;
						display: block;
						font-size: 24rpx;
						text-decoration: line-through;
					}
				};
			}
		}
	}
}
</style>
