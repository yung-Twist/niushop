<template>
	<view class="content goods-detail">
		<view class="go-top iconfont icontop ns-border-color-gray ns-text-color-gray" v-show="goTop" @click="goTopClick()"></view>

		<view class="media-wrap" :class="goodsDetail.goods_video_address != '' ? 'have-video' : ''">
			<view class="goods-alter" v-if="goodsDetail.goods_video_address != ''">
				<text class="goods-alter-image" :class="{ 'ns-bg-color': switchMedia == 'img' }" @click="switchMedia = 'img'">图片</text>
				<text class="goods-alter-video" :class="{ 'ns-bg-color': switchMedia == 'video' }" @click="switchMedia = 'video'">视频</text>
			</view>

			<swiper class="swiper-box" :autoplay="false" v-show="switchMedia == 'img'">
				<swiper-item v-for="(item, index) in goodsDetail.img_list" :key="index">
					<view class="item" @click="preview(index)"><image :src="$util.img(item.pic_cover_big)" mode="aspectFit" /></view>
				</swiper-item>
			</swiper>

			<view class="video-wrap" v-if="goodsDetail.goods_video_address != ''" v-show="switchMedia == 'video'">
				<video :src="$util.img(goodsDetail.goods_video_address)"></video>
			</view>
		</view>

		<!-- 限时折扣 -->
		<view v-if="promotionCount > 0 && goodsDetail['promotion_detail']['discount_detail'] != null" class="product-discount">
			<view class="price-info">
				<view class="actprice">
					<text class="yen">¥</text>
					<template v-if="parseFloat(goodsDetail.promotion_price) < parseFloat(goodsDetail.member_price)">
						<text>{{ goodsDetail.promotion_price }}</text>
					</template>
					<template v-else>
						<text>{{ goodsDetail.member_price }}</text>
					</template>
				</view>
				<view class="origprice">
					<text v-if="parseFloat(showPrice) < parseFloat(goodsDetail['price'])" class="oprice">¥ {{ goodsDetail.price }}</text>
					<text class="actual_sale">
						{{ goodsDetail['sales'] }}
						<template v-if="goodsDetail.goods_unit != ''">
							{{ goodsDetail.goods_unit }}
						</template>
						<template v-else>
							件
						</template>
						已售
					</text>
				</view>
			</view>

			<view class="countdown">
				<view v-if="goodsDetail.promotion_detail.discount_detail.start_time > currentTime" class="txt">距开始仅剩</view>
				<view v-else class="txt">距结束仅剩</view>
				<view class="clockrun">
					<uni-count-down
						:day="discountTimeMachine.d"
						:hour="discountTimeMachine.h"
						:minute="discountTimeMachine.i"
						:second="discountTimeMachine.s"
						color="#fff"
						splitorColor="#000"
						background-color="#000"
					/>
				</view>
			</view>
		</view>

		<!-- 商品名称 -->
		<view class="product-name-wrap">
			<view class="product-name-block">
				<template v-if="goodsDetail.goods_group_list != null">
					<text v-for="(item, index) in goodsDetail.goods_group_list" :key="index" class="product-label ns-bg-color">{{ item.group_name }}</text>
				</template>
				<text class="product-name">{{ goodsDetail.goods_name }}</text>
				<view class="product-share" @click="openSharePopup()">
					<view class="iconfont iconshare"></view>
					<text>分享</text>
				</view>
				<view class="collection" @click="editCollection()">
					<view class="iconfont" :class="whetherCollection == 1 ? 'iconlikefill' : 'iconlike'"></view>
					<text>收藏</text>
				</view>
			</view>
		</view>

		<!-- 商品描述 -->
		<view class="product-introduction ns-text-color" v-if="goodsDetail.introduction != ''">{{ goodsDetail.introduction }}</view>

		<!-- 预售价 -->
		<view v-if="goodsDetail['is_open_presell'] == 1" class="product-price">
			<view class="real-price ns-text-color">
				<text class="price">
					定金¥{{ goodsDetail.presell_price }}
					<template v-if="goodsDetail.point_exchange_type == 1 && goodsDetail.point_exchange > 0">
						<!--积分加现金-->
						+{{ goodsDetail.point_exchange }}积分
					</template>
				</text>
			</view>

			<view class="original-price ns-text-color-gray" v-if="parseFloat(showPrice) < parseFloat(goodsDetail.price)">
				<text class="label">原价:</text>
				<text class="price">¥{{ goodsDetail.price }}</text>
			</view>
		</view>

		<!-- 普通价格 -->
		<view
			v-else-if="goodsDetail['promotion_detail'] != null && goodsDetail['promotion_detail']['discount_detail'] == null && goodsDetail['is_open_presell'] == 0"
			class="product-price"
		>
			<view class="real-price ns-text-color">
				<template v-if="(goodsDetail.point_exchange_type == 2 && fromSource == 'point') || goodsDetail.point_exchange_type == 3">
					<text class="price">{{ goodsDetail.point_exchange }}积分</text>
				</template>
				<template v-else>
					<text class="price-symbol">¥</text>
					<text class="price">
						<template v-if="parseFloat(goodsDetail.promotion_price) < parseFloat(goodsDetail.member_price)">
							{{ goodsDetail.promotion_price }}
						</template>
						<template v-else>
							{{ goodsDetail.member_price }}
						</template>

						<template v-if="goodsDetail.point_exchange_type == 1 && goodsDetail.point_exchange > 0">
							<!--积分加现金-->
							+{{ goodsDetail.point_exchange }}积分
						</template>
					</text>					
					<text class="ns-text-color" v-if="goodsDetail.goods_unit != ''">/{{ goodsDetail.goods_unit }}</text>
					<text v-if="uid > 0"  class="original-price">[￥{{ goodsDetail.price }}]</text>
				</template>
			</view>

			<template v-if="promotionCount > 0">
				<view
					class="original-price ns-text-color-gray"
					v-if="
						promotionCount > 0 &&
							goodsDetail.promotion_detail.combo_package != null &&
							promotionCount == 1 &&
							parseFloat(goodsDetail.market_price) > parseFloat(showPrice)
					"
				>
					<text class="label">市场价:</text>
					<text class="price">¥{{ goodsDetail.market_price }}</text>
				</view>
			</template>
			<template v-else>
				<view class="original-price ns-text-color-gray" v-if="parseFloat(goodsDetail.market_price) > parseFloat(showPrice)">
					<text class="label">市场价:</text>
					<text class="price">¥{{ goodsDetail.market_price }}</text>
				</view>
			</template>
		</view>

		<view class="blank-line ns-bg-color-gray"></view>

		<view v-if="goodsDetail['is_open_presell'] == 1">
			<view class="product-presell-delivery-time ns-text-color-gray">
				<text>发货</text>
				<template v-if="goodsDetail.presell_delivery_type == 1">
					<text>{{ $util.timeStampTurnTime(goodsDetail.presell_time) }}发货</text>
				</template>
				<template v-else>
					<text>付款{{ goodsDetail.presell_day }}天后发货</text>
				</template>
			</view>
			<view class="line ns-border-color-gray"></view>
		</view>

		<!-- 优惠券 -->
		<view v-if="couponCount > 0">
			<view class="product-coupon">
				<text class="flag">优惠券</text>
				<text class="coupon-tip">领取优惠劵</text>
				<text class="get-coupon ns-text-color-gray ns-border-color-gray" @click="openCouponPopup()">领取</text>
			</view>

			<view @touchmove.prevent.stop>
				<uni-popup ref="couponPopup" type="bottom">
					<view class="product-coupon-popup-layer">
						<text class="tax-title ns-text-color-black">优惠券</text>
						<scroll-view class="coupon-body" scroll-y>
							<view v-for="(item, index) in goodsDetail.goods_coupon_list" :key="index" class="item">
								<view class="main">
									<view class="price">
										<text class="unit">¥</text>
										<text class="money">{{ item.money }}</text>
									</view>
									<view class="sub" v-if="item.at_least > 0">满{{ item.at_least }}使用</view>
									<view class="sub" v-else>无门槛优惠券</view>
									<view class="sub" v-if="item.term_of_validity_type == 0">
										有效期 {{ $util.timeStampTurnTime(item.start_time) }}-{{ $util.timeStampTurnTime(item.end_time) }}
									</view>
									<view class="sub" v-else>领取之日起{{ item.fixed_term }}天内有效</view>
								</view>
								<view class="tax-split"></view>
								<view class="tax-operator" @click="receiveGoodsCoupon(item.coupon_type_id)">立即领取</view>
							</view>
						</scroll-view>
						<button type="primary" @click="closeCouponPopup()">确定</button>
					</view>
				</uni-popup>
			</view>

			<view class="line ns-bg-color-gray"></view>
		</view>

		<!-- 满送 -->
		<template v-if="goodsDetail.mansong_name != ''">
			<view class="product-mansong">
				<text class="flag">满减</text>
				<text class="info">{{ goodsDetail.mansong_name }}</text>
			</view>
			<view class="blank-line ns-bg-color-gray"></view>
		</template>

		<!-- 阶梯优惠 -->
		<view v-show="ladderPreferentialCount > 0">
			<view class="product-ladder-preferential" @click="openLadderPreferentialPopup()">
				<text class="flag">阶梯优惠</text>
				<text class="info">
					满
					<text class="ns-text-color bold" v-if="ladderPreferentialCount > 0 && goodsDetail.goods_ladder_preferential_list">
						{{ goodsDetail.goods_ladder_preferential_list[0]['quantity'] }}
					</text>
					<template v-if="goodsDetail.goods_unit != ''">
						{{ goodsDetail.goods_unit }}
					</template>
					<template v-else>
						件
					</template>
					,每
					<template v-if="goodsDetail.goods_unit != ''">
						{{ goodsDetail.goods_unit }}
					</template>
					<template v-else>
						件
					</template>
					降
					<text class="ns-text-color bold" v-if="ladderPreferentialCount > 0 && goodsDetail.goods_ladder_preferential_list">
						{{ goodsDetail.goods_ladder_preferential_list[0]['price'] }}
					</text>
					元
				</text>
				<view class="ns-text-color-gray iconfont iconright"></view>
			</view>
			<view @touchmove.prevent.stop>
				<uni-popup ref="ladderPreferentialPopup" type="bottom">
					<view class="product-ladder-preferential-popup-layer">
						<text class="tax-title ns-text-color-black">阶梯优惠</text>
						<scroll-view scroll-y>
							<view v-for="(item, index) in goodsDetail.goods_ladder_preferential_list" :key="index" class="item">
								<text class="mark_title">阶梯优惠</text>
								<text>
									满
									<text class="ns-text-color bold">{{ item.quantity }}</text>
									<template v-if="goodsDetail.goods_unit != ''">
										{{ goodsDetail.goods_unit }}
									</template>
									<template v-else>
										件
									</template>
									,每
									<template v-if="goodsDetail.goods_unit != ''">
										{{ goodsDetail.goods_unit }}
									</template>
									<template v-else>
										件
									</template>
									降
									<text class="ns-text-color bold">{{ item.price }}</text>
									元
								</text>
							</view>
						</scroll-view>
						<button type="primary" @click="closeLadderPreferentialPopup()">确定</button>
					</view>
				</uni-popup>
			</view>
			<view class="blank-line ns-bg-color-gray"></view>
		</view>

		<!-- 实物商品参加包邮活动 -->
		<template v-if="goodsDetail.is_virtual == 0 && goodsDetail['baoyou_name'] != ''">
			<view class="product-baoyou">
				<text class="flag">包邮</text>
				<text class="info">{{ goodsDetail['baoyou_name'] }}</text>
			</view>
			<view class="line ns-bg-color-gray"></view>
		</template>

		<!--赠送积分-->
		<template v-if="goodsDetail['give_point'] > 0">
			<view class="product-give-point">
				<text class="flag">赠送积分</text>
				<text class="info">{{ goodsDetail['give_point'] }}积分</text>
			</view>
			<view class="line ns-bg-color-gray"></view>
		</template>

		<!-- 积分抵现 -->
		<template v-if="(goodsDetail.point_exchange_type == 2 && fromSource == 'point') || goodsDetail.point_exchange_type == 0">
			<view class="product-point-for-now " v-if="goodsDetail['integral_balance'] > 0 && goodsDetail['is_open_presell'] != 1">
				购买本商品积分可抵{{ goodsDetail['integral_balance'] }}元
			</view>
			<view class="line ns-bg-color-gray"></view>
		</template>

		<!-- 销量评价 -->
		<view class="product-sales-freight-area ns-text-color-gray">
			<text class="postage js-shipping-fee-name">快递:&nbsp;{{ shippingFeeName }}</text>
			<text class="sales">
				销量:&nbsp;{{ goodsDetail['sales'] }}
				<template v-if="goodsDetail.goods_unit != ''">
					{{ goodsDetail.goods_unit }}
				</template>
				<template v-else>
					件
				</template>
			</text>
			<text class="delivery">点击量：{{ goodsDetail.clicks }}</text>
		</view>

		<!-- 服务 -->
		<!-- <view class="blank-line ns-bg-color-gray"></view>
		<view class="product-service">
			<text>服务</text>
			<text class="info">由{$title}发货并提供售后服务</text>
		</view>
		<view class="line ns-bg-color-gray"></view> -->

		<!-- 商家服务 -->
		<view class="product-merchants-service" @click="openMerchantsServicePopup()">
			<view class="service-list">
				<text v-for="(item, index) in merchantServiceList" :key="index">
					<template v-if="index < 4">
						{{ item.title }}
					</template>
				</text>
			</view>
			<view class="ns-text-color-gray iconfont iconright"></view>
		</view>
		<view @touchmove.prevent.stop>
			<uni-popup ref="merchantsServicePopup" type="bottom">
				<view class="product-merchants-service-popup-layer">
					<text class="tax-title ns-text-color-black">商家服务</text>
					<scroll-view scroll-y>
						<view v-for="(item, index) in merchantServiceList" :key="index" class="item">
							<view class="image-wrap"><image :src="$util.img(item.pic)"></image></view>
							<view class="info-wrap">
								<text class="title">{{ item.title }}</text>
								<text class="describe">{{ item.describe }}</text>
							</view>
						</view>
					</scroll-view>
					<button type="primary" @click="closeMerchantsServicePopup()">确定</button>
				</view>
			</uni-popup>
		</view>
		<view class="blank-line ns-bg-color-gray"></view>

		<!-- 商品属性 -->
		<view v-if="attributeCount > 0">
			<view class="product-attribute" @click="openAttributePopup()">
				<text class="ns-text-color-gray">属性</text>
				<text class="info" v-if="attributeCount > 0 && goodsDetail['goods_attribute_list']">
					{{ goodsDetail['goods_attribute_list'][0]['attr_value'] }}&nbsp;{{ goodsDetail['goods_attribute_list'][0]['attr_value_name'] }}...
				</text>
				<view class="ns-text-color-gray iconfont iconright"></view>
			</view>
			<view @touchmove.prevent.stop>
				<uni-popup ref="attributePopup" type="bottom">
					<view class="product-attribute-popup-layer">
						<text class="title">基础信息</text>
						<scroll-view scroll-y class="product-attribute-body">
							<view v-for="(item, index) in goodsDetail.goods_attribute_list" :key="index" class="item ns-border-color-gray">
								<text class="ns-text-color-gray">{{ item.attr_value }}</text>
								<text class="value">{{ item.attr_value_name }}</text>
							</view>
						</scroll-view>
						<button type="primary" @click="closeAttributePopup()">确定</button>
					</view>
				</uni-popup>
			</view>
			<view class="blank-line ns-bg-color-gray"></view>
		</view>

		<!-- 商品组合套餐，普通商品才能使用 -->
		<template v-if="promotionCount > 0 && comboPackage['goods_array'].length > 0">
			<navigator class="product-combo" :url="'/pages/goods/combo/combo?goods_id=' + goodsId">
				<text>组合套餐</text>
				<view class="ns-text-color-gray iconfont iconright"></view>
			</navigator>

			<view class="combo-goods-wrap ns-text-color-gray">
				<navigator class="goods ns-border-color-gray" :url="'/pages/goods/detail/detail?goods_id=' + comboPackage['main_goods']['goods_id']">
					<image :src="$util.img(comboPackage['main_goods']['pic_cover_mid'])"></image>
					<text>¥{{ comboPackage['main_goods']['price'] }}</text>
				</navigator>
				<view class="iconfont iconadd ns-text-color-gray"></view>
				<navigator
					v-for="(item, index) in comboPackage['goods_array']"
					:key="index"
					class="goods ns-border-color-gray"
					:url="'/pages/goods/detail/detail?goods_id=' + item['goods_id']"
				>
					<image :src="$util.img(item['pic_cover_mid'])"></image>
					<text>¥{{ item['price'] }}</text>
				</navigator>
			</view>
			<view class="blank-line ns-bg-color-gray"></view>
		</template>

		<!-- 商品评价 -->
		<view class="product-evaluation-main">
			<view class="product-evaluation-title">
				<text>宝贝评价 ({{ evaluateCount }})</text>
			</view>

			<!-- <view class="product-evaluation-ul">
				<text @click="getGoodsComments(0)">全部评价({{ evaluateCount }})</text>
				<text @click="getGoodsComments(4)">晒图({{ imgsCount }})</text>
				<text @click="getGoodsComments(1)">好评({{ praiseCount }})</text>
				<text @click="getGoodsComments(2)">中评({{ centerCount }})</text>
				<text @click="getGoodsComments(3)">差评({{ badCount }})</text>
			</view> -->

			<view class="product-comments" v-if="firstCommentInfo.user_img != null">
				<view class="user">
					<template v-if="firstCommentInfo.user_img != ''">
						<image :src="$util.img(firstCommentInfo.user_img)"></image>
					</template>
					<template v-else>
						<image :src="$util.img('upload/uniapp/default_head.png')"></image>
					</template>
					<view class="user-desc">
						<text class="name">{{ firstCommentInfo.member_name }}</text>
						<text class="time ns-text-color-gray">{{ $util.timeStampTurnTime(firstCommentInfo.addtime) }}</text>
					</view>
				</view>
				<view class="product-content">{{ firstCommentInfo.content }}</view>
				<view v-if="firstCommentInfo.image.length > 0" class="product-pic">
					<image v-for="(item, index) in firstCommentInfo.image" :key="index" :src="$util.img(item)" mode="aspectFit"></image>
				</view>
			</view>
			<view class="view-more" v-if="firstCommentInfo.user_img != null" @click="openCommentsPopup()">查看全部</view>
			<view @touchmove.prevent.stop>
				<uni-popup ref="commentsPopup" type="right">
					<view class="comments-popup-layer" :style="{ height: systemInfo.windowHeight + 'px' }">
						<view class="head-wrap">
							<text class="title">评价</text>
							<view class="iconfont iconback_light" @click="closeCommentsPopup()"></view>
						</view>
						<!-- <view class="filter">
						<text @click="getGoodsComments(0)" :class="commentsType == 0 ? 'selected' : ''">全部评价({{ evaluateCount }})</text>
						<text @click="getGoodsComments(4)" :class="commentsType == 4 ? 'selected' : ''">晒图({{ imgsCount }})</text>
						<text @click="getGoodsComments(1)" :class="commentsType == 1 ? 'selected' : ''">好评({{ praiseCount }})</text>
						<text @click="getGoodsComments(2)" :class="commentsType == 2 ? 'selected' : ''">中评({{ centerCount }})</text>
						<text @click="getGoodsComments(3)" :class="commentsType == 3 ? 'selected' : ''">差评({{ badCount }})</text>
					</view> -->

						<scroll-view scroll-y @scroll="loadMoreComment">
							<view v-for="(item, index) in commentList" :key="index" class="item ns-border-color-gray">
								<view class="info ns-text-color-gray">
									<view class="author">
										<template v-if="item.user_img != ''">
											<image :src="$util.img(item.user_img)"></image>
										</template>
										<template v-else>
											<image src="/static/images/default_head.png"></image>
										</template>
										<view class="autor-content">
											<text class="nick">{{ item.member_name }}</text>
											<text class="add-time">{{ $util.timeStampTurnTime(item.addtime) }}</text>
										</view>
									</view>
								</view>

								<text class="content">{{ item.content }}</text>

								<view class="evaluation-pics" v-if="item.image.length > 0">
									<image v-for="(_item, index) in item.image" :key="index" :src="$util.img(_item)" class="comment-pic" mode="aspectFit" />
								</view>

								<view class="evaluation-reply ns-bg-color-gray" v-if="item.explain_first != ''">店家回复：{{ item.explain_first }}</view>

								<template v-if="item.again_content != ''">
									<view class="review-evaluation">
										追加评价
										<text class="review-time ns-text-color-gray">{{ $util.timeStampTurnTime(item.again_addtime) }}</text>
									</view>

									<view class="evaluation-pics" v-if="item.again_image.length > 0">
										<image v-for="(_item, index) in item.again_image" :key="index" :src="$util.img(_item)" class="comment-pic" mode="aspectFit"></image>
									</view>

									<view class="evaluation-content review">{{ item.again_content }}</view>
									<view class="evaluation-reply" v-if="item.again_explain != ''">店家回复：{{ item.again_explain }}</view>
								</template>
							</view>
						</scroll-view>
					</view>
				</uni-popup>
			</view>
		</view>

		<view class="blank-line ns-bg-color-gray"></view>

		<!-- 详情 -->
		<view class="product-details"><rich-text :nodes="description"></rich-text></view>

		<!-- 底部功能导航 -->
		<view class="product-bottom-bar" :class="isIphoneX ? 'padding-bottom' : ''">	
			<!-- <uni-goods-nav :options="leftOperation" :button-group="rightOperation" @click="leftOperationClick" @buttonClick="rightOperationClick" /> -->
			<ns-goods-action>
				<template v-if="goodsDetail.state == 1">
					<ns-goods-action-icon text="首页" icon="iconshoplight" @click="goHome" class="goods-action-left"></ns-goods-action-icon>
					<!-- #ifdef MP -->
					<ns-goods-action-icon text="客服" icon="iconkefu" open-type="contact" :send-data="contactData" class="goods-action-left"></ns-goods-action-icon>
					<!-- #endif -->
					<!-- #ifdef H5 -->
					<ns-goods-action-icon text="客服" icon="iconkefu" @click="kefu" class="goods-action-left"></ns-goods-action-icon>
					<!-- #endif -->
					<ns-goods-action-icon
						text="购物车"
						icon="iconicozhuanhuan"
						:corner-mark="cartCount > 0 ? cartCount + '' : ''"
						corner-mark-bg="#FF0036"
						@click="goCart"
						class="goods-action-left"
					></ns-goods-action-icon>
					<block v-if="goodsDetail.is_open_presell == 1">
						<ns-goods-action-button
							class="goods-action-button ns-bg-color"
							text="立即预定"
							background="#ee0a24"
							@click="buyNow('buy_now')"
						/>
					</block>
					<block v-else>
						<block>
							<ns-goods-action-button 
								v-if="goodsDetail.is_virtual == 0 && (goodsDetail.point_exchange_type == 0 || (goodsDetail.point_exchange_type == 2 && fromSource != 'point')) && promotionCount == 0"
								class="goods-action-button"
								text="加入购物车"
								background="#ff8917"
								@click="joinCart('add_cart')"
							></ns-goods-action-button>
						</block>
						<ns-goods-action-button
							v-if="goodsDetail.point_exchange_type == 1 || (goodsDetail.point_exchange_type == 2 && fromSource == 'point') || goodsDetail.point_exchange_type == 3"
							class="goods-action-button"
							text="积分兑换"
							background="#ee0a24"
							@click="buyNow('buy_now')"
						></ns-goods-action-button>
						<ns-goods-action-button
							v-else
							class="goods-action-button"
							text="立即购买"
							background="#ee0a24"
							@click="buyNow('buy_now')"
						></ns-goods-action-button>
					</block>						
				</template>
				<template v-else>
					<ns-goods-action-button class="goods-action-button" disabled-text="该商品已下架" :disabled="true"></ns-goods-action-button>
				</template>
			</ns-goods-action>
			
			
			<view @touchmove.prevent.stop>
				<uni-popup ref="skuPopup" type="bottom" class="sku-layer">
					<view class="sku-info">
						<view class="header">
							<view class="img-wrap"><image :src="$util.img(selectedSkuInfo.picCoverSmall)" /></view>
							<view class="main">
								<view v-if="goodsDetail['is_open_presell'] == 1">
									<view class="price-wrap">
										<text class="price ns-text-color">定金¥{{ goodsDetail.presell_price }}</text>
									</view>
								</view>
								<view v-else>
									<view class="price-wrap">
										<template v-if="(goodsDetail.point_exchange_type == 2 && fromSource == 'point') || goodsDetail.point_exchange_type == 3">
											<!--积分-->
											<text class="price ns-text-color">{{ goodsDetail.point_exchange }}积分</text>
										</template>
										<template v-else>
											<text class="price ns-text-color">{{ selectedSkuInfo.displayPrice }}</text>
										</template>
									</view>
								</view>

								<view v-if="goodsDetail.is_stock_visible == 1" class="stock">
									库存{{ selectedSkuInfo.stock }}
									<template v-if="goodsDetail.goods_unit != ''">
										{{ goodsDetail.goods_unit }}
									</template>
									<template v-else>
										件
									</template>
								</view>

								<view class="sku-name">
									<template v-if="currentGoodsSkuName.length > 0">
										已选择：
										<text v-for="(item, index) in currentGoodsSkuName" :key="index">{{ item }}</text>
									</template>
								</view>
							</view>

							<view class="sku-close iconfont iconclose" @click="closeSkuPopup()"></view>
						</view>

						<view class="body-item" :class="{'safearea' : isIphoneX}">
							<scroll-view scroll-y="true" class="wrap">
								<view v-for="(item, index) in goodsDetail['spec_list']" :key="index" class="sku-list-wrap">
									<text class="title">{{ item.spec_name }}</text>
									<view
										v-for="(item_value, index_value) in item.value"
										:key="index_value"
										class="items ns-border-color-gray ns-bg-color-gray"
										:class="{ selected: item_value['selected'], disabled: item_value['disabled'] }"
										@click="selectedSku(item_value)"
									>
										<template v-if="item_value.spec_show_type == 1">
											<text>{{ item_value.spec_value_name }}</text>
										</template>
										<template v-else-if="item_value.spec_show_type == 2">
											<!-- 图片 -->
											<image v-if="item_value.spec_value_data != ''" :src="$util.img(item_value.spec_value_data)"></image>
											<text>{{ item_value.spec_value_name }}</text>
										</template>

										<template v-else-if="item_value.spec_show_type == 3">
											<!-- 颜色 -->
											<text v-if="item_value.spec_value_data != ''" class="color" :style="{ background: item_value.spec_value_data }"></text>
											<text>{{ item_value.spec_value_name }}</text>
										</template>
									</view>
								</view>

								<view class="number-wrap">
									<view class="number-line">
										<text class="title">购买数量</text>
										<text class="limit-txt" v-if="goodsDetail['max_buy'] > 0">
											(每人限购{{ goodsDetail['max_buy'] }}
											<template v-if="goodsDetail.goods_unit != ''">
												{{ goodsDetail.goods_unit }}
											</template>
											<template v-else>
												件
											</template>
											)
										</text>
										<view class="number">
											<button type="default" class="decrease" @click="changeNum('-')">-</button>
											<input class="uni-input" type="number" v-model="number" placeholder="0" @input="keyInput" />
											<button type="default" class="increase" @click="changeNum('+')">+</button>
										</view>
									</view>
								</view>
							</scroll-view>
						</view>

						<button type="primary" @click="confirm()" class="footer" :class="{ disabled: selectedSkuInfo.stock == 0, 'position-bottom': isIphoneX }">确定</button>
					</view>
				</uni-popup>
			</view>
		</view>
		
		<loading-cover ref="loadingCover"></loading-cover>

		<!-- 海报 -->
		<view @touchmove.prevent.stop>
			<uni-popup ref="posterPopup" type="bottom" class="poster-layer">
				<template v-if="poster != '-1'">
					<view :style="{ height: posterHeight > 0 ? posterHeight + 80 + 'px' : '' }">
						<view class="image-wrap"><image :src="$util.img(poster)" :style="{ height: posterHeight > 0 ? posterHeight + 'px' : '' }" /></view>
						<!-- #ifdef MP -->
						<view class="save" @click="saveGoodsPoster()">保存图片</view>
						<!-- #endif -->
						<!-- #ifdef H5 -->
						<view class="save">长按保存图片</view>
						<!-- #endif -->
					</view>
					<view class="close iconfont iconclose" @click="closePosterPopup()"></view>
				</template>
				<view v-else class="msg">{{ posterMsg }}</view>
			</uni-popup>
		</view>
		<!-- 分享弹窗 -->
		<view @touchmove.prevent.stop>
			<uni-popup ref="sharePopup" type="bottom" class="share-popup">
				<view>
					<view class="share-title">分享</view>
					<view class="share-content">
						<!-- #ifdef MP -->
						<view class="share-box">
							<button class="share-btn" :plain="true" open-type="share">
								<view class="iconfont iconiconfenxianggeihaoyou"></view>
								<text>分享给好友</text>
							</button>
						</view>
						<!-- #endif -->
						<view class="share-box" @click="openPosterPopup">
							<button class="share-btn" :plain="true">
								<view class="iconfont iconpengyouquan"></view>
								<text>生成分享海报</text>
							</button>
						</view>
					</view>
					<view class="share-footer" @click="closeSharePopup"><text>取消分享</text></view>
				</view>
			</uni-popup>
		</view>
		<ns-login ref="login" href="goods_detail"></ns-login>
	</view>
</template>

<script>
import http from 'common/js/http.js';
import uniPopup from '@/components/uni-popup/uni-popup.vue';
import uniGoodsNav from '@/components/uni-goods-nav/uni-goods-nav.vue';
import detail from 'static/js/goods/detail.js';
import loadingCover from '@/components/loading/loading.vue';
import uniCountDown from '@/components/uni-count-down/uni-count-down.vue';
import nsLogin from '@/components/ns-login/ns-login.vue';
import nsGoodsActionButton from 'components/ns-goods-action-button/ns-goods-action-button.vue';
import nsGoodsActionIcon from 'components/ns-goods-action-icon/ns-goods-action-icon';
import nsGoodsAction from '@/components/ns-goods-action/ns-goods-action.vue';
// import nsGoodsSku from '@/components/ns-goods-sku/ns-goods-sku.vue';
export default {
	components: {
		uniPopup,
		uniGoodsNav,
		loadingCover,
		uniCountDown,
		nsLogin,
		// nsGoodsSku
		nsGoodsActionButton,
		nsGoodsActionIcon,
		nsGoodsAction
	},
	mixins: [http, detail],
	data() {
		return {
			topPermissions: 0,
			promotionType: 0, //活动类型 //1 组合套餐	2 团购	3 砍价	4 积分兑换
			orderType: 1, //订单类型 // 1 普通订单	4 拼团订单	6 预售订单	7 砍价订单
			discountTimeMachine: {} //限时折扣活动时间
		};
	},
	onShow() {},
	methods: {
	},
	/**
	 * 自定义分享内容
	 * @param {Object} res
	 */
	onShareAppMessage(res) {
		var path = '/pages/goods/detail/detail?goods_id=' + this.goodsId;
		if (this.uid) path += '&source_uid=' + this.uid;
		return {
			title: this.goodsDetail.goods_name,
			imageUrl: this.$util.img(this.goodsDetail.img_list[0].pic_cover_big),
			path: path,
			success: res => {
				this.sendRequest({
					url: 'NsMemberShare.MemberShare.shareReward'
				})
			},
			fail: res => {		
			}
		};
	}
};
</script>

<style lang="scss">
@import 'static/css/goods/detail.scss';
</style>
<style scoped>
/deep/ .uni-popup__wrapper.uni-custom .uni-popup__wrapper-box {
	max-height: unset !important;
}
.sku-layer >>> .uni-popup__wrapper-box {
	overflow-y: initial !important;
}
.poster-layer >>> .uni-popup__wrapper-box {
	max-height: initial !important;
}
.product-discount .countdown .clockrun >>> .uni-countdown__number {
	min-width: 32rpx;
	height: 32rpx;
	text-align: center;
	line-height: 32rpx;
	background: #000;
	/* // #690b08 */
	border-radius: 4px;
	display: inline-block;
	padding: 4rpx;
	margin: 0;
	border: none;
}
.product-discount .countdown .clockrun >>> .uni-countdown__splitor {
	width: 10rpx;
	height: 32rpx;
	line-height: 36rpx;
	text-align: center;
	display: inline-block;
	color: #000;
	padding: 0 4rpx;
}
.original-price{
	text-decoration: line-through;
	color: #333;
	font-size: 26rpx;
}
</style>