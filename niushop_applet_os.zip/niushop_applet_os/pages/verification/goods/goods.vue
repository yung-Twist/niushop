<template>
	<view>
		<view class="ns-padding">
			<view class="shop ns-padding-top ns-padding-bottom">
				<navigator :url="'/pages/goods/detail/detail?goods_id=' + verification.goods_id">
					<image class="ns-margin-right" :src="verificationPic.pic_cover_mid ? $util.img(verificationPic.pic_cover_mid) : $util.img('upload/uniapp/default_head.png')"></image>
				</navigator>
				<view class="ns-margin-left">
					<view>{{ verification.goods_name }}</view>
					<view class="ns-font-size-sm ns-text-color-gray">{{ verification.virtual_goods_name }}</view>
				</view>
			</view>
		</view>
		<view class="ns-padding">
			<view class="verification-item ns-margin-left ns-margin-right verification-item-1">
				<view>核销人</view>
				<view class="ns-font-size-sm ns-text-color-gray">{{ verificaditionPersonInfo.nick_name }}</view>
			</view>
			<view class="verification-item ns-margin-left ns-margin-right verification-item-2">
				<view>核销码</view>
				<view class="ns-font-size-sm ns-text-color-gray">{{ verification.virtual_code }}</view>
			</view>
			<view class="verification-item ns-margin-left ns-margin-right">
				<view>有效期</view>
				<view class="ns-font-size-sm ns-text-color-gray" v-if="verification.end_time != 0">到{{ $util.timeStampTurnTime(verification.end_time) }}之前有效</view>
				<view class="ns-font-size-sm ns-text-color-gray" v-else>不限</view>
			</view>
		</view>
		<button type="primary" @click="verificationVirtualGoods()">确认核销</button>
		<loading-cover ref="loadingCover"></loading-cover>
	</view>
</template>

<script>
import http from 'common/js/http.js';
import loadingCover from '@/components/loading/loading.vue';
export default {
	components: {
		loadingCover
	},
	data() {
		return {
			vgId: 0,
			verification: [],
			verificationPic: [],
			verificaditionPersonInfo: [],
			isSubmit: true
		};
	},
	onLoad(data) {
		this.vgId = data.vg_id;

		// 小程序扫码进入
		if (data.scene) {
			let sceneParams = data.scene.split('-');
			this.vgId = sceneParams[1];
		}

		this.getVerification();
	},
	mixins: [http],
	methods: {
		getVerification() {
			this.sendRequest({
				url: 'System.Order.verificationExamine',
				data: {
					vg_id: this.vgId
				},
				success: res => {
					if (res.data) {
						this.getVerificationPersonInfo();
						this.verification = res.data;
						this.verificationPic = res.data.picture;
						if (this.$refs.loadingCover == undefined) return;
						this.$refs.loadingCover.hide();
					} else {
						this.$util.showToast({
							title: res.message
						});
						setTimeout(() => {
							this.$util.redirectTo('/pages/member/index/index', {}, 'tabbar');
						}, 1500);
					}
				}
			});
		},
		getVerificationPersonInfo() {
			this.sendRequest({
				url: 'System.Order.getVerificationPersonnelInfo',
				success: res => {
					this.verificaditionPersonInfo = res.data;
				}
			});
		},
		verificationVirtualGoods() {
			if (!this.isSubmit) return;
			this.isSubmit = false;
			this.sendRequest({
				url: 'System.Order.verificationVirtualGoods',
				data: {
					virtual_goods_id: this.verification.virtual_goods_id
				},
				success: res => {
					if (res.data > 0) {
						this.$util.showToast({
							title: '核销成功'
						});
						setTimeout(() => {
							this.$util.redirectTo('/pages/member/index/index', {}, 'tabbar');
						}, 1500);
					} else {
						this.$util.showToast({
							title: '核销失败'
						});
						this.isSubmit = true;
					}
				}
			});
		}
	}
};
</script>

<style lang="scss">
page {
	background: #fff;
}
.shop {
	display: flex;
	image {
		width: 213rpx;
		height: 213rpx;
	}
}
.verification-item {
	display: flex;
	justify-content: space-between;
	view {
		line-height: 80rpx;
	}
}
.verification-item-1,
.verification-item-2,
.shop-name {
	border-bottom: 2rpx solid $ns-border-color-gray;
}
button {
	margin-top: 40rpx;
}
</style>
