<template>
	<view class="goods-list-grid">
		<view class="bg-img" :style="{ background: topicBg }"></view>
		<view class="topic-scroll"><image :src="$util.img(info.scroll_img)" mode="aspectFit"></image></view>
		<view class="goods-list">
			<view class="goods-item" v-for="(item, index) in info.goods_list" :key="index">
				<navigator class="item-head" :url="'/pages/goods/detail/detail?goods_id=' + item.goods_id">
					<image lazy-load="true" class="item-pic" :src="$util.img(item.picture_info.pic_cover_small)" mode="aspectFit"></image>
				</navigator>
				<view class="item-body">
					<navigator class="item-name" :url="'/pages/goods/detail/detail?goods_id=' + item.goods_id">{{ item.goods_name }}</navigator>
					<text class="item-price" v-if="item.point_exchange_type < 2 && item.point_exchange_type >= 0">￥ {{ item.promotion_price }}</text>
					<template v-else>
						<text class="item-price" v-if="item.point_exchange_type == 1 && item.promotion_price > 0">
							￥ {{ item.promotion_price }} + {{ item.point_exchange }} 积分
						</text>
						<text class="item-price" v-else>{{ item.point_exchange }} 积分</text>
					</template>
				</view>
			</view>
		</view>
		<loading-cover ref="loadingCover"></loading-cover>
	</view>
</template>

<script>
import http from 'common/js/http.js';
import loadingCover from '@/components/loading/loading.vue';
export default {
	components: {
		loadingCover
	},
	data() {
		return {
			topicID: 0,
			topicBg: '',
			info: []
		};
	},
	onLoad(event) {
		this.topic_id = event.topic_id;
		this.initTopic();
	},
	mixins: [http],
	methods: {
		//初始化数据
		initTopic() {
			this.sendRequest({
				url: 'System.Goods.promotionTopicDetail',
				data: { topic_id: this.topic_id },
				success: res => {
					if (res.code == 0) {
						this.info = res.data;
						this.topicBg = 'url(' + res.data.background_img + ') no-repeat' + res.data.background_color;
						/* 修改头部命名 */
						uni.setNavigationBarTitle({ title: this.info.topic_name });
						if (this.$refs.loadingCover == undefined) return;
						this.$refs.loadingCover.hide();
					}
				}
			});
		}
	}
};
</script>

<style lang="scss">
page {
	background: none;
}
.goods-list-grid {
	height: calc(100vh - 44px);
	/* #ifdef MP */
	height: 100vh;
	/* #endif */
	.bg-img {
		width: 100%;
		height: 100%;
		position: fixed;
		z-index: -1;
		background-size: cover !important;
	}
}
.topic-scroll {
	height: 300rpx;
	image {
		width: 750rpx;
		height: 300rpx;
	}
}
.goods-list {
	padding-bottom: 40rpx;
}
.goods-item {
	display: flex;
	align-items: center;
	margin: 30rpx 30rpx 0;
	padding: 30rpx;
	height: 200rpx;
	background-color: #fff;
	border-radius: 10rpx;
	.item-head {
		width: 200rpx;
		height: 200rpx;
		margin-right: 20rpx;
		image {
			width: 200rpx;
			height: 200rpx;
		}
	}
	.item-body {
		display: flex;
		flex-direction: column;
		justify-content: space-between;
		height: 160rpx;
		.item-name {
			overflow: hidden;
			text-overflow: ellipsis;
			display: -webkit-box;
			-webkit-line-clamp: 2;
			-webkit-box-orient: vertical;
			font-size: $ns-font-size-base;
			line-height: 1.5;
			font-weight: 600;
		}
		.item-price {
			font-size: $ns-font-size-base;
			color: $base-color;
		}
	}
}
</style>
