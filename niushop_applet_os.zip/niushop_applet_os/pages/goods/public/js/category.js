export default {
	data() {
		return {
			showImg: '', //是否显示图片
			nameType: '', //显示全称或简称
			templatetype: '', //模版选择
			sideIdent: 0, //侧边导航是否选中标识
			goodsPageIndex: 1, //商品页数
			goodsList: [], //商品信息
			categoryList: [], //一级分类
			TwoCategoryList: [], //二级分类
			category_id: '',
			status: 'loading', //加载状态
			isEmpty: false, //是否显示空页面
			searchText: '', //搜索关键词
			goodsSearchText: '',
			orderType: '', //排序方式
			conditionIdent: 0, //筛选标识
			priceIdent: 0, //价格标识
			categoryTwoIdent: 0,
			ident: false, //防止初始化时，触发上拉加载
			sideClickIndex: -1, //防止重复侧导航栏重复点击
			searchIndex: true,
			priceIndex: true,
			pageCount: 0
		};
	},
	onLoad() {
		this.getCategoryType();
		this.getCategoryInfo();
	},
	methods: {
		/**
		 * 获取分类展示信息
		 */
		getCategoryType() {
			this.sendRequest({
				url: 'System.Goods.getAppletCategoryDisplay',
				success: res => {
					this.showImg = res.data.is_img;
					this.nameType = res.data.is_use;
					this.templatetype = res.data.template;
				}
			});
		},
		/**
		 * 获取分类信息
		 */
		getCategoryInfo() {
			this.sendRequest({
				url: 'System.Goods.goodsCategoryList',
				success: res => {
					if (res.data.length > 0) {
						/* 一级分类 */
						this.categoryList = res.data;
						this.category_id = this.categoryList[0].category_id;
						this.getGoodsInfo();

						/* 二级分类 */
						this.TwoCategoryList = this.categoryList[0].child_list;
					} else {
						this.isEmpty = true;
					}
					if (this.$refs.loadingCover == undefined) return;
					this.$refs.loadingCover.hide();
				},
				fail: res => {
					if (this.$refs.loadingCover == undefined) return;
					this.$refs.loadingCover.hide();
				}
			});
		},
		/**
		 * 获取商品信息
		 */
		getGoodsInfo(type = '') {
			let condition = {};
			if (type == 'refresh') {
				this.goodsPageIndex = 1;
				this.goodsList = [];
				this.status = 'more';
			}
			if (this.status == 'nomore') return;
			if (this.goodsSearchText == '') {
				condition = JSON.stringify({
					'ng.category_id': this.category_id,
					'ng.state': 1
				});
			} else {
				condition = JSON.stringify({
					'ng.category_id': this.category_id,
					'ng.state': 1,
					'ng.goods_name': ['like', '%' + this.goodsSearchText + '%']
				});
			}
			this.sendRequest({
				url: 'System.Goods.goodsList',
				data: {
					page_index: this.goodsPageIndex,
					page_size: 13,
					condition: condition,
					order: this.orderType
				},
				success: res => {
					let goods = res.data;
					this.searchIndex = true;
					this.priceIndex = true;
					this.pageCount = goods.page_count;
					if (this.pageCount == 0) {
						this.status = 'nomore';
						this.isEmpty = true;
					} else {
						this.status = this.goodsPageIndex < this.pageCount ? 'more' : 'nomore';

						this.isEmpty = false;
						if (goods.data.length > 0) {
							this.goodsList = this.goodsList.concat(goods.data);
							this.goodsPageIndex++;
						}
					}

					this.$refs.loadingCover.hide();
				}
			});
		},

		/**
		 * 侧边导航栏的点击事件
		 */
		sideNavClick(id, index = 0) {
			// 防止重复点击
			if (index == this.sideClickIndex) return;
			this.sideClickIndex = index;

			// 初始化加载状态
			this.status = 'loading';
			// 初始化页数
			this.goodsPageIndex = 1;
			//初始化存储商品的数组
			this.goodsList = [];
			//初始化价格箭头的颜色
			this.priceIdent = 0;
			this.categoryTwoIdent = index;
			//初始化搜索关键词
			this.goodsSearchText = '';

			this.TwoCategoryList = this.categoryList[index].child_list;

			this.sideIdent = index;
			this.category_id = id;
			this.getGoodsInfo();
		},
		/**
		 * 综合排序
		 */
		comprehensiveSorting() {
			if (this.conditionIdent == 0) return;
			this.priceIdent = 0;
			this.conditionIdent = 0;
			this.getGoodsInfo('refresh');
		},
		/**
		 * 销量
		 */
		salesVolume() {
			if (this.conditionIdent == 2) return;
			this.priceIdent = 0;
			this.conditionIdent = 2;
			this.orderType = 'ng.sales desc';
			this.getGoodsInfo('refresh');
		},
		/**
		 * 价格
		 */
		price() {
			if (!this.priceIndex) return;
			this.priceIndex = false;
			this.conditionIdent = 1;
			if (this.priceIdent == 2 || this.priceIdent == 0) {
				this.priceIdent = 1;
				this.orderType = 'ng.promotion_price desc';
			} else if (this.priceIdent == 1) {
				this.priceIdent = 2;
				this.orderType = 'ng.promotion_price asc';
			}

			this.getGoodsInfo('refresh');
		},
		/**
		 * 关键词搜索
		 */
		search() {
			if (!this.searchIndex) return;
			this.searchIndex = false;

			this.priceIdent = 0;
			this.goodsSearchText = this.searchText;
			this.getGoodsInfo('refresh');
		}
	}
};
