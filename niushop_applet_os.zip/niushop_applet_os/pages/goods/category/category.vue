<template>
	<view>
		<view class="category">
			<!-- 左边边分类 -->
			<view class="category-left">
				<view :class="category_id == item.category_id ? 'category-itemA' : 'category-item'" v-for="(item, index) in categoryList" :key="index" @click="changeCategory(item)">
					<text>{{item.category_name}}</text>
				</view>
			</view>
			<!-- 右边商品 -->
			<view class="category-right">
				<view class="category-product-item" v-for="(item, index) in goodsList" :key="index">
					<view class="item-header" :style="{'background-color':item.bgcolor}">
						<view class="product-title text-cut">{{item.goods_name}}</view>
						<!-- <view class="product-name">{{item.goods_name}}</view> -->
						<image :src="$util.img(item['pic_cover_mid'])" mode="" class="product-image"></image>
					</view>
					<view class="product-introduction">{{item.introduction}}</view>
					<view class="item-footer">
						<view class="product-price"><text>￥</text>{{item.promotion_price}}</view>
						<view class="moreBtn" @click="toGoodsDetail(item.goods_id)">了解详情</view>
					</view>
				</view>
			</view>
			<view v-if="isEmpty && goodsList.length == 0" class="category-right empty">
				<view class="iconfont iconwenzhangchaxun"></view>
				<view class="ns-text-color-gray">Sorry！没有找到您想要的商品分类…</view>
			</view>
		</view>
		
		<Tarbar :route="route"/>
		<loading-cover ref="loadingCover"></loading-cover>
	</view>
</template>

<script>
import http from 'common/js/http.js';
import loadingCover from '@/components/loading/loading.vue';
import Tarbar from '@/components/Tarbar'
export default {
	components: {
		loadingCover,
		Tarbar
	},
	mixins: [http],
	data() {
		return {
			route:null,
			category_id:1,
			goodsPageIndex:1,
			orderType:'',
			status:'',
			isEmpty:false,
			goodsSearchText:'',
			categoryList:[],
			goodsList:[]
		};
	},
	methods:{
		// 获取分类信息
		getCategoryInfo() {
			this.sendRequest({
				url: 'System.Goods.goodsCategoryList',
				success: res => {
					if (res.data.length > 0) {
						/* 一级分类 */
						this.categoryList = res.data;
						this.category_id = this.categoryList[0].category_id;
						this.getGoodsInfo();
					}
					if (this.$refs.loadingCover == undefined) return;
					this.$refs.loadingCover.hide();
				},
				fail: res => {
					if (this.$refs.loadingCover == undefined) return;
					this.$refs.loadingCover.hide();
				}
			});
		},
		// 获取商品信息
		getGoodsInfo(type = '') {
			let condition = {};
			if (type == 'refresh') {
				this.goodsPageIndex = 1;
				this.goodsList = [];
				this.status = 'more';
			}
			if (this.status == 'nomore') return;
			if (this.goodsSearchText == '') {
				condition = JSON.stringify({
					'ng.category_id': this.category_id,
					'ng.state': 1
				});
			} else {
				condition = JSON.stringify({
					'ng.category_id': this.category_id,
					'ng.state': 1,
					'ng.goods_name': ['like', '%' + this.goodsSearchText + '%']
				});
			}
			this.sendRequest({
				url: 'System.Goods.goodsList',
				data: {
					page_index: this.goodsPageIndex,
					page_size: 13,
					condition: condition,
					order: this.orderType
				},
				success: res => {
					let goods = res.data;
					this.searchIndex = true;
					this.priceIndex = true;
					this.pageCount = goods.page_count;
					if (this.pageCount == 0) {
						this.status = 'nomore';
						this.isEmpty = true;
					} else {
						this.status = this.goodsPageIndex < this.pageCount ? 'more' : 'nomore';

						this.isEmpty = false;
						if (goods.data.length > 0) {
							this.goodsList = this.goodsList.concat(goods.data);
							this.goodsPageIndex++;
						}
					}

					this.$refs.loadingCover.hide();
				}
			});
		},
		// 分类切换
		changeCategory(item){
			// 初始化加载状态
			this.status = 'loading';
			// 初始化页数
			this.goodsPageIndex = 1;
			//初始化存储商品的数组
			this.goodsList = [];
			//初始化搜索关键词
			this.goodsSearchText = '';
			this.category_id = item.category_id;
			this.getGoodsInfo();
		},
		// 前往商品详情
		toGoodsDetail(goodsId) {
			this.$util.redirectTo('/pages/goods/detail/detail', { goods_id: goodsId });
		}
	},
	onLoad() {
		let routes = getCurrentPages();
		this.route = routes[routes.length - 1].route
		this.getCategoryInfo()
	},
	onReady() {
		this.$refs.loadingCover.hide();
	}
};
</script>

<style lang="scss">
page{
		background-color: #FFFFFF;
	}
.category{
	.category-left{
		width: 198upx;
		height: 100vh;
		position: fixed;
		left: 0;
		overflow-y: scroll;
		padding-bottom: calc(var(--window-bottom) + 126upx);
		background-color: rgba(220,220,220,.2);
		.category-item{
			width: 100%;
			display: flex;
			flex-direction: column;
			height: 88upx;
			text-align: center;
			line-height: 88upx;
			color: #343434;
			font-size:28upx;
			font-weight:400;
			color:rgba(52,52,52,1);
		}
		.category-itemA{
			width: 100%;
			display: flex;
			flex-direction: column;
			height: 88upx;
			text-align: center;
			line-height: 88upx;
			background-color: #FFFFFF;
			font-size:28upx;
			font-weight:400;
			color:rgba(42,108,220,1);
			position: relative;
			&::after {
			    content: "";
			    width: 6upx;
			    height: 60upx;
			    position: absolute;
			    background-color: rgba(42,108,220,1);
			    top: 0;
			    left: 0upx;
			    bottom: 0;
			    margin: auto;
			  }
		}
	}
	.category-right{
		width: 552upx;
		position: fixed;
		right: 0;
		padding: 0 31upx;
		height: 100vh;
		overflow-y: scroll;
		padding-bottom: calc(var(--window-bottom) + 126upx);
		.category-product-item{
			width: 491upx;
			background:rgba(255,255,255,1);
			box-shadow:6upx 9upx 20upx 0upx rgba(39,71,98,0.2);
			border-radius:20upx;
			margin-top: 86upx;
			.item-header{
				position: relative;
				display: flex;
				flex-direction: column;
				padding: 38upx 29upx;
				border-radius:20upx;
				.product-title{
					width:250upx;
					white-space: wrap;
					font-size:30upx;
					font-weight:bold;
					color:rgba(52,52,52,1);
				}
				.product-name{
					width:250upx;
					white-space: wrap;
					font-size:26upx;
					font-weight:400;
					color:rgba(52,52,52,1);
				}
				.product-image{
					width: 151upx;
					height: 205upx;
					position: absolute;
					right: 37upx;
					top: -56upx;
				}
			}
			.product-introduction{
				margin-top: 30upx;
				font-size:24upx;
				font-weight:400;
				color:rgba(102,102,102,1);
				line-height:36upx;
				padding: 0 29upx;
			}
			.item-footer{
				display: flex;
				flex-direction: row;
				align-items: center;
				justify-content: space-between;
				margin-top: 40upx;
				padding: 0 29upx 38upx;
				.product-price{
					font-size:24upx;
					font-weight:400;
					color:rgba(255,0,0,1);
				}
				.moreBtn{
					width: 140upx;
					height: 40upx;
					background-color: #94B6ED;
					box-shadow:6upx 9upx 20upx 0upx rgba(39,71,98,0.2);
					border-radius:20upx;
					font-size:24upx;
					font-weight:400;
					color:rgba(255,255,255,1);
					text-align: center;
					line-height: 40upx;
				}
			}
		}
	}
}
</style>
