<template>
	<view>
		<view class="worker-info">
			<image class="ns-margin-right" :src="memberInfo.user_headimg ? $util.img(memberInfo.user_headimg) : $util.img('upload/uniapp/default_head.png')"></image>
			<view class="ns-margin-left">
				<view class="name">{{ memberInfo.nick_name }}</view>
				<view class="work ns-text-color-gray">店铺核销员</view>
			</view>
		</view>
		<view class="code uni-bold ns-font-size-lg ns-margin-top ns-padding">虚拟码</view>
		<view class="operate ns-padding">
			<input class="ns-font-size-sm uni-input" type="text" placeholder="请输入虚拟码" v-model="code" />
			<button type="primary" @click="checkVirtualCode()">核销</button>
		</view>
		<view class="tips ns-font-size-sm ns-text-color-gray ns-padding ns-margin-top">或者扫描买家的虚拟二维码！</view>
		<!-- #ifdef MP -->
		<button @click="scanCode">扫一扫</button>
		<!-- #endif -->
	</view>
</template>

<script>
import http from 'common/js/http.js';
export default {
	data() {
		return {
			memberInfo: [],
			code: '',
			isSubmit: true
		};
	},
	onLoad() {
		this.getVerification();
	},
	mixins: [http],
	methods: {
		getVerification() {
			this.sendRequest({
				url: 'System.Order.checkVerification',
				success: res => {
					if (res.data) {
						this.getMemberInfo();
					} else {
						this.$util.redirectTo('/pages/member/index/index');
					}
				}
			});
		},
		getMemberInfo() {
			this.sendRequest({
				url: 'System.Member.memberInfo',
				success: res => {
					this.memberInfo = res.data.user_info;
				}
			});
		},
		checkVirtualCode() {
			if (this.code.length == 0) {
				this.$util.showToast({
					title: '请输入虚拟码'
				});
				return false;
			}
			if (!this.isSubmit) return;
			this.isSubmit = false;
			this.sendRequest({
				url: 'System.Order.checkCode',
				data: {
					virtual_code: this.code
				},
				success: res => {
					var data = res.data;
					if (!data) {
						this.$util.showToast({
							title: res.message
						});
						this.isSubmit = true;
					} else {
						this.$util.redirectTo('/pages/verification/goods/goods', { vg_id: data });
					}
				}
			});
		},
		scanCode() {
			// 只允许通过相机扫码
			uni.scanCode({
				onlyFromCamera: true,
				success: res => {
					if (res.scanType == 'WX_CODE' && res.errMsg == 'scanCode:ok') {
						try {
							this.$util.redirectTo('/' + res.path);
						} catch (e) {
							this.$util.showToast({
								title: e.message
							});
						}
					} else {
						this.$util.showToast({
							title: res.errorMsg
						});
					}
				}
			});
		}
	},
	onHide() {
		this.isSubmit = true;
	}
};
</script>

<style lang="scss">
	page{
		background: #fff;
	}
.worker-info {
	display: flex;
	padding: $ns-padding;
	margin-top: $ns-margin;
	image {
		width: 135rpx;
		height: 135rpx;
	}
	view {
		.name {
			height: 67.5rpx;
			line-height: 67.5rpx;
		}
	}
}
.operate {
	display: flex;
	justify-content: space-between;
	input {
		height: 54rpx;
		width: 70%;
		padding: 0;
	}
	button {
		height: 54rpx;
		line-height: 54rpx;
	}
}
.code {
	border-bottom: 2rpx solid $ns-border-color-gray;
}
</style>
