<template>
	<view>
		<view class="qrcode ns-margin-top ns-margin-bottom">
			<view>请将二维码出示给核销员</view>
			<view><image v-if="info.path" :src="$util.img(info.path)"></image></view>
		</view>
		<view class="ns-padding detail">
			<view class="title ns-padding-left ns-margin-top ns-margin-bottom">核销详情</view>
			<view>
				<view class="ns-margin-right">核销总次数：</view>
				<view v-if="info.confine_use_number > 0">{{ info.confine_use_number }}</view>
				<view v-else>不限次数</view>
			</view>
			<view v-if="info.confine_use_number > 0 && info.confine_use_number - info.use_number > 0">
				<view class="ns-margin-right">剩余次数：</view>
				<view>{{ info.confine_use_number - info.use_number }}</view>
			</view>
			<view>
				<view class="ns-margin-right">有效日期：</view>
				<view v-if="info.end_time != 0">到{{ $util.timeStampTurnTime(info.end_time) }}之前有效</view>
				<view v-else>不限制</view>
			</view>
		</view>
		<view class="ns-padding notes" v-for="(item, index) in virtualGoodsVerificationList" :key="index">
			<view class="title ns-padding-left ns-margin-top ns-margin-bottom">核销记录</view>
			<view>
				<view class="ns-margin-right">核销员：</view>
				<view>{{ item.verification_name }}</view>
			</view>
			<view>
				<view class="ns-margin-right">核销次数：</view>
				<view>{{ item.num }}</view>
			</view>
			<view>
				<view class="ns-margin-right">核销日期：</view>
				<view>{{ $util.timeStampTurnTime(item.create_time) }}</view>
			</view>
		</view>
	</view>
</template>

<script>
import http from 'common/js/http.js';
export default {
	data() {
		return {
			vgId: '',
			info: [],
			virtualGoodsVerificationList: []
		};
	},
	onLoad(e) {
		this.vgId = e.vg_id;
		this.getWapVirtualGoodsShare();
	},
	mixins: [http],
	methods: {
		getWapVirtualGoodsShare() {
			this.sendRequest({
				url: 'System.Order.getWapVirtualGoodsShare',
				data: {
					vg_id: this.vgId
				},
				success: res => {
					this.info = res.data;
					if (this.vgId != '') {
						this.getVirtualGoodsVerificationList();
					}
				}
			});
		},
		getVirtualGoodsVerificationList() {
			this.sendRequest({
				url: 'System.Order.virtualGoodsVerificationList',
				data: {
					vg_id: this.vgId
				},
				success: res => {
					this.virtualGoodsVerificationList = res.data;
				}
			});
		}
	}
};
</script>

<style lang="scss">
page {
	background: #fff;
}
.qrcode {
	display: flex;
	flex-direction: column;
	view {
		text-align: center;
		margin-bottom: $ns-margin;
	}
	image {
		width: 300rpx;
		height: 300rpx;
	}
}
.title {
	border-left: 6rpx solid $base-color;
	line-height: 1.5;
}
.detail view,
.notes view {
	display: flex;
}
</style>
