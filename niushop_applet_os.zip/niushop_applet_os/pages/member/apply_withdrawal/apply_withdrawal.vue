<template>
	<view>
		<template v-if="!isDisabled">
			<view class="panel can-apply">
				<text>可提现金额：</text>
				<text class="ns-text-color">¥{{ account }}</text>
			</view>
			<view class="panel side-nav">
				<view v-if="isEmpty">
					<navigator url="/pages/member/account/account?goback=apply_withdrawal" class="apply-account">
						<text>请添加提现账号</text>
						<text class="iconright iconfont ns-text-color-gray"></text>
					</navigator>
				</view>
				<view v-if="!isEmpty">
					<navigator url="/pages/member/account/account?goback=apply_withdrawal" v-for="(item, index) in accountList1" :key="index">
						<text>
							{{ item.branch_bank_name }}
							<br />
							{{ item.account_number }}
						</text>
						<text class="iconright iconfont ns-text-color-gray"></text>
					</navigator>

					<navigator url="/pages/member/account/account?goback=apply_withdrawal" v-for="(item, index) in accountList2" :key="index">
						<text>{{ item.account_type_name }}</text>
						<text class="iconright iconfont ns-text-color-gray"></text>
					</navigator>
					<navigator url="/pages/member/account/account?goback=apply_withdrawal" v-for="(item, index) in accountList3" :key="index">
						<text>
							{{ item.account_type_name }}
							<br />
							{{ item.account_number }}
						</text>
						<text class="iconright iconfont ns-text-color-gray"></text>
					</navigator>
				</view>
			</view>

			<input class="uni-input money" type="digit" placeholder="请输入提现金额" v-model="money" />
			<view v-if="poundage != '' && cash != ''" class="tip-text ns-text-color">
				最低提现金额为
				<text id="Minaamountcash">{{ cash }}</text>
				元，必须为
				<text id="IntTimes">{{ poundage }}</text>
				的整数倍
			</view>
			<view v-else class="tip-text">
				最低提现金额为
				<text id="Minaamountcash">0</text>
				元 ，必须为
				<text id="IntTimes">1</text>
				的整数倍
			</view>
			<view class="btn-wrap">
				<button @click="btnSave()" type="primary">立即申请</button>
				<view v-if="withdrawMessage != ''" class="horn-text">注:{{ withdraw_message }}</view>
			</view>
		</template>
		<loading-cover ref="loadingCover"></loading-cover>
		<ns-login ref="login" href="apply_withdrawal"></ns-login>
	</view>
</template>

<script>
import http from 'common/js/http.js';
import loadingCover from '@/components/loading/loading.vue';
import nsLogin from 'components/ns-login/ns-login.vue';
export default {
	components: {
		loadingCover,
		nsLogin
	},
	data() {
		return {
			balanceConfig: {
				value: {
					withdraw_multiple: 0
				}
			},
			poundage: '',
			cash: '',
			withdrawMessage: '',
			account: 0,
			accountList1: [],
			accountList2: [],
			accountList3: [],
			bankAccountId: 0,
			isEmpty: false,
			money: '',
			isDisabled: false,
			wxAccountType : 1
		};
	},
	mixins: [http],
	onShow() {
		var isLogin = false;
		// #ifdef H5
		getApp().checkLogin(() => {
			isLogin = true;
			setTimeout(() => {
				this.$refs.login.clickLogin();
			}, 100);
		});
		// #endif
		// #ifdef MP
		getApp().$vm.checkLogin(() => {
			isLogin = true;
			this.$refs.login.clickLogin();
		});
		// #endif

		if (isLogin) return;
		this.getBalanceConfig();
		this.getAccount();
		this.getAccountList();
	},
	onHide() {
		this.accountList1 = [];
		this.accountList2 = [];
		this.accountList3 = [];
	},
	methods: {
		getBalanceConfig() {
			this.sendRequest({
				url: 'System.Config.balanceWithdraw',
				success: res => {
					if (res.code == 0) {
						let list = res.data;
						this.balanceConfig = list;
						this.poundage = list.value.withdraw_multiple;
						this.cash = list.value.withdraw_cash_min;
						this.withdrawMessage = list.value.withdraw_message;
						if (this.$refs.loadingCover == undefined) return;
						this.$refs.loadingCover.hide();

						if (this.balanceConfig.is_use == 1 || this.balanceConfig['value']['withdraw_multiple'] > 0) {
							this.isDisabled = false;
						} else {
							this.isDisabled = true;
							uni.showModal({
								title: '操作提示',
								content: '商家已禁止提现！',
								showCancel: false,
								success: res => {
									if (res.confirm) {
										this.$util.redirectTo('/pages/member/index/index', {}, 'tabbar');
									}
								}
							});
						}
					}
				}
			});
		},
		getAccount() {
			this.sendRequest({
				url: 'System.Member.memberBalance',
				success: res => {
					if (res.code == 0) {
						this.account = res.data;
					}
				}
			});
		},
		getAccountList() {
			this.sendRequest({
				url: 'System.Member.defaultAccount',
				success: res => {
					if (res.code == 0) {
						let list = res.data;
						if (list != null && list.length > 0) {
							this.bankAccountId = list[0].id;
							this.wxAccountType = list[0].wx_account_type;
							for (var i = 0; i < list.length; i++) {
								if (list[i].account_type == 1) {
									this.accountList1.push(list[i]);
								} else if (list[i].account_type == 2) {
									this.accountList2.push(list[i]);
								} else if (list[i].account_type == 3) {
									this.accountList3.push(list[i]);
								}
							}
							this.isEmpty = false;
						} else {
							this.isEmpty = true;
						}
					}
				}
			});
		},
		btnSave() {
			var bank_account_id = this.bankAccountId;
			var wx_account_type = this.wxAccountType;
			var cash = this.money;
			var MaxCashAmount = this.account;
			var Minaamountcash = this.poundage != '' && this.cash != '' ? this.cash : 0;
			var IntTimes = this.poundage != '' && this.cash != '' ? this.poundage : 1;
			if (bank_account_id == null || bank_account_id == '') {
				this.$util.showToast({
					title: '未添加提现账号'
				});
				return;
			}

			var reg = /^\+?[1-9][0-9]*$/;
			if (reg.test(cash)) {
				cash = Number(cash);
				MaxCashAmount = Number(MaxCashAmount);
				Minaamountcash = Number(Minaamountcash);
				if (cash > 0) {
					if (cash <= MaxCashAmount) {
						if (cash >= Minaamountcash) {
							if (cash % parseInt(IntTimes) == 0) {
								this.sendRequest({
									url: 'System.Member.addWithdrawApply',
									data: {
										bank_account_id: bank_account_id,
										cash: cash,
										wx_withd_type : wx_account_type
									},
									success: res => {
										if (res.data > 0) {
											this.$util.showToast({
												title: '已提交申请，等待审核'
											});
											setTimeout(() => {
												this.$util.redirectTo('/pages/member/balance/balance');
											}, 1500);
										} else {
											this.$util.showToast({
												title: res.message
											});
										}
									}
								});
							} else {
								this.$util.showToast({
									title: '提现金额必须是' + IntTimes + '的整数倍'
								});
								return false;
							}
						} else {
							this.$util.showToast({
								title: '提现金额必须大于' + Minaamountcash
							});
							return false;
						}
					} else {
						this.$util.showToast({
							title: '可提现金额最大为' + MaxCashAmount
						});
						return false;
					}
				} else {
					this.$util.showToast({
						title: '当前不可提现'
					});
					return false;
				}
			} else {
				this.$util.showToast({
					title: '输入金额不合法'
				});
				return false;
			}
		}
	}
};
</script>

<style lang="scss">
input {
	height: 46rpx;
	border: 0;
	padding: 40rpx;
	font-size: $ns-font-size-base;
}

.tip-text {
	padding: 40rpx 20rpx;
}

.btn-wrap {
	text-align: center;
}

.panel {
	margin-bottom: 40rpx;
	padding: 40rpx;
	background: #fff;
}

.side-nav {
	padding: 0;
}

.side-nav > view {
	position: relative;
}

.side-nav > view navigator {
	display: flex;
	justify-content: space-between;
	align-items: center;
	padding: 20rpx 40rpx;
}

.side-nav > view navigator text {
	line-height: 50rpx;
}

.side-nav > view navigator .iconfont {
	line-height: 90rpx;
}

.side-nav > view navigator.apply-account .iconfont {
	line-height: 50rpx;
}
.money {
	background: #fff;
}
.can-apply {
	border-top: 2rpx solid $ns-border-color-gray;
}
</style>
