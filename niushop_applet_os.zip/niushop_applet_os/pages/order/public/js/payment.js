export default {
	methods: {
		showPopup(ref) {
			this.$refs[ref].open();
		},
		closePopup(ref) {
			this.$refs[ref].close();
		},
		/**
		 * 获取代付款订单数据
		 */
		getOrderData() {
			let data = uni.getStorageSync('orderCreateData');
			if (!data) {
				this.$util.showToast({
					title: '未获取到创建订单所需数据!！',
					success: () => {
						setTimeout(() => {
							this.$util.redirectTo('/pages/index/index/index', {}, 'tabbar');
						}, 1500)
					}
				});
				return;
			}
			this.sendRequest({
				url: 'System.Order.orderDataCollation',
				data: {
					data
				},
				success: res => {
					if (res.data) {
						var orderData = res.data;
						this.orderCreateData = JSON.parse(data);
						this.orderCollationData = orderData;
						if (this.orderCollationData.pickup_point_list == undefined) this.orderCollationData.pickup_point_list = [];
						if (this.orderCollationData.express_company_list == undefined) this.orderCollationData.express_company_list = [];
						this.is_virtual = orderData.is_virtual;
						this.address = orderData.address;
						if (this.address) this.address.address_info = this.address.address_info.replace(/&nbsp;/g, " ");
						this.payType.list = orderData.pay_type;
						this.goodsList = orderData.goods_sku_array;
						this.giftList = orderData.gift_array;
						this.couponList.list = orderData.coupon_list;
						this.expressType = orderData.express_type;
						this.expressService.title = this.expressType[0] != undefined ? this.expressType[0].type_name : '';

						this.orderData.is_virtual = this.is_virtual;
						this.orderData.pay_type = this.payType.list[0] != undefined ? this.payType.list[0]['type_id'] : 0;
						this.orderData.coupon_id = this.couponList.list[0] != undefined ? this.couponList.list[0].coupon_id : 0;
						this.orderData.shipping_info.shipping_type = this.expressType[0] != undefined ? this.expressType[0].type_id :
							0;
						this.orderData.order_type = this.orderCreateData.order_type;
						this.orderData.goods_sku_list = this.orderCreateData.goods_sku_list;
						this.orderData.promotion_type = this.orderCreateData.promotion_type;
						this.orderData.address_id = orderData.address != undefined ? orderData.address.id : 0;
						this.orderData.promotion_info = this.orderCreateData.promotion_info != undefined ? JSON.stringify(this.orderCreateData
							.promotion_info) : '';

						if (this.orderCollationData.order_type == 6) {
							this.$set(this.orderData, 'presell_info', {
								is_full_payment: 0
							});
						}

						this.orderCalculate();

					} else {
						this.$util.showToast({
							title: '未获取到创建订单所需数据!！',
							success: () => {
								setTimeout(() => {
									this.$util.redirectTo('/pages/index/index/index', {}, 'tabbar');
								}, 1500)
							}
						});
					}
				}
			})
		},
		/**
		 * 订单计算
		 */
		orderCalculate() {
			this.getValue();
			this.sendRequest({
				url: 'System.Order.orderCalculate',
				data: {
					data: JSON.stringify(this.orderData)
				},
				success: res => {
					if (res.code == 0) {
						let data = res.data;
						this.taxMoney = data.tax_money.toFixed(2);
						this.totalMoney = data.total_money.toFixed(2);
						if(data.shipping_info.shipping_type == 3){
							this.shippingMoney = data.shipping_money;
						}else{
							this.shippingMoney = data.shipping_money.toFixed(2);
						}						
						this.goodsMoney = data.goods_money.toFixed(2);
						this.promotionMoney = data.promotion_money.toFixed(2);
						this.payMoney = data.pay_money.toFixed(2);
						this.pointMoney = data.offset_money_array.point.offset_money.toFixed(2);
						this.couponMoney = data.coupon_money;
						if (data.order_type == 6) {
							this.payMoney = parseFloat(data.presell_order_pay_money).toFixed(2);
							this.orderData.pay_money = data.presell_order_pay_money;
						}
					}
					if (this.$refs.loadingCover == undefined) return;
					this.$refs.loadingCover.hide();
				}
			})
		},
		/**
		 * 订单创建
		 */
		orderCreate() {
			this.getValue();
			if (this.verify()) {
				if (this.is_sub) return;
				this.is_sub = true;
				this.sendRequest({
					url: 'System.Order.orderCreate',
					data: {
						data: JSON.stringify(this.orderData)
					},
					success: res => {
						if (res.code == 0) {
							uni.removeStorage({
								key: 'orderCreateData',
								success: () => {
									// 如果是购物车结算 订单创建成功清除购物车中的结算商品
									if (this.orderCreateData.order_tag == 2) {
										this.sendRequest({
											url: 'System.Goods.deleteCartByGoods',
											data: {
												goods_sku_list: this.orderCreateData.goods_sku_list
											}
										})
									}

									if (this.orderData.pay_type == 4 || this.payMoney == 0) {
										this.$util.redirectTo('/pages/order/list/list', {}, '', 'redirectTo');
									} else {
										this.$util.redirectTo('/pages/pay/pay/pay', {
											out_trade_no: res.data.out_trade_no
										}, '', 'redirectTo');
									}
								}
							});
						} else {
							this.is_sub = false;
							this.$util.showToast({
								title: res.message,
							})
						}
					}
				})
			}
		},
		verify() {
			var data = this.orderData;
			if (data.is_virtual == 0) {
				if (data.address_id == 0) {
					this.$util.showToast({
						title: '请先选择收货地址',
					})
					return false;
				}
				if (data.pay_type == 0) {
					this.$util.showToast({
						title: '商家未配置支付方式',
					})
					return false;
				}
				// 如果用户选择商家配送的话 不考虑配送方式有没有开启
				if (data.pay_type != 4) {
					if (data.shipping_info.shipping_type == 0) {
						this.$util.showToast({
							title: '商家未启用配送方式',
						})
						return false;
					}
				}
				if (data.shipping_info.shipping_type == 2 && data.shipping_info.pick_up_id == 0) {
					this.$util.showToast({
						title: '请先选择自提点',
					})
					return false;
				}
			} else {
				if (data.user_telephone.search(/^1([38][0-9]|4[579]|5[0-3,5-9]|6[67]|7[0135678]|9[189])\d{8}$/) == -1) {
					this.$util.showToast({
						title: '请输入正确的手机号',
					})
					return false;
				}
			}
			if (this.isNeedInvoice) {
				if (this.invoiceData.invoice_title.search(/[\S]+/)) {
					this.$util.showToast({
						title: '请填写发票抬头',
					});
					return false;
				}
				if (this.invoiceData.taxpayer_identification_number.search(/[\S]+/)) {
					this.$util.showToast({
						title: '请输入纳税人识别号',
					});
					return false;
				}
				if (this.invoiceType == 2) {
					if (this.invoiceData.opening_bank.search(/[\S]+/)) {
						this.$util.showToast({
							title: '请输入开户银行',
						});
						return false;
					}
					if (this.invoiceData.bank_account.search(/[\S]+/)) {
						this.$util.showToast({
							title: '请输入银行账号',
						});
						return false;
					}
					if (this.invoiceData.business_address.search(/[\S]+/)) {
						this.$util.showToast({
							title: '请输入企业地址',
						});
						return false;
					}
					if (this.invoiceData.business_tel.search(/[\S]+/)) {
						this.$util.showToast({
							title: '请输入企业电话',
						});
						return false;
					}
				}
			}
			return true;
		},
		getValue() {
			if (this.isNeedInvoice) {
				if (this.invoiceType == 1) {
					this.orderData.buyer_invoice = this.invoiceData.invoice_title + '$' + this.orderCollationData.invoice_info.order_invoice_content_list[
						this.invoiceData.invoice_content] + '$' + this.invoiceData.taxpayer_identification_number;
				} else {
					this.orderData.buyer_invoice = this.invoiceData.invoice_title + '$' + this.orderCollationData.invoice_info.order_invoice_content_list[
							this.invoiceData.invoice_content] + '$' + this.invoiceData.taxpayer_identification_number + '$' + this.invoiceData
						.opening_Bank + '$' + this.invoiceData.bank_account + '$' + this.invoiceData.business_address + '$' + this.invoiceData
						.business_tel;
				}
			} else {
				this.orderData.buyer_invoice = '';
			}
		},
		/**
		 * 选择支付方式
		 * @param {Object} item
		 * @param {Object} index
		 */
		selectPayType(item, index) {
			this.orderData.pay_type = item.type_id;
			this.payType.index = index;
			this.closePopup('payType');
			this.orderCalculate();
		},
		/**
		 * 选择优惠券
		 * @param {Object} item
		 * @param {Object} index
		 */
		selectCoupon(item, index) {
			if (this.orderData.coupon_id == item.coupon_id) {
				this.orderData.coupon_id = 0;
				this.couponList.index = -1;
			} else {
				this.orderData.coupon_id = item.coupon_id;
				this.couponList.index = index;
			}
			this.closePopup('coupon');
			this.orderCalculate();
		},
		/**
		 * 切换配送方式
		 * @param {Object} item
		 */
		selectExpressType(item) {
			this.orderData.shipping_info.shipping_type = item.type_id;
			this.expressService.title = item.type_name;
			this.orderCalculate();
		},
		/**
		 * 选择物流公司
		 * @param {Object} item
		 */
		selectShippingCompany(item) {
			this.orderData.shipping_info.shipping_company_id = item.co_id;
			this.orderCalculate();
		},
		/**
		 * 选择自提点
		 * @param {Object} item
		 */
		selectPickupPoint(item) {
			this.orderData.shipping_info.pick_up_id = item.id;
			this.orderCalculate();
		},
		/**
		 * 选择配送时间
		 */
		selectShippingTime(item) {
			this.orderData.shipping_info.shipping_time = item.t;
			this.shippingTimeText = '预计' + item.y + '-' + item.m + '-' + item.d + item.w;
			this.orderCalculate();
		},
		/**
		 * 选择配送时间段
		 * @param {Object} item
		 */
		selectShippingTimeOut(item) {
			if (!this.orderData.shipping_info.shipping_time) {
				this.$util.showToast({
					title: '请先选择配送时间',
				});
				return;
			}
			this.orderData.shipping_info.distribution_time_out = item;
			this.orderCalculate();
		},
		/**
		 * 是否需要发票
		 * @param {Object} e
		 */
		needInvoice(e) {
			this.isNeedInvoice = e.target.value;
			this.orderCalculate();
		},
		/**
		 * 选择发票内容
		 */
		selectInvoiceContent(index) {
			this.invoiceData.invoice_content = index;
		},
		/**
		 * 积分使用数
		 * @param {Object} e
		 */
		pointChange(e) {
			if (!isNaN(e.detail.value)) {
				if (e.detail.value > 0) {
					if (e.detail.value > this.orderCollationData.max_use_point) this.orderData.point = this.orderCollationData.max_use_point;
					else this.orderData.point = e.detail.value;
				} else {
					this.orderData.point = 0;
				}
			} else {
				this.orderData.point = '';
			}
			this.orderCalculate();
		},
		selectAddress(){
			this.$util.redirectTo('/pages/member/address/address', {back: '/pages/order/payment/payment'});
		}
	},
	computed: {
		tailMoney() {
			// 计算预售订单尾款
			if (this.orderCollationData.order_type == 6) {
				let tailMoney = (this.goodsList[0].sku_price - this.goodsList[0].presell_price).toFixed(2);
				return tailMoney;
			}
		}
	},
	watch: {
		'orderData.presell_info.is_full_payment': function(value) {
			this.orderCalculate();
		}
	}
}
