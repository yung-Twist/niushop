<template>
	<view class="cart-container">
		<block v-if="cartList.length">
			<scroll-view scroll-y="true">
				<!-- <view class="cart-header">
					<view class="iconfont icondianpu"></view>
					<text>{{ shopName }}</text>
					<view class="cart-operation" @click="cartOperation">{{ operation == 'settlement' ? '编辑' : '完成' }}</view>
				</view> -->
				<view class="cart-store-header">
					<view class="cart-store-left">
						<!-- <checkbox class='round blue' :value="index" style="zoom:80%;"></checkbox> -->
						<image src="../../../static/tarbar/storeA.png" mode="" class="store-icon"></image>
						<text class="store-name">{{shopName}}</text>
					</view>
					<view class="store-edit"  @click="cartOperation">{{ operation == 'settlement' ? '编辑' : '完成' }}</view>
				</view>
				<view class="cart-wrapper">
					<block v-for="(item, index) in cartList" :key="index">
						<view class="cart-goods">
							<view class="iconfont" :class="item.checked ? 'iconyuan_checked' : 'iconyuan_checkbox'" @click="singleElection(index)"></view>
							<navigator class="goods-img" :url="'/pages/goods/detail/detail?goods_id=' + item.goods_id">
								<image :src="$util.img(item.picture_info.pic_cover_small)" mode="aspectFill"></image>
							</navigator>
							<view class="goods-info">
								<navigator :url="'/pages/goods/detail/detail?goods_id=' + item.goods_id" class="goods-name">{{ item.goods_name }}</navigator>
								<text class="sku" v-if="item.sku_name">{{ item.sku_name }}</text>
								<view class="goods-sub-section">
									<text class="goods-price ns-text-color-red">
										<text class="unit">￥</text>
										{{ item.show_price.toFixed(2) }}
									</text>
									<uni-number-box
										:min="item.min_buy > 0 ? item.min_buy : 1"
										:max="item.max_buy > 0 ? item.max_buy : item.stock"
										:value="item.num"
										:modifyFlag="modifyFlag"
										size="small"
										@change="cartNumChange($event, index)"
										:index="index"
									/>
								</view>
							</view>
						</view>
					</block>
				</view>
			</scroll-view>
		</block>
		<block v-else>
			<view class="cart-empty">
				<image
					src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAfAAAAEeCAYAAAB14kcUAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyZpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQ1IDc5LjE2MzQ5OSwgMjAxOC8wOC8xMy0xNjo0MDoyMiAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTkgKFdpbmRvd3MpIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjA0QzdFM0VFRjdDQjExRTlCRUI1QzBFMDE5Njg0M0RBIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjA0QzdFM0VGRjdDQjExRTlCRUI1QzBFMDE5Njg0M0RBIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6MDRDN0UzRUNGN0NCMTFFOUJFQjVDMEUwMTk2ODQzREEiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6MDRDN0UzRURGN0NCMTFFOUJFQjVDMEUwMTk2ODQzREEiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz4fYpjdAAAobklEQVR42uydCZRU1ZnHb4uCsiu7IiAuo2wiq0sc445BQzQqxugI4xLHYzIhZsaJOknMouNMojOT8TiOUUhM4joqbmDUOC4nbixCC8iOCrIKvQG9UvN99W6boujuuq+6lvvq/X7n/E91Vd1X/ereW+//vruWJRIJAwAAxeeXv/xlpiTniR60f18tmtNW4ptuuolMLWH2IwsAACKDmvcAqwfJDgwcAACiwYBW/gYMHAAAADBwAAAAwMABAAAAAwcAAIgsZUwjyx/Tpk0jEwAgFCNHjmyeKpbtILWNoqvLy8uTU8xmzZpFphKBAwBAAWiPeRvDFLPYsD9ZUHBOF50j6iH6VLRU9KForWgP2QMAOaCMLMDAIXd0Fz0i+kor7+9KMXN9LLePn5B1ALHiGhtB98/y+A2i68hGDBxyx6MmWAaxNTqLxlmlUpli7Eus1Nw3k6UApUd5efmLppUm9JEjRybS0hJpY+CQZ07LYN5toU3tJ1ml8nlKlF6eYvLbyW4AAAwccsN5efjMXqIvW6Wy0UbpH6ZE62ru1RQDAAAGDuHoVsD/1bzRwVlpr68z+zbF6/PdFA+UCtOnT9eZNVNF3xCdKOoj2ip6xwRjUB6bOXMmg0UBAwdnVnlwDkOsUgfR6YVsjdm3KX65qJ5ig4iZ91B5eFw0Nu0tNfELrG6SdJeKia8hxyDqMA+8MOgAtlpPy/8o0YWiW+15LhbV2Ej9t6K/F51gmJYC/pv32y2Ydzr6/ts2fRTZmPL3JkoeA4fC/Oi+LYrKsncHiIaLrhT9u2iBaL3oPrPvYDqAYpu3XsceE/V1PETTPWaPixrXWOPWqWJXU/oYOBSGX4u+Jvoooud/qOh60Z9tlD7dGj1AsbnM7Dv98gnRCFEn+/h42vvj7HGRQqeYiQaIBtrpZhBj6AMvLM9aDREdb6Pckfbx2AgZop7zQ6JbRP8oepqihSJyZdrzJ2fOnHlpynMdsDlVIm7tBrok7bg/kH2AgUMY1lnNTnlNzfsYGy2kSvvqfG0p0f7zp0R/MkHT3lqKFopAevR9eyvpbk8z8OPJOsDAIRc0mL9M73os5XVdoe24lEi9+XGgR+d+hmiR6Hsm6CoAKCS9056vaCXdyrTnvcg6wMAhn+ga6fOtUumZFqk3m3uxLko61/0B0Skm6Cuvo+igQGxLM/Gj7Y1wOkenPf+crAMMHIpBhegtq1QGpJj5MNEo+9i1QOc1TTRYNMWw+hsUhnmiSSnPf2z2bipv5odpzxeRdYCBg09stHol5TUdvDMkLVIfZtUxD+dwuv3/um1qJUUCeebhNAO/ePr06bqmgfZ56yJKOlbjR6JLWzgOAAMHr9H552utnksr/6PN3s3wo+wFr70Lt0wQzRWdaYJuAIB8oWY9w+w9mG2qVVtR+6NkHUQZ5oHHm0bRMhPMmdUI5WITjIQ/2ATLTt5v2re7ma5F/VvDKm6QR+za5jqne4vjIZruMtZEBwwcShFt9n7eBIPRdAGXvzEtDwpy4eui75OlkGcTXy0PJ5t9B3umo++fbNMDYOBQ0uhocu0r1Kb1G0Q7sviMO03QpA6QbxPXena5CbqKPjPBpjwb7fNv6vuYN5QKZYlEglzIE9OmTSvFr3WYCZrFzwh5nEbwYw3TywAKyqxZs8gEInCAJLqJwrmi/wx5nA6QoykdAAADhyKig990m9GfhDxO103vS/YBAGDgUFx05Pq9IdJ3F/0D2QYAgIFD8dFI/NUQ6XXTk55kGwAABg7FpckE2zK6zhdX8/4bsg0AAAOH4qPTdG4Okf4KsgwAAAMHP5gpKndMO97suzMUAABg4FAEtCn9rhDpzyXLAAAwcPCDx437etQYOAAABg6e0GBN3IXxZBcAAAYO/vC8Y7p+ov5kFwAABg5+8JYJ+sNdOJ7sAgDIjv3Jgvbx9NNPkwl7s1O0QnScQ1pdH/0lsgwAAAOPFFOmTOlhDWyiaLPoktmzZ79ZAl9tsaOBj6QWAABkB03oxeVsa96K9glfXSLfy3U+OAYOAICBR5KOac8PKJHvtdQx3XHUQQAADNw3ek+ZMuVrosEx/O6uEXhn0VCqCgAABu4Lh4mWiHSE2zIx8cnt/UD5jFGiaaIoTL1aI9rlmJZmdAAADNwb1LD72r8PEj3VHhOXY/9WHhaYYL3xRREw8T164+KYdgTVBQAAA/cFNdvUudAdszVxOUYHtv1a1MG+pDcGX45AHrg2ow+nugAAYOC+ME/0LVGiBRM/P6R5PyAqS3m5VvReBPLgQ8d0NKEDAGDgXvGg6NoWTPxxMeYh9vlCUX2a8bdl3pr24tmzZ6+JwPdf4pjuGFEnqgsAAAbuDWK0LZm49omPtu9rP/Eo0aWiM+T5Pda8NSq9vwXzvkjSvBCRr+/ahK6LCf0VtQUAIBysxFYAExdDNtaQtR/7M9EbKe8vl4flaYeNMH/p8242769HyLyVDaIKUU+HtPp9F1NbAAAwcB9NfJ6Ntl+S59szHPKyaKNogAmmY02VY56P4FfXfvAvOaRrqx+8m+gU0RjRkaI+JmjFACgFdAveatHHJuh2elf0EdkCGLhfJr5IHhY5pt1mm9HV/BbI808j+rXLszRwrZcXiqaLzjT7rlgHUMqsFf1G9JDoU7IDWqMskUiQC+3A7kZ2qgn6ug9sIYlm8DvN/dthESOfIQ8nmr37w5vREekPeLwByg2iex0vWEPtd/ym6HbDCm0A9dbEf2KCFrmsmDVrFjlJBA5t+bioVxvvXypGXC5G+0pI8z5LHu7OkOxcE2yE4iOuI9GH2Cj8XnszBABBy9P1oqmiGTYqB/gCRqHnhl4Oafpm8bl98/S5hcJ1JLpG3vMxb4AWOVgDaRNMK6U7CTDwHDMvw/vaFLYwi89NnyfeEu96nC86WM+16e8AqhFAm1wjehYTh2ZoQs8N2tR9ehsmtNhOFwuFzhPXTUxMMHq9JXQE62ue542ORB9AFQHICdpl9oToIrP3cs2AgUOWVIqeacGA2/3BrcwTjxLajH42VQQgZ3xV9FPRLWQFBg4eIpG39nv9tWi+mPj6CH+VJZQmQM65WfSi6C2yAgOH/BuyLp96vP7oxJC3Zkjb2wRzxg8V7ZLnl0ZsFbZUPszlh3Xt2tUccADd5dnS1NRkGhoayIh2Ultba4o8BVfHL91nryl7KBEMHPJn3roxyRdLqeoiLRlWYzvLmrfS2QS7mF0UURNfYi8wWQ+Y7N+/vznppJPMMcccY7p06UKFgpJBbwIqKyvNqlWrzOLFi826devCHK5LEF8u+h05iYFD/sw7dVcxNWZtGn/Gvn+MvYveJgbdPCBtqQkGqDSvh94xwia+0wTLRB4R9sAOHTqYSZMmmQkTJpiysjIqE5QcWq979uxpxo0bl9TKlSvNc889ZyoqKlw/4jsYeHxhGllhzVvZLfrAvn+sCQZ5PS76kzz/rr4uJq0be7S2n/jkCGZFedgDtJn88ssvNxMnTsS8ITYcffTR5vrrrzcDBjhP3Bhv2M0PA4ec09p+3tqfvc4+H2P2ntM5vvkPuxXpdS2Y+JNi4lFbZjS0gU+ePDl5MQOIG507dzZXXHFFcryHI18l1zBwyB1qzK3t5+28q5ik/XULJq7rrU+IWH4sDZN44MCBZsyYMdQiiC3dunVLdh85cgo5hoFD7hhn9t3PO6v+6xQTb160YYvo/0o5Ah87diw1CGLPiBEjktG4S1JyCwOH3PGCNVpld7bmnWbi6mq6veZoeb4pYvmh+xs7z10aOpSNyAD2228/c8QRTmM/B5Fb8YRR6Plhgwl219K9sHUhlo/b+4Fh9hP3EDXvlaJhLom7d+9ODQIQevTo4ZJMF0boJKojxzBwyA1bxHSfIhu+oNzVwBsbG5NTyADizp49Tmu0JEyIFi4oHWhCLy71LUSqpWzgTujCFgDg/FvYYViNDQOHgvOy6D37ty6v+mAJf1fnkeiff/45NQPA/bewhZyKJzShF5HZs2fr7fXEmHxd5wh827ZtVA6IPbrM6vbt212SriK3MHDIggsvvLAtgyaD/sIa0S4TrO1OBA6QAW0+1/EgDqwgt+IJTehQKLSPbplLQgwcINTvYDW5hYED5BunZnQMHCDU72AluYWBA+Qbp73Ba2pqTH19PbkFscax/1uhCR0DB8g7S/Jw8QKIcwReK/qU3MLAAfINI9EBcmvgOgKdOeAYOEDe0SVmK3J48QIoSXQFth07drgkpf8bAwcoGE794ETgEGcqKipMU1OTS1L6vzFwgILh1IxOHzjEmRA3sETgGDgAETiAL4ToQmIVNgwcoGA4jUTfvXt3UgAYOAYOGDj4gfNI9C1b2KMB4onjALYaEwwMBQwcoCBo5/ZGl4SbN28mtyCWOHYhEX1j4AAFx6kffOvWreQUxA4dfe64D/hycgsDByg0Ts3oROAQR3QGhs4DJwIHDBx8xGkgGwYOcSTEADYicAwcoOA4NaHrKPTq6mpyC2JFiCmUROAYOEBRInCnNkJGokPcCLGIEYu4YOAABWen6GOXhDSjQ9xwbELXPQVY7QgDBygKDGQDyD4CZw10wMDBbwNnKhnEiYaGBlNVVeWSlOZzwMChaCzNYTQCUDLRdyKRIAIHDBy8ZrFLog4dOpBTEBvYhQwwcIhKBP5ZpkS1tbWuEQlA5AkxB5wIHDBwKBo6jezPmRJpnyBzwQEDJwIHDBz8wukiRD84YOB7oVMzqsgtwMChmDg1A4boFwSINI43q6zABhg4EIED+EJdXZ2pqanJ2e8GMHAAInCAAsAANsDAIUroKi0VObywAcTBwInAAQOHaEThIfZHBiACBwwcoEBkjCaamppMZWUlOQUljWNXkS6KwCA2wMAhGhF4yOgEIJI4DtZcL9pFbgEGDpGIwENc3ABKPQIn+gYMHIjAAXxh9+7dyWWDc3XDCxg4gDcROAYORN9E4ICBg1/okpCbcniBA4gcIbqIlpNbgIFDpKLwioqK5Gh0ACJwAAwc/CFjP7jOA9+xYwc5BSWJYxdREwYOGDhELgIPcZEDKNUI/BNRPbkFGDhEKgJXmEoGpYpj3ab/GzBwIAIH8IXq6mpTX+8UWNN8Dhg4eIdemDIudo6BQ4yjbwwcMHDwEl3BYgMGDnGEXcgAA4eok/HipBuaNDY2klMQVwNnFzLYi/3JAlCmT59+gTzMEI23L70vunvmzJnPF+gU9OJ0RlsJEolEsrmxb9++FBiUDI4j0BtE68gtIAKHdPP+mTw8Kzpd1NVK/37OvudFBB4yWgEopQh8jYjmJ8DAYS/zPl8ebm0jya02Oi9EBJ6raAUgEjS3KuXqBhcwcIgX33NIM8OXCJy54FBKhBjXQf83YOCwD+NylKa9ODUR0oQOpUSIG1IicMDAISvKCvA/nAbpEIFDKRHihnQ1uQUYOKQzzyHN+wU6l4zNhFVVVa6rVgGUkoHThA4YOOzDPTlKkwvoBwcMfF90oaNPyS3AwGEvZs6c+Zw8/LyNJD+3abyIwBVGokPMDNxpqWHAwCGeJn6bPEwRvSbaaaV/f9W+VyiYCw6xIcQe9wxggxZhJTZoNnFdyOXZIp8GETjEhoqKCtPU1JSz3wUQgQMUE+3nq82UyDFqAfCaEDeiROCAgYP3aD9fxi0TaUKHUiDEjSgROGDgEAkyRhs7d+40tbW15BTEJQJfQ24BBg5RgH5wiAWO0yFrRBvILcDAoSQi8BAXP4CoR+CryCnAwIEIHMATdPS5bmTiwHJyC1qDaWQQyQicgWwQZbQFSeeBFzsCf/311/P6PU877TQKmwgcYsQmURUGDqVMiPpbzAj8YNENIl2J8WNRnahatMy+doNNAxg4gHsUTh84RJkQXUDF6AM/UPQDE4x+v1d0vmiQqKOoq+hY+9q9Ns0tooMoVQwcwMnAdRqZTicDiCIh5oAXOgIfYoLdB+8Q9XRIr2l0L4X37LGAgUPMcdr7mGZ0iCqOdVddvpBNTQNFb4pGZHHsCHvsQEoXA4d44xR1YOBQ4gZeyCVUtdn8qRYMWNv6tYl8lE1zoP37Fvte+g2AfgbN6Rg4xBinfj8MHKJIQ0ODqaqqcklaSAP/rmh82mtqxkeJ7hSVm2AQW539+0773v+mHTPefhZg4EAEjoFDaaEDMBOJhEvSQq2Bfojon9Jee1p0saityer63iXW6FO52X4mYOAQx2uccej7YzEXiCIe7kL2DVGP1FMUTRO53GVomumirSmv9bCfCRg4EIW3O5IB8IYQLUeFisDPTXv+K+OwFkMKmvaetNcmUdIYOMSXjP3g2pdYXV1NTkGpGnihIvDRac9nZ/EZz6c9P56SxsCBCDxjFA4QJRzrrNOKhDmiX9rzj3Lwe+1HSWPgQATeJvSDQ4lG4IVcga0uB5/RkZLFwAGIwKFkqaurMzU1Nb4Z+Ma058dm8RlD055vprQxcCACJwKHuEXfyooCnlb6zfKULD5jctrzRZR2/mE7UfAVDVM2iA5r8yq3YoW58847yS2IBLoPuCOFXMTlJdEFKc9vFP27ce+D7y6akfbaXEobAwei8DYNXPdU3r17NzkFpUYhI/BHTLAhSfNc8D6imSZYyCXTPM0ym7ZPymuV9jMhz9CEDj6znCyAGJIwhe0D14Ekd6W9dpHoSbP3Ai/p6HtP2LSp3GUKuwkLBg7gaQQOEDfWi3YV+H9qk3l5Cyauv0HdG1x3GzvABKPNR9jX9L2vpx3zof0sKAA0oQMROIBfrCzC/9xtDft10aEpr/c2wd7gdzh8ho5ZudB+FhCBAxE4AAZewN/bl2wUHZYP7bH8ZjFwgC8uKE1kA8SM1UX832tFE0S3iioc0lfYtHrMOoqusNCEDj5TL/pEdARZATGi2F1H2gSuTeb3iS43wcYko0QD7Pu68MtiE0wV+4NoB0WGgQO0djHDwCFO+NIMrcZ8rxVg4ACRvZgBFIKmQtb50047jRzHwAHyGoFn5JRTTjEDBw4kt8Bb5s6dayorKzMl0y6jenILMHAoBda4JOrevbsZPnw4uQXe8swzz+TshhVAYRQ6+I7TkpIhNokAKDi6A5nuROYAXUaAgUPJsE7UgIFDlPF0FzLAwAHySqNxaEbHwKFEDHw1uQUYOJQSGVem0sFBjY2N5BQQgQMGDuARGS9qiUTCbN/OBkjgJ9u2bXNJpl1F68gtwMAhVhG4goGDrzjWTe0qohkJMHCIVwQeIsoBKCghWodWkluAgQMROIAnVFVVmYaGBpek9H8DBg4lx3rRLiJwiCIhBrARgQMGDiVHwjgscEEEDhg4YOAA/pGxeVGbKuvrWUYaImvgrMIGGDiUJPSDQykbeK3oU3ILMHCIZQQeMtoB8MnANfreQ24BBg6xjcAxcPCJPXv2mB07duSsfgNg4EAEDlAAdInfpqamnNVvAAwcoshWUQUGDlEixNRGInDAwCHeUTgGDj4RYlAlEThg4FDSZIxSdu7caWpra8kpiFoEzhQywMAh3hF4yIsmgA8ReI1oI7kFGDjEOgIPcdEE8CUCJ/oGDByIwDFw8AUdfa6j0B1YTm4BBg6ljlOkQhM6+IDeSOo8cCJwwMABjNFwZisROETFwB0hAgcMHGJBxmb0rVu3ukY+AHljy5YtrkmJwAEDBwxcqaurM+vXryenoKisXbuWCBwwcIAUFrkkmjdvHjkFRaOiosKsWbPGJalOH6PPBzBwiAVvuSRavHix2bRpE7kFRWHu3Lmu3ThvkluAgUNcWCD6LFMivXg++uijprq6mhyDgvLOO++YpUuXuiZ/gRwDDBziQkL0e5eEOgr4oYceMps3bybXIO/oTeNrr71m5syZ43qIrsD2NDkH2bI/WQAR5L9FM1zqr25ucv/995tx48aZiRMnml69epF7kFMaGxvN8uXLzRtvvGE2bgy1IurDIpqIAAOHWKGjg2aJrnG9wGqzpqpHjx6mT58+plOnTuQitDvirqmpSZq21rGQ6I47d5CLgIFDHLlNdJHokDAH6dKWjstbAuSTO0XMdYR2QR84RBXt2L6RbIAIMl90F9kAGDjEmUdEvyIbIELoUsCXiOrICsDAIe7oYLbfkQ0QASpEk0VryQrAwAGMaRJNE91HVoDH6NoFXxa9T1YABg6wt4nfILpWtJPsAM/4k2iscVwGGAADhzjya9FI0TNkBXiATgq/TnSWiHV9AQMHyID2L14omih63ATzbQEKyUcmGJtxjOgBE6weCJBzmAcOpcp7oqmibqJJolNFo0VDRT1EXckiaCe6ekuVCfq3dUvQt0UvixaTNYCBA7QfXaryCSsAgJKBJnQAAAAMHAAAADBwAAAAwMABAAAwcAAAAMDAAQAAwB2mkUHU6C86STRGdKxosH1N53UfbNPoht86P1dXv9KFXZaJForeNayIBblD96LX9QWGi/7KaoAJ1h7QtQbKTLCBSY0JVmVbaeui6g3RNrIQMHAodXRVtYtNsJPTcQ7pe1gdLhqf9l656HnR70VLyFoIiS7Ve4XobNHxJnMr5sFWWhcnpLyuq7Ppgi+vmGBb3PlkLWDgUCqoAV9jdWyOL8CqH5hgcwldP32mYRMUaB2NqKeLrhaNytFnltkbANVN9mbyNyZYerWCLAcX6AMH3+gp+qnoE9Evcmze6ejF81eij0U/NCyvCvveRP7I1sX/yKF5t4Q2w/+r/V8/t78DAAwcIoFGJNNM0D94m6h7Af93L9HtohX2HMoojtjXRY24dVOSHxfYTDXav4W6CBg4RIWjRG+ZoCm7fxHPY4A9B92Q4giKJZYMEb0meqjIdbGPrYs62O1IigUwcPARHRD0gehkj87pTBOMWv8axRMrLjHBuIjTPDqnL4kW2HMDwMDBC7Rp8G7Rw6IuHp6f9n8+JbrD0IwZh7qo4y4eM4XtunFFz0n3tv8FdREwcCg2HUW/E82IwIVdR6v/xp4zlB4dTDDy+7YImONN9ndDXYQkTCODYpj3bNGknDhsWZnp0qWLOeigg8wBBxxgEomEaWxsNLt37zY1NTW5OucrRQeJLhM1UYQlZd4a2V6Uq7p44IEHJtWpU6fkc62LtbW1ybqodTMHXG6CBWSmiOopQgwcoJAR7UPtMe8OHTqYQw891Bx22GGmb9++pmfPnsnXWkIvnhUVFWbr1q1mw4YNSe3Zsyfbf32xjcTVzBMUZUnUxfvaY9777bdfsh5qfezXr1+bdbGpqclUVlaaLVu2fFEX9bUs0d/PY7ZOckOJgQMUBO1P/mY2B+rF8bjjjjNHHHFEMrpxqtz772969+6dlB6rkdDatWvN0qVLTVVVVTanoee+xgRzxiHa/Ex0bTYH9ujRwxx77LHmyCOPdK6LauyHHHJIUnpsXV1dsi4uW7YseZOZBTrA8h7RdyjKGN+F5qhZB1pg2rRpZMJf0NHmD4c9qFu3buaEE04wQ4cOTTZJ5gKNwlevXm0WLlxodu4MvQBbwkY+T1GkkeV80bMmZJ93165dzejRo5PGrdF3LtDrrxr5/Pnzs+3ymWqCboBWmTVrFiWOgQMGnjU6z1unijmPNlezHjZsmBkzZkwyks4H9fX1yQvnRx99FPbQHaLRJlg1C6LFIBNMy+oV5iCNmseOHWs6dszP+DHt7lmwYEGydSjkNVk37hkrWo2Bxw9GoUMh6thvw5i3NkueffbZZsKECXkzb0UvxieddJI5/fTTw16YdXOKByna6AUsJhiD0StMHTnzzDOT9SRf5q1oPdf6ftZZZyUHwYVApzs+zLUcAwfIB9eZYPtPJ7p3724mT56cHBxUKIYMGWK+8pWvJJtIQ3CWybI/H4qGDkA80zWx1getF4MGDSrYCQ4cONCcd955ya6jEOjv63qKFwMHyCXNG5M4oRetc889NzlIqNAcfPDBZtKkSaZz585hDvs3UWeKORKoI94Vpi5qfdB6UfAfTc+e2Zj4T0wwvQxiBKPQI8LIkSP1ZksHrHxDdKIJ1kreKnrHBPsJP1ZeXr7Hs9P+B1Fvl4Q6j1vNO2QUnNsrvFwwzznnHDNnzpzkKGEHdO30b4cxBigaOlrbaW1z7cLRZvOQBppTdG0DbU6fO3duck0DB3rZ7/hjipoIHPwy76Hy8J7oD6ILrHkb+3iBff09m86n6PtGl4Q6YO3UU08t6gUzNRI/+eRQy7J/3wSLvIC/6F3h91wTn3jiiUWJvFuKxPV3EWL2xXdsSwNg4OCReb9tgpGmbaHvv+2RiV9jHNeVHjFiREH7vDOhfeI66tgRbWG4gprqNVcZx+blo446Kjll0Rf0d6G/D9f7T9G3KG4MHPwwby0fXXGpr+Mhmu4xe1wx0ZDBaZEM7e/Wed6+oVOGtBnTkRuprV7jZGrafTNx4kTvTl5/Hzq4M8R3ZcMTDBw8QNfeHpf22hMatIo62cf0RRzG2eOKiV4Fj3G9OLW2/GQx0SlDauKOjBINp7p6yfF6L+xaF/M5VSxb9PcRoi7qmgsnU+wYOBSfK9OeP1leXn6paImo3j5Otabe1nGFxmnvYl1WUpurfUWbUrUf0pGpVFcvudQlkZazT03n6QwePDj5e8nl7w8wcMgv6dH37a2ku72FqKOYnO2SSFday9XyqPlAz03XUHdkEtXVS5zKRcc85Gp51HzVxeHDnRt5zqPYMXAoPulTsFa0km5l2vNeRT7njKNudOUpn6PvZnTzFMcmfm3jZB6uX2h5ZBxgocat5ew7GoXrlrkOaPfVIIofA4fisi3t+dGtpEt//fMinvOpxmEQja5u5XgxKio6J9hxhLz+lsZTZb1ioktd1PINuXxpUdDfy+GHH+6a/ESKHwOH4jIv7fmPW0mXvr3loiKes9NomwEDBkSmEEKc62iqrFc4tTmHMMUo1cVRFH/pw0psfqObFKT24V08cuTIR03Q573KBCNOf2T2HajzcBHP2anTuF+/fpEphBDnOowq6xVOMyH69OkTmS/Uv3//nP4OgQgc8sejLUThOtp5qajePk5tIWp/tIjnPCRTAu1TDjGvtejoCGXHwXaHU2W9IuNqPNr/HWKmQdHR1Qodx2QMpvgxcCgidm1zndO9xfEQTXdZkddEzxgi6OItPo8+b8cNx0BqrVdkXA9VDdHn0efp6O/GcbOf3hQ/Bg7FN/HVJliYYX6GpPr+yTZ9McnodDowLGo4DnLqQo31ipKsi47n3JXix8DBHxOfILpc9JzoMxM0oW+0z3Vf6gkemLfThSMKo8+zPGcMPGIGrtMZS7QusqlJDGAQW3RMXJvFH7HymQa9xlBi4AEZ+2mi1Hweko4UPxE4QFhqMiVobGyM3JdyPOdGit+7m8m2EzQ0RO5L7dnjNMSlmuLHwAHCkvHCUVdXF7kvVVtb65Lsc4rfK7bnqFy9YteuXS7Jqih+DBwgLNsyJaisrDSJRCJSEU91tVNAs5Hi94rNGV2uqso1ovUC/d3U1NRQFwEDh7ywLlMCbY52vAh5gd5wNDU1uSRdTvF7xTIXQ9TyjQr6u6mvr8/J7xAwcIDQF81kaLR5c2S+0NatW12TYuB+sTLH5RuluriM4sfAAcLygUuijRuj08K3YcMG16RLKH6vWJLj8i06n332mWvSRRQ/Bg4Qlj+7JPrkk09cm6WLio5SXr9+vUtS7Uh9l+L3Ci2PjIMttHyjMDNC++o//fRT1+RvU/wYOEDoIME4NN9pP97HH3/s/ZdZu3at68V9oaiC4veK7bZc2kTLV8vZd/T34jhq/iP7OwQMHCA0c1wSLV261OsvoQOcli1z7kp8gWKPbl1csmSJ9zMjQtTF5yl2DBwgW55wSaQDchybp4vC6tWrzfbt23P6ncHPurhjxw6vW4S0nz7EwM/fUewYOEC2aN+j04jsefPmeTkPV5tVFy5c6Jp8gehDit1LdDDXYpeE8+fP93Jchv4+9HcS4vsygA0DB8gabYt8wDXyKS8v9++qv2hRmLnq/02Re83/uCTSRV0++OAD705efx8hWoIeorgxcID2cr9xHNSlke6WLVu8OXEd6RvipkLnIP2G4vaaWcZhhcBmswwxVSvv6O8ixE2FfscHKW4MHKC9aPj6X07heiJh3njjDbNz586in7RGYW+++WaYAU2/MMHWruAvWrHuca2LWv6OS+fm96Tl9/D666+H6WK6235XwMAB2s2/aRDhklAvmH/84x+LurmEbhLx6quvhtlsRUfg/Q/FHAn+Q7TJtR688sorZvfu3UU7Wf0d6DmE6MbR73YvxYyBA+QsoBX90DVxRUWFmTt3blHWSdf/+dJLLyXPIQQ36/WeYo5MFH5zmLo4Z86cokTiGnlrXQzR763cZNiBDAMHyDEaob7umlgHtemFs5B94trn+eKLL4Y177miP1C8keJh0SuuiXWTE60XmzZtKtgJ6tRKrf8hzfs10SMULwYOkGu0M/lq47BPeGo0rBexxYsX53WKmU4Zev/995NN9yH733VC7t9StJGsi1pu21wP0OZ0bRXSgZb5rIv62Vrf9YYhZNRfZb9TguKNH/uTBVAAVouuFT0a5oKm83J1ictx48aZww47LKcnpAvI6NxajfjDXmtFVxr2W44qupj4VSZYrazMyfUTieRI8HXr1pnx48ebgQMH5vSEdJEWrYsho+5mrjNsHYqBA+SZx0Qni74T5iC9qGmE3LdvXzNs2DAzePBgs99+2TUcacStq23pEq7t2ELyVtHLFGekeVF0hy1LZ7SL5eWXXza9e/c2w4cPT9bFDh06ZB1x64Y+WhfbsbXuv9jfFWDgAHnnu6Jeom+GPVD7xFWdOnVKXjgHDBhg+vXrZ7p06dLmcdo0rsdplKPmrZuotIP77EUTos8/iw4R/V3YA7dt25ac3tWxY0czaNAgc+ihhybrYteuXZ3qom6lq9F8iNkOLfF70S0UIwYOUCia+yB7iM7P5gP0ordixYqklAMPPNB07949eTFVKWrSKp3TncNpabq+9LcpwpKqi1qefUQXZ/MBWsdWrVqVVHNd7NatW7Ie6o1mal3Ufu0cTkt72tDvDRg4FAENgb9uDfGS9n6YGnQB5o7r/Fpt+t9D8ZUUuvD5ZSZoWbk2InVRR5trH34DxQeMQodimbheOP/V8/NUw75NdCPmXdIm/i3RzzyPaPXc7jJB9xPmDRg4FN0cdWGNy42fC1DoKLfzRD+nqEoeNUftE9cWoUoPz+9z0QWifzI0mwMGDh6hTYIniN7y6Jzm2nP6I8UTK/5XdLzo/zw6p1dFY0QvUDyAgYOPrBH9tegaE2KRjTyw3kZhGnlvoFhiyceiM0TTTXHn+uv/1taps0SfUCyAgYPPaNOgboU4VPQj0Y4C/m+9WH5fdJzoSYqCumiCLUiPKUJd1DWEf2D/N8ujAgYOkULXkfyJaLAJpvl8lMf/tdgE84D1puGXJtgCFaCZmpS6+PeihXn8X0tNMNPhCBOsNUBdhIwwjQx8NvL/stL+6KmiSaJRxnEJzFYiqw9Ec0RP2L8BXOrif1qNFH1DdI5otKhDOz633ASrwj0uWkA2Q1jKrrrqKnIBokRf0Yn24qlN3oeLdKF0XRxGV8/YYy+4Kh1Jvlykq74sEb1jitvHDqXFwaJT7Q2m1sVBJlgYpqtVcxRfbeud9q8vszeOb9v6CZCTCFynKcwQjU+pfABRROvvABP0I55CdkCR62J/0dGik8gOaAd6M/i+6G4TbMbzRR+4LmLwrOh0zBsAAMDLm0H16OesZycjcF2T+lbyBgAAIBKoZ7+rEfj3yAsAAIBIMUMNfBz5AAAAECnGMQ8cAAAgepSpgc8jHwAAACLF+2rg95APAAAAkeIeNXAdks6WiQAAANFAPfu55j7w20RTRK+JdpI3AAAAXrHTevRXrWeb/xdgALnLdjyEgIfAAAAAAElFTkSuQmCC"
					mode="aspectFill"
					class="empty-img"
				></image>
				<text class="ns-text-color-gray">购物车空空如也！</text>
				<block v-if="token != ''">
					<navigator open-type="switchTab" url="/pages/index/index/index" class="ns-text-color">去逛逛</navigator>
					<ns-goods-recommend ref="goodsRecommend"></ns-goods-recommend>
				</block>
				<block v-else><navigator url="/pages/member/index/index" open-type="switchTab" class="ns-text-color">去登录</navigator></block>
			</view>
		</block>

		<view class="cart-bottom" v-if="cartList.length">
			<view class="all-election" @click="allElection">
				<view class="iconfont" :class="checkAll ? 'iconyuan_checked' : 'iconyuan_checkbox'"></view>
				<text>全选</text>
			</view>
			<view class="settlement-info">
				<text v-show="operation == 'settlement'">
					合计：
					<text class="ns-text-color-red">
						￥
						<text>{{ totalPrice }}</text>
					</text>
				</text>
			</view>
			<button type="primary" class="operation-btn" :class="totalCount == 0 ? 'disabled' : ''" @click="submit">
				{{ operation == 'settlement' ? '结算' : '删除' }}({{ totalCount }})
			</button>
		</view>
		<loading-cover ref="loadingCover"></loading-cover>
		<Tarbar :route="route"/>
	</view>
</template>

<script>
import uniNumberBox from '@/components/uni-number-box/uni-number-box.vue';
import http from 'common/js/http.js';
import loadingCover from '@/components/loading/loading.vue';
import nsGoodsRecommend from '@/components/ns-goods-recommend/ns-goods-recommend.vue';
import Tarbar from '@/components/Tarbar.vue'
export default {
	components: {
		uniNumberBox,
		loadingCover,
		nsGoodsRecommend,
		Tarbar
	},
	data() {
		return {
			route: null,
			operation: 'settlement', // 操作 settlement:结算  delete:删除
			token: '',
			cartList: [],
			totalPrice: '0.00',
			totalCount: 0,
			checkAll: true,
			goodsLadderPreferential: [], // 商品阶梯优惠
			shopName: '',
			flag: false, //防重复标识
			modifyFlag: false ,//修改数量防重复
		};
	},
	methods: {
		/**
		 * 上拉加载
		 */
		onReachBottom() {
			this.$refs.goodsRecommend.getGoodsList();
		},
		/**
		 * 获取购物车数据
		 */
		getCartData() {
			this.sendRequest({
				url: 'System.Goods.cartList',
				success: res => {
					if (res.code == 0) {
						if (res.data.cart_list.length) {
							this.cartList = res.data.cart_list;

							if (this.cartList != null && this.cartList.length > 0) {
								this.shopName = this.cartList[0]['shop_name'];
								this.goodsLadderPreferential = JSON.parse(res.data.goods_ladder_preferential);

								this.cartList.forEach((item, index) => {
									item.checked = true;
									item.show_price = item.promotion_price;
									this.calculationGoodsPrice(item, index);
								});
								this.calculationTotalPrice();
							}
						} else {
							this.cartList = [];
						}
						this.$refs.loadingCover.hide();
					}
				},
				fail: res => {
					this.$refs.loadingCover.hide();
				}
			});
		},
		async cartNumChange(value, index) {
			let item = this.cartList[index];
			if (isNaN(parseInt(value))) return;
			if (item.num != value) {
				this.modifyFlag = true;
				uni.showLoading({
					title: '加载中'
				});
				await this.modifyCartNum(value, item, index);
			}
		},
		/**
		 * 修改购物车商品数量
		 * @param {Object} num
		 * @param {Object} item
		 * @param {Object} index
		 */
		async modifyCartNum(num, item, index) {
			num = parseInt(num) > parseInt(item.stock) ? item.stock : parseInt(num);
			if (num <= 0) {
				num = item.min_buy > 0 ? item.min_buy : 1;
			}
			let res = await this.sendRequest({
				url: 'System.Goods.modifyCartNum',
				data: { cart_id: item.cart_id, num: num },
				async: false,
				success: res => {}
			});
			if (res.code == 0) {
				this.cartList[index].num = num;
				this.cartList[index].show_price = this.cartList[index].promotion_price;
				this.calculationGoodsPrice(item, index);
				this.calculationTotalPrice();
			} else {
				this.$util.showToast({ title: res.message });
			}
		},
		/**
		 * 计算购物车总价
		 */
		calculationTotalPrice() {
			if (this.cartList.length) {
				let totalPrice = 0;
				let totalCount = 0;
				let siteAllElectionCount = 0;
				
				this.cartList.forEach(function(item) {
					if (item.checked) {
						totalPrice += item.show_price * item.num;
						totalCount += Number(item.num);
						siteAllElectionCount += 1;
					}
				});
				
				this.totalPrice = totalPrice.toFixed(2);
				this.totalCount = totalCount;
				this.modifyFlag = false;
				
				this.checkAll = this.cartList.length == siteAllElectionCount;
				uni.hideLoading();
			} else {
				this.totalPrice = '0.00';
				this.totalCount = 0;
			}
		},
		/**
		 * 单选
		 * @param {Object} index
		 */
		singleElection(index) {
			this.cartList[index].checked = !this.cartList[index].checked;
			this.cartList.push({});
			this.cartList.pop();
			let checkedNUm = 0;
			this.cartList.forEach(item => {
				if (item.checked) checkedNUm += 1;
			});
			this.checkAll = checkedNUm == this.cartList.length;
			this.calculationTotalPrice();
		},
		/**
		 * 全选
		 */
		allElection(checked) {
			if (typeof checked == 'boolean') {
				this.checkAll = checked;
			} else {
				this.checkAll = !this.checkAll;
			}
			if (this.cartList.length) {
				this.cartList.forEach(item => {
					item.checked = this.checkAll;
				});
				this.calculationTotalPrice();
			}
		},
		/**
		 * 购物车操作
		 */
		cartOperation() {
			if (this.operation == 'settlement') {
				this.operation = 'delete';
				this.allElection(false);
			} else {
				this.operation = 'settlement';
				this.allElection(true);
			}
		},
		/**
		 * 计算阶梯优惠之后的商品价格
		 */
		calculationGoodsPrice(cartItem, index) {
			var quantity = 0;
			if (this.goodsLadderPreferential.length) {
				this.goodsLadderPreferential.forEach(items => {
					if (items.length) {
						items.forEach(item => {
							if (item.quantity <= cartItem.num && item.quantity >= quantity && item.goods_id == cartItem.goods_id && item.cart_id == cartItem.cart_id) {
								quantity = item.quantity;
								this.cartList[index].show_price = this.cartList[index].promotion_price - item.price;
							}
						});
					}
				});
			}
		},
		submit() {
			var cartIdArr = [],
				goodsSkuList = [];

			this.cartList.forEach(item => {
				if (item.checked) {
					cartIdArr.push(item.cart_id);
					goodsSkuList.push(item.sku_id + ':' + item.num);
				}
			});
			if (this.operation == 'settlement') {
				if (!goodsSkuList.length) {
					this.$util.showToast({ title: '请选择要结算的商品！' });
					return;
				}

				if (this.flag) return;
				this.flag = true;

				uni.setStorage({
					key: 'orderCreateData',
					data: JSON.stringify({
						order_type: 1,
						goods_sku_list: goodsSkuList.toString(),
						order_tag: 2
					}),
					success: () => {
						this.$util.redirectTo('/pages/order/payment/payment');
					}
				});
			} else {
				if (!cartIdArr.length) {
					this.$util.showToast({ title: '请选择要删除的商品！' });
					return;
				}

				if (this.flag) return;
				this.flag = true;

				this.sendRequest({
					url: 'System.Goods.deleteCart',
					data: { cart_id_array: cartIdArr.toString() },
					success: res => {
						if (res.code == 0) {
							for (var i = 0; i < this.cartList.length; ) {
								if (this.$util.inArray(this.cartList[i].cart_id, cartIdArr) != -1) {
									this.cartList.splice(i, 1);
									i = 0;
									continue;
								}
								i++;
							}
							this.calculationTotalPrice();
						} else {
							this.$util.showToast({ title: res.message });
						}
						this.flag = false;
					}
				});
			}
		}
	},
	onShow() {
		this.token = uni.getStorageSync('token');
		if (this.token) this.getCartData();
		else this.cartList = [];
		let routes = getCurrentPages();
		this.route = routes[routes.length - 1].route
	},
	onReady() {
		this.$refs.loadingCover.hide();
	},
	onHide() {
		this.flag = false;
	},
	mixins: [http]
};
</script>

<style lang="scss">
scroll-view {
	/*  #ifdef H5 */
	height: calc(100vh - 94px);
	/*  #endif  */
	/*  #ifdef MP */
	height: calc(100vh - 0px);
	/*  #endif  */
}
.cart-container {
	box-sizing: border-box;
	position: relative;
	width: 100vw;
	overflow: scroll;
	.cart-store-header{
		padding: 20upx;
		margin: 20upx 24upx 0 24upx;
		display: flex;
		flex-direction: row;
		justify-content: space-between;
		align-items: center;
		border-bottom: 2upx solid #EEEEEE;
		background-color: #FFFFFF;
		border-radius:20upx 20upx 0 0;
		.cart-store-left{
			display: flex;
			flex-direction: row;
			align-items: center;
			.store-icon{
				width: 40upx;
				height: 40upx;
				margin: 0 4upx 0 20upx;
			}
			.store-name{
				font-size:30upx;
				font-weight:400;
				color:rgba(52,52,52,1);
			}
		}
		.store-edit{
			font-size:28upx;
			color:rgba(42,108,220,1);
		}
	}
}
.cart-container .cart-header {
	padding: 20rpx;
	overflow: hidden;
	line-height: 1;

	.icondianpu {
		float: left;
		display: inline-block;
		margin-right: 20rpx;
	}

	.cart-operation {
		float: right;
	}
	view,
	text {
		line-height: 37rpx;
	}
}
.cart-container .cart-wrapper {
	padding-bottom: 100rpx;
	.cart-goods {
		margin: 0 24rpx 0 24rpx;
		background: #fff;
		box-sizing: border-box;
		position: relative;
		padding-left: 76rpx;
		display: flex;
		border-bottom: 2upx solid #EEEEEE;
		&:nth-last-child(1){
			border-radius: 0 0 20upx 20upx;
			overflow: hidden;
		}
		& > .iconfont {
			font-size: 36rpx;
			position: absolute;
			top: 50%;
			left: 24rpx;
			transform: translateY(-50%);
		}
		& > .iconyuan_checked {
			color: $base-color;
		}
		& > .iconyuan_checkbox {
			color: $ns-text-color-gray;
		}
		.goods-img {
			width: 180rpx;
			height: 180rpx;
			padding: 24rpx 0;
			margin-right: 24rpx;

			image {
				width: 100%;
				height: 100%;
			}
		}

		.goods-info {
			flex: 1;
			padding: 24rpx 0;
			position: relative;

			.goods-name {
				display: -webkit-box;
				-webkit-box-orient: vertical;
				-webkit-line-clamp: 2;
				overflow: hidden;
				line-height: 1.5;
				font-size: 28rpx;
				padding-right: 20rpx;
			}

			.sku {
				font-size: 24rpx;
				color: #999;
				display: block;
				overflow: hidden;
				text-overflow: ellipsis;
				white-space: nowrap;
				padding-right: 20rpx;
			}

			.goods-sub-section {
				// position: absolute;
				// left: 0;
				// bottom: 24rpx;
				width: calc(100% - 24rpx);

				.unit {
					font-size: 24rpx;
				}

				.uni-numbox {
					float: right;
				}
			}
		}
	}
}
.cart-container .cart-bottom {
	position: absolute;
	z-index: 5;
	width: 100vw;
	height: 100rpx;
	background: #fff;
	bottom: 100upx;
	overflow: hidden;
	display: flex;

	.all-election {
		height: 100rpx;
		position: relative;
		padding-left: 20rpx;
		display: inline-block;

		& > .iconfont {
			font-size: 36rpx;
			position: absolute;
			top: 50%;
			left: 24rpx;
			transform: translateY(-50%);
		}
		& > .iconyuan_checked {
			color: $base-color;
		}

		& > text {
			margin-left: 56rpx;
			line-height: 100rpx;
		}
	}

	.settlement-info {
		flex: 1;
		text-align: right;
		padding-right: 20rpx;
		line-height: 100rpx;
	}

	.operation-btn {
		width: 230rpx;
		height: 100rpx;
		line-height: 100rpx;
		border-radius: 0;
		margin: 0;
	}
	.operation-btn.disabled {
		background: $btn-disabled-color !important;
		border: none !important;
	}
}
.cart-empty {
	text-align: center;
	font-size: 24rpx;
	padding: 0 $ns-padding;
	.empty-img {
		margin: 200rpx auto 20rpx auto;
		width: 220rpx;
		height: 120rpx;
		display: block;
	}
	navigator {
		display: inline;
	}
}
</style>
