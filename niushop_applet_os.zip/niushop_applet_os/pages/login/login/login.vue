<template>
	<view class="login">
		<view class="login-head">
			<!-- 自定义状态栏高度 -->
			<view class="head-nav"></view>
			<view class="head-content">
				<view class="head-return" @click="navigateBack">
					<text class="iconfont iconback_light"></text>
					{{ navLoginText }}
				</view>

				<view class="head-portrait" v-if="bindStorage"><image :src="userInfo.avatar ? $util.img(userInfo.avatar) : '/static/images/default_head.png'"></image></view>
			</view>
		</view>

		<view class="login-body">
			<!--  #ifdef  H5 || MP-ALIPAY -->
			<block v-if="!$util.isWeiXin()">
				<!-- 手机号 -->
				<template v-if="loginMode == 'mobile' && mobileIsUse">
					<view class="form-input input-mobile">
						<text>+86</text>
						<input class="uni-input" type="number" maxlength="11" v-model="formData.mobile" placeholder="手机号登录仅限中国大陆用户" name="mobile" />
					</view>

					<view class="form-input align-type">
						<input class="uni-input" type="number" maxlength="6" v-model="formData.dynacode" placeholder="请输入动态码" name="dynacode" />
						<view class="dynacode ns-text-color" @click="sendMobileCode">{{ codeText }}</view>
					</view>
				</template>

				<!-- 账号 -->
				<template v-if="loginMode == 'account'">
					<view class="form-input"><input class="uni-input" type="text" maxlength="30" placeholder="请输入账号" v-model="formData.account" name="account" /></view>

					<view class="form-input">
						<input class="uni-input" type="text" maxlength="30" password="true" placeholder="请输入密码" v-model="formData.password" name="password" />
					</view>

					<view class="form-input align-type" v-if="vercodeIsUse">
						<input class="uni-input" type="number" maxlength="4" v-model="formData.vercode" placeholder="请输入验证码" name="vercode" />
						<view class="vercode"><imgcode width="80" height="22" ref="imgcode"></imgcode></view>
					</view>
				</template>

				
				<view class="forget-section">
					<text @click="switchLoginMode" v-show="mobileIsUse">{{ loginMode == 'mobile' ? '账号登录' : '手机号登录' }}</text>
					<navigator v-show="loginMode == 'account'" url="/pages/login/find/find?type=mobile">忘记密码</navigator>
				</view>

				<button type="primary" class="login-btn" @click="login">登录</button>
				<view class="register">
					没有账号的用户快来
					<navigator url="/pages/login/register/register">注册</navigator>
					吧!
				</view>
			</block>
			<!--  #endif -->

			<!--  #ifdef  MP-WEIXIN -->
			<!-- 授权 - 登录方式 -->
			<block v-if="loginMode == ''">
				<button type="primary" v-if="isAuthorizePhone == 0" class="modify-operation" open-type="getPhoneNumber" @getphonenumber="bindGetPhoneNumber">一键授权登录</button>
				<button type="primary" v-else-if="isAuthorizePhone == 1" class="modify-operation" @click="wxLogin">一键授权登录</button>
				<button v-if="mobileIsUse" type="primary" class="modify-operation" @click="mobileLogin">手机号登录</button>
				<view class="align-type">
					<text @click="accountLogin">账号密码登录</text>
					<navigator url="/pages/login/register/register">新用户注册</navigator>
				</view>
			</block>
			
			<!-- 一键授权登录 -->
			<block v-if="loginMode == 'onAuthorization'">
				<view class="form-input"><input class="uni-input" type="text" maxlength="30" password="true" placeholder="请输入密码" v-model="formData.password" /></view>

				<view class="form-input"><input class="uni-input" type="text" maxlength="30" password="true" placeholder="请确认密码" v-model="formData.rePassword" /></view>

				<button type="primary" class="login-btn" @click="wxLogin">登录</button>
			</block>

			<!-- 授权 - 手机号 -->
			<block v-if="loginMode == 'mobile' && mobileIsUse">
				<!-- 下一步 -->
				<block v-if="stepShow == 0">
					<view class="form-input input-mobile">
						<text>+86</text>
						<input class="uni-input" type="number" maxlength="11" v-model="formData.mobile" placeholder="手机号登录仅限中国大陆用户" name="mobile" />
					</view>
					<view class="forget-section">
						<text @click="switchLoginMode" v-show="mobileIsUse">{{ loginMode == 'mobile' ? '账号登录' : '手机号登录' }}</text>
					</view>
					<button type="primary" class="login-btn" @click="mobileStep">下一步</button>
				</block>

				<!-- 登录 -->
				<block v-if="stepShow == 1">
					<view class="form-input align-type">
						<input class="uni-input" type="number" maxlength="6" v-model="formData.dynacode" placeholder="请输入动态码" />
						<view class="dynacode ns-text-color" @click="sendMobileCode">{{ codeText }}</view>
					</view>
					<button type="primary" class="login-btn" @click="wxLogin">登录</button>
				</block>
			</block>

			<!-- 授权 - 账号登录 -->
			<block v-if="loginMode == 'account'">
				<view class="form-input"><input class="uni-input" type="text" maxlength="30" placeholder="请输入账号" v-model="formData.account" name="account" /></view>

				<view class="form-input">
					<input class="uni-input" type="text" maxlength="30" password="true" placeholder="请输入密码" v-model="formData.password" name="password" />
				</view>

				<view class="form-input align-type" v-if="vercodeIsUse">
					<input class="uni-input" type="number" maxlength="4" v-model="formData.vercode" placeholder="请输入验证码" name="vercode" />
					<view class="vercode"><imgcode width="80" height="22" ref="imgcode"></imgcode></view>
				</view>

				<view class="forget-section">
					<text @click="switchLoginMode" v-show="mobileIsUse">{{ loginMode == 'mobile' ? '账号登录' : '手机号登录' }}</text>
				</view>

				<button type="primary" class="login-btn" @click="wxLogin">登录</button>
			</block>

			<!--  #endif -->
			
			<!--  #ifdef  H5 -->
			<block v-if="$util.isWeiXin()">
				<!-- 授权 - 登录方式 -->
				<block v-if="loginMode == ''">
					<block v-if="openidIsExits">
						<button type="primary" class="modify-operation" @click="checkOpenid">一键授权登录</button>
						<button v-if="mobileIsUse" type="primary" class="modify-operation" @click="mobileLogin">手机号登录</button>
						<view class="align-type">
							<text @click="accountLogin">账号密码登录</text>
							<navigator url="/pages/login/register/register">新用户注册</navigator>
						</view>
					</block>
					<block v-else>
						<button v-if="mobileIsUse" type="primary" class="modify-operation" @click="mobileLogin">手机号登录</button>
						<button type="primary" class="modify-operation" @click="accountLogin">账号密码登录</button>
						<view class="align-type">
							<navigator url="/pages/login/register/register">新用户注册</navigator>
						</view>
					</block>
				</block>
				<!-- 授权 - 手机号 -->
				<block v-if="loginMode == 'mobile' && mobileIsUse">
					<!-- 下一步 -->
					<block v-if="stepShow == 0">
						<view class="form-input input-mobile">
							<text>+86</text>
							<input class="uni-input" type="number" maxlength="11" v-model="formData.mobile" placeholder="手机号登录仅限中国大陆用户" name="mobile" />
						</view>
						<view class="forget-section">
							<text @click="switchLoginMode" v-show="mobileIsUse">{{ loginMode == 'mobile' ? '账号登录' : '手机号登录' }}</text>
						</view>
						<button type="primary" class="login-btn" @click="mobileStep">下一步</button>
					</block>
				
					<!-- 登录 -->
					<block v-if="stepShow == 1">
						<view class="form-input align-type">
							<input class="uni-input" type="number" maxlength="6" v-model="formData.dynacode" placeholder="请输入动态码" />
							<view class="dynacode ns-text-color" @click="sendMobileCode">{{ codeText }}</view>
						</view>
						<button type="primary" class="login-btn" @click="wxLogin">登录</button>
					</block>
				</block>
				
				<!-- 授权 - 账号登录 -->
				<block v-if="loginMode == 'account'">
					<view class="form-input"><input class="uni-input" type="text" maxlength="30" placeholder="请输入账号" v-model="formData.account" name="account" /></view>
				
					<view class="form-input">
						<input class="uni-input" type="text" maxlength="30" password="true" placeholder="请输入密码" v-model="formData.password" name="password" />
					</view>
				
					<view class="form-input align-type" v-if="vercodeIsUse">
						<input class="uni-input" type="number" maxlength="4" v-model="formData.vercode" placeholder="请输入验证码" name="vercode" />
						<view class="vercode"><imgcode width="80" height="22" ref="imgcode"></imgcode></view>
					</view>
				
					<view class="forget-section">
						<text @click="switchLoginMode" v-show="mobileIsUse">{{ loginMode == 'mobile' ? '账号登录' : '手机号登录' }}</text>
					</view>
				
					<button type="primary" class="login-btn" @click="wxLogin">登录</button>
				</block>
			</block>
			<!--  #endif -->
		</view>
	</view>
</template>

<script>
import http from 'common/js/http.js';
import validate from 'common/js/validate.js';
import imgcode from '../../../components/imgcode/imgcode.vue';
import uniPopup from 'components/uni-popup/uni-popup.vue';

let _self;
export default {
	components: {
		imgcode,
		uniPopup
	},
	data() {
		return {
			vercodeIsUse: false, //图形验证码
			mobileIsUse: 1, //短信配置  1表示配置完成  0表示未配置
			loginMode: '', //登录方式
			isSub: false, //防止重复点击登录
			isSend: false, // 防止重复点击发送动态验证码
			isClickLogin: false,
			wxIsClickLogin: false,
			isAuthorize: 0, // 是否授权
			authorizePhone: '', //授权手机号
			navLoginText: '手机号登录',
			goback: '',
			token: '',
			isAuthorizePhone: 0,
			formData: {
				mobile: '',
				account: '',
				password: '',
				rePassword: '',
				vercode: '',
				dynacode: ''
			},
			seconds: 120,
			timer: null,
			codeText: '获取动态码',
			stepShow: 0,
			userInfo: {
				avatar: '',
				nickname: ''
			},
			bindStorage: null,
			openidIsExits: false
		};
	},
	onLoad(data) {
		if (data.goback) this.goback = data.goback;
		// #ifdef MP-ALIPAY
		this.loginMode = 'account';
		// #endif
	},
	methods: {
		/**
		 * 导航切换
		 */
		navigateBack() {
			//#ifdef  MP
			if (this.loginMode != '') {
				if (this.stepShow == 1) {
					this.stepShow = 0;
					this.navLoginText = this.loginMode == 'mobile' ? '手机号登录' : '账号登录';

					this.isSend = false;
					this.seconds = 120;
					this.codeText = '获取验证码';
					clearInterval(this.timer);

					return false;
				}
				this.navLoginText = '登录';
				this.loginMode = '';
				return false;
			}
			// #endif

			this.$util.redirectTo('/pages/member/index/index', '', 'tabbar', 'reLaunch');
		},

		/**
		 * 切换登录方式
		 */
		switchLoginMode() {
			this.loginMode = this.loginMode == 'mobile' ? 'account' : 'mobile';
			this.navLoginText = this.loginMode == 'mobile' ? '手机号登录' : '账号登录';
		},

		/**
		 * 获取验证码
		 */
		getVertificationCode() {
			this.$refs.imgcode.refresh();
		},

		/**
		 * 检测手机号是否存在
		 */
		async detectPhoneNumber(mobile) {
			let res = await this.sendRequest({
				url: 'System.Member.checkMobile',
				data: { mobile: mobile },
				async: false
			});
			if (!res.data) {
				// #ifdef  H5
				this.$util.showToast({ title: '该手机号未注册' });
				// #endif
				return false;
			}
			return true;
		},

		/**
		 * 发送手机动态码
		 */
		sendMobileCode() {
			if (this.seconds != 120) return;
			let f = this.isAuthorize == 0 ? this.vertify() : this.wxVertify();
			if (f && !this.isSend) {
				this.isSend = true;
				this.sendRequest({
					url: 'System.Send.sendDynamicCode',
					data: {
						account: _self.formData.mobile,
						key: 'register_validate',
						type: 'sms'
					},
					success: res => {
						if (res.code == 0) {
							if (this.seconds == 120 && this.timer == null) {
								this.timer = setInterval(() => {
									this.seconds--;
									this.codeText = this.seconds + 's';
								}, 1000);
							}
							uni.setStorageSync('login_validate_token', res.data.record_id);
						} else {
							this.$util.showToast({ title: res.message });
							this.seconds = 120;
							this.codeText = '获取验证码';
							clearInterval(this.timer);
							this.isSend = false;
						}
					}
				});
			}
		},

		/**
		 * 未授权登录
		 */
		async login() {
			this.isClickLogin = true;
			if (this.vertify()) {
				this.isClickLogin = false;
				if (this.isSub) return;
				this.isSub = true;

				if (this.loginMode == 'mobile') {
					let detectPhone = await this.detectPhoneNumber(this.formData.mobile);
					if (!detectPhone) return;
				}

				let url = this.loginMode == 'mobile' ? 'System.Login.mobileLoginAPI' : 'System.Login.login';

				this.sendRequest({
					url: url,
					data: {
						username: _self.formData.account,
						password: _self.formData.password,
						account: _self.formData.mobile,
						code: _self.formData.dynacode,
						record_id: uni.getStorageSync('login_validate_token')
					},
					success: res => {
						if (res.data.code > 0) {
							uni.setStorage({
								key: 'token',
								data: res.data.token
							});
							uni.removeStorage({ key: 'login_validate_token' });
							if (this.goback) {
								let pages = getCurrentPages(),
									backArray = [
										'goods_point',
										'index',
										'combo',
										'coupon_receive',
										'find',
										'apply_withdrawal',
										'balance',
										'collection',
										'member_coupon',
										'member_index',
										'modify_face',
										'member_point',
										'recharge',
										'aftersale',
										'order_detail',
										'order_list',
										'payment',
										'pickup',
										'pickup_toexamine',
										'refund_detail',
										'pay',
										'verification_code',
										'verification_detail',
										'bargain_launch',
										'goods_detail',
										'distribution'
									];
								var f = true;
								for (let i = pages.length - 1; i > 0; i--) {
									if (backArray.indexOf(_self.goback) > -1) {
										f = false;
										uni.navigateBack({
											delta: 1
										});
										break;
									}
								}

								if (f) this.$util.redirectTo('/pages/member/index/index', {}, 'tabbar');
							} else {
								this.$util.redirectTo('/pages/member/index/index', {}, 'tabbar');
							}
						} else {
							this.isSub = false;
							if (this.vercodeIsUse && this.loginMode == 'account') {
								this.getVertificationCode();
							}
							this.$util.showToast({ title: res.data.message });
						}
					}
				});
			}
		},

		/**
		 * 未授权登录表单验证
		 */
		vertify() {
			let rule = [];
			// 手机号验证
			if (this.loginMode == 'mobile') {
				rule = [{ name: 'mobile', checkType: 'required', errorMsg: '请输入手机号' }, { name: 'mobile', checkType: 'phoneno', errorMsg: '请输入正确的手机号' }];
				if (this.isClickLogin) {
					rule.push({ name: 'dynacode', checkType: 'required', errorMsg: '请输入动态码' });
				}
			}

			// 账号验证
			if (this.loginMode == 'account') {
				rule = [{ name: 'account', checkType: 'required', errorMsg: '请输入用户名' }, { name: 'password', checkType: 'required', errorMsg: '请输入密码' }];
				if (this.vercodeIsUse) {
					rule.push({ name: 'vercode', checkType: 'required', errorMsg: '请输入验证码' });
					rule.push({
						name: 'vercode',
						checkType: 'custom',
						errorMsg: '验证码错误',
						validate(value) {
							return _self.$refs.imgcode.checkCode(value);
						}
					});
				}
			}

			var checkRes = validate.check(this.formData, rule);
			if (checkRes) {
				return true;
			} else {
				this.$util.showToast({ title: validate.error });
				this.isClickLogin = false;
				return false;
			}
		},

		/**
		 * 授权获取小程序用户的基础信息
		 */
		getBindStorage() {
			this.bindStorage = uni.getStorageSync('bind_data');
			this.getUserInfo();

			this.sendRequest({
				url: 'System.UniApp.getMobileByOpenId',
				data: {
					provider: this.bindStorage.provider,
					openid: this.bindStorage.openid
				},
				success: res => {
					if (res.data) this.openidIsExits = true;
					if (res.data && res.data.mobile) {
						this.authorizePhone = res.data.mobile;
						this.isAuthorizePhone = 1;
					}
				}
			});
		},
		getLoginConfig(){
			this.sendRequest({
				url: 'System.Login.loginConfig',
				success: res => {
					this.config = res.data;
					this.mobileIsUse = res.data.login_config.mobile_config.is_use;
					let code_config = res.data.code_config.value;
					if (code_config.pc == 1) {
						if (code_config.error_num > 0 && code_config.error_num > code_config.curr_err_num) this.vercodeIsUse = false;
						else this.vercodeIsUse = true;
					}
				}
			});
		},
		getUserInfo() {
			// #ifdef H5
			if ((this.bindStorage.provider = 'weixinPublic')) {
				this.sendRequest({
					url: 'System.WchatPublic.getOauthMemberInfo',
					data: this.bindStorage,
					success: res => {
						if (res.errmsg == undefined) {
							this.userInfo.avatar = res.data.headimgurl;
							this.userInfo.nickname = res.data.nickname;
						} else {
							this.$util.showToast({ title: res.errmsg });
							setTimeout(() => {
								this.$util.redirectTo('/pages/member/index/index', {}, 'tabbar');
							}, 1500);
						}
					}
				});
			}
			// #endif
			// #ifdef MP
			uni.getUserInfo({
				provider: this.bindStorage.provider,
				success: infoRes => {
					if (infoRes.errMsg == 'getUserInfo:ok') {
						switch (this.bindStorage.provider) {
							case 'weixin':
								this.userInfo.avatar = infoRes.userInfo.avatarUrl;
								this.userInfo.nickname = infoRes.userInfo.nickName;
								break;
						}
					} else {
						this.$util.showToast({ title: infoRes.errMsg });
						setTimeout(() => {
							this.$util.redirectTo('/pages/member/index/index', {}, 'tabbar');
						}, 1500);
					}
				}
			});
			// #endif
		},

		/**
		 *  一键授权
		 */
		bindGetPhoneNumber(e) {
			if (e.detail.errMsg == 'getPhoneNumber:ok') {
				this.sendRequest({
					url: 'System.Login.getWechatParticularInfo',
					data: {
						sessionKey: this.bindStorage.session_key,
						encryptedData: e.detail.encryptedData,
						iv: e.detail.iv
					},
					success: async res => {
						if (res.code == 0) {
							if (res.data.data) {
								let phoneNumber = JSON.parse(res.data.data).phoneNumber,
									detectPhone = await this.detectPhoneNumber(phoneNumber);
								this.authorizePhone = phoneNumber;
								if (detectPhone) {
									this.wxLogin();
								} else {
									this.loginMode = 'onAuthorization';
								}
							}
						}
					}
				});
			}
		},

		/**
		 * 已授权手机号登录
		 */
		mobileLogin() {
			this.loginMode = 'mobile';
			this.navLoginText = '手机号登录';
		},

		async mobileStep() {
			if (!this.wxVertify()) return;

			let detectPhone = await this.detectPhoneNumber(this.formData.mobile);
			if (!detectPhone) {
				this.$util.showToast({ title: '该手机号不存在' });
				return;
			}

			this.stepShow = 1;
		},

		/**
		 * 已授权账号登录
		 */
		accountLogin() {
			this.loginMode = 'account';
			this.navLoginText = '账号登录';
		},
		/**
		 * 已授权登录
		 */
		async wxLogin() {
			if (this.isSub) return;
			this.isSub = true;

			this.wxIsClickLogin = true;
			if (!this.wxVertify()) return;
			this.wxIsClickLogin = false;
			let authMode = '',
				account = '',
				password = '',
				code = '',
				record = '';

			//一键授权 手机号存在
			if (this.loginMode == '') {
				this.navLoginText = '一键授权登录';
				authMode = 'quick';
				account = this.authorizePhone;
			}

			// 一键授权 手机号不存在
			if (this.loginMode == 'onAuthorization') {
				this.navLoginText = '一键授权登录';
				authMode = 'quick';
				account = this.authorizePhone;
				password = this.formData.rePassword;
			}

			//手机号登录
			if (this.loginMode == 'mobile') {
				authMode = 'mobile';
				account = this.formData.mobile;
				code = this.formData.dynacode;
				record = uni.getStorageSync('login_validate_token');
			}

			//账号登录
			if (this.loginMode == 'account') {
				authMode = 'account';
				account = this.formData.account;
				password = this.formData.password;
			}

			this.sendRequest({
				url: 'System.UniApp.login',
				data: {
					mode: authMode,
					provider: this.bindStorage.provider,
					openid: this.bindStorage.openid,
					account: account,
					avatar: this.userInfo.avatar,
					nickname: this.userInfo.nickname,
					password: password,
					code: code,
					record_id: record,
					source_uid: uni.getStorageSync('source_uid')
				},
				success: res => {
					if (res.code == 0) {
						uni.setStorage({
							key: 'token',
							data: res.data.token
						});
						console.log(this.bindStorage)
						uni.removeStorage({ key: 'source_uid' });
						uni.removeStorage({ key: 'login_validate_token' });
						if (this.goback) {
							let pages = getCurrentPages(),
								backArray = [
									'goods_point',
									'index',
									'combo',
									'coupon_receive',
									'find',
									'apply_withdrawal',
									'balance',
									'collection',
									'member_coupon',
									'member_index',
									'modify_face',
									'member_point',
									'recharge',
									'aftersale',
									'order_detail',
									'order_list',
									'payment',
									'pickup',
									'pickup_toexamine',
									'refund_detail',
									'pay',
									'verification_code',
									'verification_detail',
									'bargain_launch',
									'goods_detail'
								];
							var f = true;
							for (let i = pages.length - 1; i > 0; i--) {
								if (backArray.indexOf(_self.goback) > -1) {
									f = false;
									uni.navigateBack({
										delta: 1
									});
									break;
								}
							}

							if (f) this.$util.redirectTo('/pages/member/index/index', {}, 'tabbar');
						} else {
							this.$util.redirectTo('/pages/member/index/index', {}, 'tabbar');
						}
					} else {
						this.isSub = false;

						if (this.vercodeIsUse && this.loginMode == 'account') {
							this.getVertificationCode();
						}
						this.$util.showToast({ title: res.message });
					}
				}
			});
		},

		/**
		 * 已授权登录表单验证
		 */
		wxVertify() {
			let rule = [],
				checkRes = '';
			if (this.loginMode == 'onAuthorization') {
				var regConfig = this.config.reg_config;

				rule.push({ name: 'password', checkType: 'required', errorMsg: '请输入密码' });

				if (regConfig.pwd_len > 0) {
					rule.push({ name: 'password', checkType: 'lengthMin', checkRule: regConfig.pwd_len, errorMsg: '密码长度不能小于' + regConfig.pwd_len + '位' });
				}
				if (regConfig.pwd_complexity != '') {
					var passwordErrorMsg = '密码需包含';
					var reg = '';
					if (regConfig.pwd_complexity.indexOf('number') != -1) {
						reg += '(?=.*?[0-9])';
						passwordErrorMsg += '数字';
					}
					if (regConfig.pwd_complexity.indexOf('letter') != -1) {
						reg += '(?=.*?[a-z])';
						passwordErrorMsg += '、小写字母';
					}
					if (regConfig.pwd_complexity.indexOf('upper_case') != -1) {
						reg += '(?=.*?[A-Z])';
						passwordErrorMsg += '、大写字母';
					}
					if (regConfig.pwd_complexity.indexOf('symbol') != -1) {
						reg += '(?=.*?[#?!@$%^&*-])';
						passwordErrorMsg += '、特殊字符';
					}
					rule.push({ name: 'password', checkType: 'reg', checkRule: reg, errorMsg: passwordErrorMsg });
				}

				if (this.formData.password != this.formData.rePassword) {
					this.$util.showToast({ title: '两次密码不一致' });
					return false;
				}
			}

			if (this.loginMode == 'mobile') {
				rule.push({ name: 'mobile', checkType: 'required', errorMsg: '请输入手机号' });
				rule.push({ name: 'mobile', checkType: 'phoneno', errorMsg: '请输入正确的手机号' });

				if (this.wxIsClickLogin) {
					rule.push({ name: 'dynacode', checkType: 'required', errorMsg: '请输入动态码' });
				}
			}

			if (this.loginMode == 'account') {
				rule.push({ name: 'account', checkType: 'required', errorMsg: '请输入账号' });

				var regConfig = this.config.reg_config;

				rule.push({ name: 'password', checkType: 'required', errorMsg: '请输入密码' });				
				if (this.vercodeIsUse) {
					rule.push({ name: 'vercode', checkType: 'required', errorMsg: '请输入验证码' });
					rule.push({
						name: 'vercode',
						checkType: 'custom',
						errorMsg: '验证码错误',
						validate: value => {
							return this.$refs.imgcode.checkCode(value);
						}
					});
				}
			}

			checkRes = validate.check(this.formData, rule);
			if (checkRes) {
				return true;
			} else {
				this.isSub = false;
				this.wxIsClickLogin = false;
				this.$util.showToast({ title: validate.error });
				return false;
			}
		},
		checkOpenid(){
			this.sendRequest({
				url: 'System.UniApp.checkOpenidIsExits',
				data: this.bindStorage,
				success: res => {
					if (res.data.is_bound) {
						uni.setStorage({
							key: 'token',
							data: res.data.token,
							success: () => {
								uni.removeStorage({ key: 'bind_data' });
								uni.removeStorage({ key: 'login_validate_token' });
								if (this.goback) {
									let pages = getCurrentPages(),
										backArray = [
											'goods_point',
											'index',
											'combo',
											'coupon_receive',
											'find',
											'apply_withdrawal',
											'balance',
											'collection',
											'member_coupon',
											'member_index',
											'modify_face',
											'member_point',
											'recharge',
											'aftersale',
											'order_detail',
											'order_list',
											'payment',
											'pickup',
											'pickup_toexamine',
											'refund_detail',
											'pay',
											'verification_code',
											'verification_detail',
											'bargain_launch',
											'goods_detail',
											'distribution'
										];
									var f = true;
									for (let i = pages.length - 1; i > 0; i--) {
										if (backArray.indexOf(_self.goback) > -1) {
											f = false;
											uni.navigateBack({
												delta: 1
											});
											break;
										}
									}
									
									if (f) this.$util.redirectTo('/pages/member/index/index', {}, 'tabbar');
								} else {
									this.$util.redirectTo('/pages/member/index/index', {}, 'tabbar');
								}
							}
						});
					}
				}
			});
		}
	},
	onShow() {
		_self = this;
		/**
		 * 获取登录配置信息
		 */
		// #ifdef  H5
		if (this.$util.isWeiXin()) this.getBindStorage();
		this.sendRequest({
			url: 'System.Login.loginConfig',
			success: res => {
				this.config = res.data;
				this.mobileIsUse = res.data.login_config.mobile_config.is_use;
				if (this.$util.isWeiXin()){
					this.loginMode = '';
				} else {
					this.loginMode = this.mobileIsUse == 0 ? 'account' : 'mobile';					
				}
				let code_config = res.data.code_config.value;
				console.log(code_config);
				if (code_config.pc == 1) {
					if (code_config.error_num > 0 && code_config.error_num > code_config.curr_err_num) this.vercodeIsUse = false;
					else this.vercodeIsUse = true;
				}
			}
		});	
		// #endif

		// #ifdef  MP
		this.navLoginText = '登录';
		this.getBindStorage();
		this.getLoginConfig();
		this.sendRequest({
			url: 'System.Login.registerConfig',
			success: res => {
				this.config = res.data;
				this.mobileIsUse = this.config.reg_config.mobile_config.is_use;
				if (res.data.reg_config.register_info.indexOf('plain') == -1) this.isCanRegister = false;
				else this.isCanRegister = true;
			}
		});
		// #endif

		/**
		 * 判断是否已经登陆
		 */
		uni.getStorage({
			key: 'token',
			success: function(res) {
				_self.token = res.data;
			}
		});
	},
	watch: {
		seconds(value) {
			if (value == 0) {
				this.seconds = 120;
				this.codeText = '获取验证码';
				clearInterval(this.timer);
				this.isSend = false;
			}
		}
	},
	onUnload() {
		/**
		 * 清除本地缓存
		 */
		uni.removeStorageSync('imgcode/' + this.currPage);

		/**
		 * 初始化动态码状态
		 */

		this.seconds = 120;
		this.codeText = '获取验证码';
		clearInterval(this.timer);

		this.isSend = false;
		this.isSub = false;
	},
	mixins: [http]
};
</script>

<style lang="scss">
page {
	background: #fff;
}
.login-head {
	/* 自定义导航 */
	.head-nav {
		width: 100%;
		height: var(--status-bar-height);
	}
	.head-content {
		position: relative;
		width: 750rpx;
		height: 540rpx;
		background: $base-color url(../../../static/images/authorize_bj.png) no-repeat;
		background-size: contain;
		.head-return {
			padding-left: 30rpx;
			height: 90rpx;
			line-height: 90rpx;
			color: #fff;
			font-size: $ns-font-size-lg;
			text {
				display: inline-block;
				margin-right: 10rpx;
			}
		}
		.head-portrait {
			overflow: hidden;
			position: absolute;
			bottom: 28rpx;
			left: 50%;
			transform: translateX(-50%);
			width: 120rpx;
			height: 120rpx;
			border-radius: 50%;
			border: 4rpx solid #fff;
			image {
				width: 120rpx;
				height: 120rpx;
			}
		}
	}
}

.login-body {
	padding: 100rpx 80rpx 0;
	.form-input {
		margin-top: 60rpx;
		height: 60rpx;
		border-bottom: 2rpx solid $ns-bg-color-gray;
		input {
			font-size: $ns-font-size-base;
			padding: 0;
		}
	}
	.input-mobile {
		position: relative;
		text {
			&:after {
				content: '';
				position: absolute;
				left: 56rpx;
				bottom: 24rpx;
				border: 2rpx solid transparent;
				border-top-color: #333;
				border-left-color: #333;
				width: 12rpx;
				height: 12rpx;
				display: block;
				transform: rotate(-135deg);
			}
			position: absolute;
			top: -4rpx;
			left: 0;
		}
		input {
			padding: 0 0 0 90rpx;
		}
	}
	.login-btn {
		margin-top: 60rpx;
	}
	button {
		margin: 0;
		border-radius: 40rpx;
		margin-bottom: 30rpx;
		color: #fff;
	}
	.forget-section {
		display: flex;
		flex-direction: row-reverse;
		justify-content: space-between;
		margin-top: 10rpx;
		height: 70rpx;
		line-height: 70rpx;
	}
	.register {
		text-align: center;
		navigator {
			display: inline-block;
			color: $base-color;
		}
	}
}

.align-type {
	display: flex;
	justify-content: space-between;
}
</style>
