export default {
	baseUrl: 'https://daiwu668.dianaikeji.com/', // api请求地址
	imgUrl: 'https://daiwu668.dianaikeji.com/', // 图片服务器地址
	shareDomain: 'https://daiwu668.dianaikeji.com/h5/', // 网站分享跳转域名 H5端必须
	privateKey: "hsvkrqcvdfapteih", //api安全秘钥 
}
		