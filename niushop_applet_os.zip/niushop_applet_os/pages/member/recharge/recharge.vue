<template>
	<view>
		<view class="detail-main">
			<view class="payment">
				<text>金额</text>
				<input class="uni-input ns-font-size-sm" type="digit" v-model="payMoney" placeholder="请输入充值金额" @onblur="checkPayMoney()" />
			</view>
			<button type="primary" @click="calculateRecharge()">确认支付</button>
		</view>
		<ns-login ref="login" href="recharge"></ns-login>
	</view>
</template>

<script>
import http from 'common/js/http.js';
import nsLogin from 'components/ns-login/ns-login.vue';
export default {
	components: {
		nsLogin
	},
	data() {
		return {
			payNo: 0,
			payMoney: '',
			isSubmit: false
		};
	},
	onShow() {
		var isLogin = false;
		// #ifdef H5
		getApp().checkLogin(() => {
			isLogin = true;
			setTimeout(() => {
				this.$refs.login.clickLogin();
			}, 100);
		});
		// #endif
		// #ifdef MP
		getApp().$vm.checkLogin(() => {
			isLogin = true;
			this.$refs.login.clickLogin();
		});
		// #endif

		if (isLogin) return;

		this.getMemberAccount();
	},
	mixins: [http],
	methods: {
		getMemberAccount() {
			this.sendRequest({
				url: 'System.Member.recharge',
				success: res => {
					if (res.code == 0) {
						this.payNo = res.data;
					}
				}
			});
		},
		checkPayMoney() {
			var pay_money = parseFloat(this.payMoney).toFixed(2);
			if (isNaN(pay_money)) {
				pay_money = 0.0;
			}
			this.payMoney = pay_money;
		},
		calculateRecharge() {
			var pay_no = this.payNo;
			var pay_money = this.payMoney;
			if (pay_money < 0 || pay_money == '' || pay_money == 0) {
				this.$util.showToast({
					title: '充值金额必须大于0'
				});
				return;
			}
			if (this.isSubmit) return;
			this.isSubmit = true;
			this.sendRequest({
				url: 'System.Member.createRechargeOrder',
				data: {
					recharge_money: pay_money,
					out_trade_no: pay_no
				},
				success: res => {
					if (res.data > 0) {
						this.$util.redirectTo('/pages/pay/pay/pay', {
							out_trade_no: pay_no
						});
					} else {
						this.isSubmit = false;
						this.$util.showToast({
							title: '充值失败'
						});
					}
				}
			});
		}
	},
	onHide() {
		this.isSubmit = false;
	}
};
</script>

<style lang="scss">
.payment {
	overflow: hidden;
	line-height: 100rpx;
	padding-left: 30rpx;
	background: #fff;
	display: flex;
}

.payment text {
	width: 30%;
}

.payment input {
	width: 70%;
	height: 100rpx;
	line-height: 100rpx;
	border: none;
	display: inline-block;
	padding:0;
}

.detail-main {
	button {
		position: fixed;
		bottom: 50rpx;
		z-index: 5;
		width: 90%;
		height: 100rpx;
		border: 0;
		line-height: 100rpx;
		text-align: center;
		color: #fff;
	}
}
</style>
