<template>
	<view>
		<image :src="qrcodeImg" mode="widthFix"></image>
		<loading-cover ref="loadingCover"></loading-cover>
		<ns-login ref="login" href="distribution"></ns-login>
	</view>
</template>

<script>
import http from 'common/js/http.js';
import loadingCover from '@/components/loading/loading.vue';
import nsLogin from 'components/ns-login/ns-login.vue';
import { Weixin } from 'common/js/wx-jssdk.js';

export default {
	components: {
		loadingCover,
		nsLogin
	},
	data() {
		return {
			qrcodeImg: '',
			uid: 0
		};
	},
	methods: {
		getShopQrcode() {
			this.sendRequest({
				url: 'System.Distribution.userFxQrcode',
				success: res => {
					if (res.code == 0 && res.data) {
						this.qrcodeImg = this.$util.img(res.data);
						if (this.$refs.loadingCover == undefined) return;
						this.$refs.loadingCover.hide();
					} else {
						this.$util.showToast({ title: res.message });
						setTimeout(() => {
							this.$util.redirectTo('/distributionpages/index/index', {}, '', 'redirectTo');
						}, 1500);
					}
				}
			});
		},
		/**
		 * 获取当前用户id
		 */
		getUserId() {
			if (uni.getStorageSync('token')) {
				this.sendRequest({
					url: 'System.Member.getUserId',
					success: res => {
						if (res.data) this.uid = res.data;
					}
				});
			}
		}
	},
	onShow() {
		var isLogin = false;
		// #ifdef H5
		getApp().checkLogin(() => {
			isLogin = true;
			setTimeout(() => {
				this.$refs.login.clickLogin();
			}, 100);
		});
		// #endif
		// #ifdef MP
		getApp().$vm.checkLogin(() => {
			isLogin = true;
			this.$refs.login.clickLogin();
		});
		// #endif

		if (isLogin) return;

		this.getShopQrcode();

		this.getUserId();
	},
	mixins: [http],
	/**
	 * 自定义分享内容
	 * @param {Object} res
	 */
	onShareAppMessage(res) {
		var path = '/distributionpages/user_shop_goods/user_shop_goods';
		if (this.uid) path += '?source_uid=' + this.uid;
		return {
			path: path,
			success: res => {
				this.sendRequest({
					url: 'NsMemberShare.MemberShare.shareReward'
				})
			},
			fail: res => {}
		};
	},
	onReady() {
		// 微信公众号分享
		// #ifdef H5
		if (this.$util.isWeiXin()) {
			this.sendRequest({
				url: 'System.WchatPublic.getJsApiConfig',
				data : {
					url: window.location.href
				},
				success: jsApiRes => {
					if (jsApiRes.code == 0) {
						var wxJS = new Weixin();
						wxJS.init(jsApiRes.data);
						
						this.sendRequest({
							url: 'System.Member.shareContents',
							data: {
								flag: 'fx_shop_qrcode'
							},
							success: res => {
								if (res.data) {
									wxJS.updateAppMessageShareData({
										title: res.data.share_title,
										desc: res.data.share_contents + '\r\n' + res.data.share_nick_name + '\r\n' + '收藏热度：★★★★★',
										link: res.data.share_url,
										imgUrl: res.data.share_img,
									}, () => {
										this.sendRequest({
											url: 'NsMemberShare.MemberShare.shareReward'
										})
									})
								}
							}
						})
					}
				}
			})
		}
		// #endif
	}
};
</script>

<style>
image {
	width: 100%;
}
</style>
