<template>
	<view class="nc-callback-pay-content">
		<view class="callback-wrap">
			<text class="callback-icon iconfont" :class="paySuccess ? 'icon_success' : 'icon_fail'"></text>
			<text class="callback-desc">{{ paySuccess ? '支付成功' : '支付失败' }}</text>
			<button class="callback-btn" @click="goBack">完成</button>
		</view>
	</view>
</template>

<script>
import http from 'common/js/http.js';

export default {
	data() {
		return {
			outTradeNo: '',
			paySuccess: true,
			payInfo: {}
		};
	},
	onLoad(option) {
		if (option.out_trade_no) this.outTradeNo = option.out_trade_no;
	},
	onShow() {
		this.getPayStatus();
	},
	onBackPress(options) {
		switch (parseInt(this.payInfo.type)) {
			case 1:
				// 普通订单
			case 5:
				// 预售订单
				this.$util.redirectTo('/pages/order/detail/detail', { order_id: this.payInfo.type_alis_id }, '', 'redirectTo');
				break;
			case 4:
				// 充值订单
				this.$util.redirectTo('/pages/member/index/index', {}, 'tabbar');
				break;
			default:
				this.$util.redirectTo('/pages/index/index/index', {}, 'tabbar');
				break;
		}
		return true;
	},
	methods: {
		getPayStatus() {
			this.sendRequest({
				url: 'System.Pay.payStatus',
				data: { out_trade_no: this.outTradeNo },
				success: res => {
					if (res.code == 0) {
						this.payInfo = res.data;
						this.paySuccess = true;
					} else {
						this.paySuccess = false;
					}
				}
			});
		},
		goBack() {
			switch (parseInt(this.payInfo.type)) {
				case 1:
					// 普通订单
				case 5:
					// 预售订单
					this.$util.redirectTo('/pages/order/detail/detail', { order_id: this.payInfo.type_alis_id }, '', 'redirectTo');
					break;
				case 4:
					// 充值订单
					this.$util.redirectTo('/pages/member/index/index', {}, 'tabbar');
					break;
				default:
					this.$util.redirectTo('/pages/index/index/index', {}, 'tabbar');
					break;
			}
		}
	},
	mixins: [http]
};
</script>

<style lang="scss">
page {
	overflow: hidden;
	background: #fff;
}
.callback-wrap {
	display: flex;
	flex-direction: column;
	margin-top: 200rpx;
	align-items: center;
	.callback-icon {
		width: 70px;
		height: 70px;
		line-height: 70px;
		font-size: $ns-font-size-lg + 100rpx;
		color: $ns-text-color-gray;
		text-align: center;
	}
	.icon_success {
		color: #24af41;
	}
	.icon_fail {
		color: #ff0000;
	}
	.callback-desc {
		font-size: $ns-font-size-lg + 10rpx;
	}
	.callback-btn {
		margin-top: 60rpx;
		border: 1px solid $base-color;
		color: $base-color;
		width: 300rpx;
		height: 70rpx;
		line-height: 70rpx;
		border-radius: 100rpx;
		background-color: #fff;
	}
}
</style>
