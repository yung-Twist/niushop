<template>
	<view>
		<view class="body">
			<image class="qrcode" :src="$util.img(qrcode)"></image>
			<view class="title">请将该提货码出示给门店审核人员进行提货</view>
		</view>
		<ns-login ref="login" href="pickup"></ns-login>
	</view>
</template>

<script>
import http from 'common/js/http.js';
import nsLogin from 'components/ns-login/ns-login.vue';
export default {
	components: {
		nsLogin
	},
	data() {
		return {
			qrcode: '',
			orderId: ''
		};
	},
	onLoad(e) {
		this.orderId = e.order_id;
	},
	onShow() {
		var isLogin = false;
		// #ifdef H5
		getApp().checkLogin(() => {
			isLogin = true;
			setTimeout(() => {
				this.$refs.login.clickLogin();
			}, 100);
		});
		// #endif
		// #ifdef MP
		getApp().$vm.checkLogin(() => {
			isLogin = true;
			this.$refs.login.clickLogin();
		});
		// #endif

		if (isLogin) return;

		this.getQrcode();
	},
	mixins: [http],
	methods: {
		getQrcode() {
			this.sendRequest({
				url: 'System.Order.getUniAppPickupQecode',
				data: {
					order_id: this.orderId
				},
				success: res => {
					if (res.code == 1) {
						let list = res.data.path;
						this.qrcode = list;
					}
				}
			});
		}
	}
};
</script>

<style>
page {
	background: #fff;
}
.body {
	text-align: center;
}
.qrcode {
	width: 356rpx;
	height: 356rpx;
	margin: 60rpx 0 30rpx;
}
.title {
	text-align: center;
	font-size: 28rpx;
}
</style>
