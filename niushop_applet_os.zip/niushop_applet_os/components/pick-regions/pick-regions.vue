<template>
	<view class="pick-regions">
		<picker mode="multiSelector" :value="multiIndex" :range="multiArray" @change="handleValueChange" @columnchange="handleColumnChange"><slot></slot></picker>
	</view>
</template>

<script>
import http from 'common/js/http.js';
export default {
	props: {
		defaultRegions: {
			type: Array
		}
	},
	mixins: [http],
	data() {
		return {
			pickerValueArray: [],
			cityArr: [],
			districtArr: [],
			multiIndex: [0, 0, 0],
			isInitMultiArray: false,
			// 是否加载完默认地区
			isLoadDefaultAreas: false
		};
	},
	watch: {
		defaultRegions: {
			handler(arr, oldArr = []) {
				// 避免传的是字面量的时候重复触发
				if (arr.length !== 3 || arr.join('') === oldArr.join('')) return;
				// console.log('触发了');
				this.handleDefaultRegions();
			},
			immediate: true
		}
	},
	computed: {
		multiArray() {
			if (!this.isLoadDefaultAreas) return;
			var arr = this.pickedArr.map(arr => arr.map(item => item.label));
			return arr;
		},
		pickedArr() {
			// 进行初始化
			if (this.isInitMultiArray) {
				return [this.pickerValueArray[0], this.pickerValueArray[1], this.pickerValueArray[2]];
			}
			return [this.pickerValueArray[0], this.cityArr, this.districtArr];
		}
	},
	created() {
		this.getProvince();
	},
	methods: {
		handleColumnChange(e) {
			this.isInitMultiArray = false;
			let col = e.detail.column;
			let row = e.detail.value;
			this.multiIndex[col] = row;
			switch (col) {
				case 0:
					//选择省，加载市、区县
					this.getCityCallback(this.pickerValueArray[0][this.multiIndex[col]].value, data => {
						this.cityArr = data;
						this.getDistrictCallback(this.cityArr[0].value, data => {
							this.districtArr = data;
						});
					});
					break;
				case 1:
					//选择市，加载区县
					this.getDistrictCallback(this.cityArr[this.multiIndex[col]].value, data => {
						this.districtArr = data;
					});
					break;
			}
		},
		handleValueChange(e) {
			// 结构赋值
			let [index0, index1, index2] = e.detail.value;
			let [arr0, arr1, arr2] = this.pickedArr;
			let address = [arr0[index0], arr1[index1], arr2[index2]];
			this.$emit('getRegions', address);
		},
		handleDefaultRegions() {
			var time = setInterval(() => {
				if (!this.isLoadDefaultAreas) return;
				this.isInitMultiArray = false;
				for (let i = 0; i < this.defaultRegions.length; i++) {
					for (let j = 0; j < this.pickerValueArray[i].length; j++) {
						// 匹配省
						if (this.defaultRegions[i] == this.pickerValueArray[i][j].value) {
							// 设置选中省
							this.$set(this.multiIndex, i, j);

							// 查询市
							this.getCityCallback(this.pickerValueArray[i][j].value, data => {
								this.cityArr = data;

								for (let k = 0; k < this.cityArr.length; k++) {
									if (this.defaultRegions[1] == this.cityArr[k].value) {
										// 设置选中市
										this.$set(this.multiIndex, 1, k);

										// 查询区县
										this.getDistrictCallback(this.cityArr[k].value, data => {
											this.districtArr = data;

											// 设置选中区县
											for (let u = 0; u < this.districtArr.length; u++) {
												if (this.defaultRegions[2] == this.districtArr[u].value) {
													this.$set(this.multiIndex, 2, u);
													this.handleValueChange({
														detail: {
															value: [j, k, u]
														}
													});
													break;
												}
											}
										});

										break;
									}
								}
							});
						}
					}
				}
				if (this.isLoadDefaultAreas) clearInterval(time);
			}, 100);
		},
		/* 获取省 */
		getProvince(province, city, district) {
			this.sendRequest({
				url: 'System.Address.province',
				success: res => {
					if (res.code == 0) {
						var provinceData = [];
						res.data.forEach((item, index) => {
							if (province == undefined && index == 0) {
								province = item.province_id;
							} else if (province == item.province_id) {
								this.pickerValueDefault[0] = index;
							}
							provinceData.push({
								value: item.province_id,
								label: item.province_name
							});
						});
						this.pickerValueArray[0] = provinceData;
						this.getCity(province, city, district);
					}
				}
			});
		},
		/* 获取市 */
		getCity(province, city, district) {
			this.sendRequest({
				url: 'System.Address.city',
				data: { province_id: province },
				success: res => {
					if (res.code == 0) {
						var cityData = [];
						res.data.forEach((item, index) => {
							if (city == undefined && index == 0) {
								city = item.city_id;
							} else if (city == item.city_id) {
								this.pickerValueDefault[1] = index;
							}
							cityData.push({
								value: item.city_id,
								label: item.city_name
							});
						});
						this.pickerValueArray[1] = cityData;
						this.getDistrict(province, city, district);
					}
				}
			});
		},
		/* 获取区或县 */
		getDistrict(province, city, district) {
			this.sendRequest({
				url: 'System.Address.district',
				data: { city_id: city },
				success: res => {
					if (res.code == 0) {
						var districtData = [];
						if (res.data.length) {
							res.data.forEach((item, index) => {
								if (district != undefined && district == item.district_id) {
									this.pickerValueDefault[2] = index;
								}
								districtData.push({
									value: item.district_id,
									label: item.district_name
								});
							});
						}
						this.pickerValueArray[2] = districtData;
						this.isInitMultiArray = true;
						this.isLoadDefaultAreas = true;
					}
				}
			});
		},
		/* 获取市 */
		getCityCallback(province, callback) {
			this.sendRequest({
				url: 'System.Address.city',
				data: { province_id: province },
				success: res => {
					if (res.code == 0) {
						var cityData = [];
						res.data.forEach((item, index) => {
							cityData.push({
								value: item.city_id,
								label: item.city_name
							});
						});
						if (callback) callback(cityData);
					}
				}
			});
		},
		/* 获取区或县 */
		getDistrictCallback(city, callback) {
			this.sendRequest({
				url: 'System.Address.district',
				data: { city_id: city },
				success: res => {
					if (res.code == 0) {
						var districtData = [];
						if (res.data.length) {
							res.data.forEach((item, index) => {
								districtData.push({
									value: item.district_id,
									label: item.district_name
								});
							});
						}
						if (callback) callback(districtData);
					}
				}
			});
		}
	}
};
</script>
