export default {
	methods: {
		pay(order_id){
			this.sendRequest({
				url: 'System.Pay.orderPay',
				data: {order_id},
				success: res => {
					if (res.data > 0) {
						this.$util.redirectTo('/pages/pay/pay/pay', {out_trade_no: res.data});
					}
				}
			})
		},
		/**
		 * 关闭订单
		 * @param {Object} order_id
		 */
		orderClose(order_id, callback){
			uni.showModal({
				title: '提示',
				content: '您确定要关闭该订单吗？',
				success: res => {
					if (res.confirm) {
						this.sendRequest({
							url: 'System.Order.orderClose',
							data: {order_id},
							success: res => {
								typeof callback == 'function' && callback();
							}
						})
					}
				}
			})
		},
		/**
		 * 订单收货
		 * @param {Object} order_id
		 */
		orderDelivery(order_id, callback){
			uni.showModal({
				title: '提示',
				content: '您确定已经收到货物了吗？',
				success: res => {
					if (res.confirm) {
						this.sendRequest({
							url: 'System.Order.orderTakeDelivery',
							data: {order_id},
							success: res => {
								typeof callback == 'function' && callback();
							}
						})
					}
				},
			})
		},
		/**
		 * 删除订单
		 */
		deleteOrder(order_id, callback){
			uni.showModal({
				title: '提示',
				content: '您确定要删除该订单吗？',
				success: res => {
					if (res.confirm) {
						this.sendRequest({
							url: 'System.Order.deleteOrder',
							data: {order_id},
							success: res => {
								if (res.data > 0) {
									typeof callback == 'function' && callback();
								}
							}
						})
					}
				},
			})
		},
		/**
		 * 预售订单支付
		 * @param {Object} order_id
		 */
		orderPresellPay(order_id){
			this.sendRequest({
				url: 'System.Pay.orderPresellPay',
				data: {order_id},
				success: res => {
					if (res.data > 0) {
						this.$util.redirectTo('/pages/pay/pay/pay', {out_trade_no: res.data});
					}
				}
			})
		}
	}
}