<template>
	<view v-if="pintuan.length > 0" class="pintuan-box">
		<view class="pintuan-title">
			<text></text>
			<text>拼团促销每日更新</text>
			<text class="iconfont iconright"  @click="entryPintuanList()" >查看更多</text>
		</view>		
		<view class="pintuan-goods-box">
			<block  v-for="(item, index) in pintuan" :key="index" >
				<view class="pintuan-goods" @click="entryPintuanDetail(item.goods_id)">				
					<view class="goods-img">
						<image :src="$util.img(item.pic_cover_small)" mode="aspectFit"></image>
					</view>
					<text class="goods-name">{{ item.goods_name }}</text>
					<view class="pintuan-price">
						<text>￥{{ item.tuangou_money }}</text>		
						<text>￥{{ item.promotion_price }}</text>										
					</view>
				</view>
			</block>
		</view>
	</view>	
</template>

<script>
import http from 'common/js/http.js';
export default{
	name: 'diy-pintuan',
	mixins: [http],
	props: {
		value: {
		}
	},
	data(){
		return {
			pintuan : [],
		}
	},
	created() {
		this.getPintuanList();
	},
	methods:{
		getPintuanList(){
			let condition = JSON.stringify({
				'npg.is_open': 1,
				'npg.is_show': 1
			});
			this.sendRequest({
				url: 'NsPintuan.Pintuan.goodsList',
				data: {
					page_size : 4,
					condition : condition,
					order : "npg.create_time desc"
				},
				success: res => {
					let data = res.data;
					if(data.data.length > 0){
						this.pintuan = data.data;
					}
				}
			})
		},
		entryPintuanDetail(goodsId){
			this.$util.redirectTo('/promotionpages/pintuan/detail/detail', { goods_id: goodsId });
		},
		
		entryPintuanList(){
			this.$util.redirectTo('/promotionpages/pintuan/list/list');
		}
	}
}
</script>

<style lang="scss">
	.pintuan-box{
		background: #fff;
		padding: 0rpx 20rpx;
		overflow: hidden;
		.pintuan-title{
			padding:20rpx 0rpx 10rpx 0rpx;
			text:nth-child(1){
				background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQ4AAAA3CAYAAAD9s6R0AAALDElEQVR4nO2d4XHcNhOGX2X0P5cKAleQcwWCK4hcgZgKLFcgqAJbFYhfBdZXgeAKcqnAdAW+DpIfOMoUBRDvggCPPPGZ4Yx0BIElCSwWiwV4BhlbAJveb83hkLI55NdnD2CXkF8IdTj6NEiTe+V4KPjfZZ/cdahLqN6OYQcncwk5Bp+FMUZYrON84NwjAE3kcQsgVvo3cC8ccDf6G5m2iwFwI0j/JvD7vwllnxpnnb8VgIq45gHlGmtLBe4dWwDvCsmwhWsbudkBuANQk+krAJ+IdB9R4L0MKY6c3AK4J9Nu4B5KLSzjSpC2xmptsDQALhDvRP4E8La0MCfMFq6NXAF4j7gF8oHMtx4hU5CpFEcN11MoMv0HyG64EuQNAP8TpF1xil9H0mzhV/hbcD0jgyLT5bQKivTYA2g42d8hrDw0uGdRD+QxinPwQ5IQN3hpPp550t2Br0Dbg0yWTC+xNnaCfFccFm4ochlJd3NI162sG4yrXynkLLPv05uC1vp4HzjP1vdiHeQZxiuOUL59NnC+DvZF1AD+ItJtAfxN5olDnvXA+dXH4X9/Cu79xej7vDTK+ASm4h2edzQa091Pv2zAtZ8f5PUWTon/k0+kp3zxCNdYch4hjDAfRsncC/JjKn7uZ7HEI4Qhrv2B52a0nsH9jDl07xlMeT/3L18BrmfwTMwvHsFy4SvwRpjHj0A+3aMS5KcCeRihXK+Vz4iPmTeQv+cVP9rzG+sULcpUztFTo8YyHaxXkCnaPnu4oUjMV1XBPR87oqwlYsFPA2/gnmM1kEb1/tee347CqjjS+I5lNgqdIY/PcL2eiqS7gXtGO+SLqWAV3w5uNiQHpWZU9nD+Ng1eGVwVkkXMOVzP8NVz7grcDdnA9Sv5UIg3mAaF5uw9vEd8hgVwveoe+ZSsJtPlLDMFjbgDtXV8NuDaWRvfNAvOEa5sF+Bu6CtWH0FpFOJ+A4vpFMcO08Y2rHCKejLWocpKDIVx4+o9XG8Z64FzouGc3mNhllNMxQXKW1G+tWheVsWxEqPCuFmSqSMvTxUmpklMd5GbMeYR5HCwpOIIOcQknn2m0klCmmv4Z0Ma8nofBvOYftTw97LH7jUfMJOZgJV8lFQcNvC7xDNcI2+s/VJnQ5bKDrzzb2VBlAwAC6EEaYss0FmZjCXGuiwJNtLzOnfBx1Ac7CYotqQQK5PwcGwBThgtSGtzF34M5yi7yK0pKcRKcdphipTbgXMX4BpMg2Frh41RmjOaTFdkN7SpFYcWpP1eSogVETX8KzS/RK5LHaaYyDlN5NFE8mFjlObMBZmuyIzW1IpDCdKuU3jzoMFLy6EirluHKWXRZLoiUd05FMcFXmr30P6TSpBvkybO5Bhw053sfiS+PRg04gFUFuX22ezzZ+R86jBlhUOyWbItIUAOxaHxXPvt4RZC+fhDkO+pWRzXiCsNi/k7hTeIhz+vsyll0YK0toQAJWZV7hCeRn3NjlEmfmXIMTgXmDUTcx6mtNtSLhnWv2FLCZDbxzFkbQD8C2tGSzIvKsSHaQ3mb20A8WHKA8ZH4oZgG4wK5PMrZrTCdASaTFds1XpuxfER460N4PSW6TMh6UuwNphhyv9HlpEjfF9lyqfJkEdu6IVoKNgR5RyqNBhe1i1x6JxSxGgFztqoC8uRg6UPU6TM8V60IK0tJENWi6PfY+rI/zHY9BKF9Hsg35RP8LEwe0QuwdoAuGHKqSh9Zn/VYyDxb2hE2pExpjbGNFIhcimOBi97zDH7L+T6gE+fCv4xrm8KNAcaccW2xzKsDWaY0uB5RW0wT3M/xg7zVeaaTLcDN2RLmjrPNVSZ60M+Nsw4+664FHlghinXcB1Ge6iSAhXiAcNfUTsmEv/GV3AKQWKxP5HD4miwjB5zajTivUNsFmpOxIYpPpYSi9PuUXqHec9saUFaC075SWKrnshhcazBPn4Y38ZQzMucYIYpfbp+Iwv3dbixB2vZSsv7DW4DZiu8x6mRrE/Zd/4eIsniCCkOheUHyRwThXhDW5K1kbJRrs0txIIo9RkDTaaznb9jikOlCBIaqpRyTr4WGN/GkmYgUoYpQ7E4G/Cby+wwblp0yrLa8krsSC71b7REvxtrjNHGGCsRxqc4NGa2FfvCUOCiE5fiUE5tCHbg3CX4AK2xC/f2kO3jMVZxVIg38JQ9MrQgre38zZSzhdBC9A1Vcm282x1D1oLr3kA2PpVUrNtAHlaQRwzm+dWQTYHpFEEyoeCeW/eoI9fE4mLYOtYgz7th/XAK4ztNxreVYm2m+Dfa/2P8LpTlhcWhUaaSKkHapkD5U8H2zoy10ZqmGsfdRX2Hl5UvZvrbgXMafH3IZZXVcMNvxtS/QrrVocl0KffF5r2BfFd7sYO0rzhKVdDXss8os3SeWQS2gYuDmOv6nljvNyQL6zjcI2/I9x24+n0Jp9iajGV3SVkEKPFvKMjbsRamfzZU0SkZkLA3vRRnoY8N+CnYGIwC6jPluoqYVRUyjzfgV6fmdh7XgrTMe0wlJeBP5xaijzFGSdJ3FUepmRQtSBv1AM8YprFbxK0qVgH1850q2EpHzjcI96js7AaQ33ncgFeuVeayuzzi52cLvpHXsP6NMYiGK63iqKQXCpD0nE0hGaYg10Y9FWTPbI9CnwcMEJuatQPn2GGKRZm6wDpJJZbRGBS4jpVJM5YkxVHS+SYRqCklRGEqxB1+FpwPR2Jt7OFmlRrBNWPRkfMhpdf6DhhKRSNL/AslhysSJP6NMYismnNwlX4MkqkeW0qIwjCKl2kMFfh3UWN446QSKMQ7gku4IUk/KlbiFK1FUsm4Azcs3x6O/hCwwUvLcWzHu0N4AyQ9Mm8WBUEHdI7yU32KTLdUx6hGfPk42xguMKw8d3Dfm0nxzOdAk+k+4bnfRYGPjyi9WrgG78/7gJfDwAbPpzursQLBPZ/P8LcBgzwdqsJwW1SB8r2cwwVc+aA/eR+BHaosZSVlH4t8ltKUvooUJKHnXwC8xc/KyAbqDdWDGtyzHmoAezi5cpn/OYY0G7gO/KPnnMmQP+AU3H0kDe1WKP1Bpg1e987mc0McIdhDC9IqOOXR+mCakWUjYz65OikNrrE1iFve13DWVjNGoAFqeKxeY0z3b9pYKP3RaYlj9HsxKVYAVzGrEdenOOk08vWYc4SxNix4S/JoEcLGmA0yWRw5TDklSGszlDcVNzhuGHhJmsDvqWs4blDow8cTYj2/KXDPpN0cqEZccVdwTnRfeTl56gQOFkc7VBo9OrjGzyCV2DEU1GME+aTGkWhBGYbIj83rVI/QOPjvGch2rMPHPXHdt056RZb1GCgvF6wcQ4fqZmgOQv8QZjLU4L8I8klFC8owRH7HrqTHPrTnmWxmINcxD9/zYNpJ1bvOkOWV3NbiEylD6Hg0xjz5OFpTRUM2RLEYNkFXx+iysPCbySUr8hKpwO250Q9xD0259im1/CNHROwt8NM5mlIx9vBPH3XRZF5NQvkrednD7bvp4yJybYPX9Q5T95Pdg4tTUZCt62G5xDjf5W27U1irOKRz0W2ocw5rAzi9Tz4ujR2ex1z00cT17weuPyUqcE7/OvC7Aadkb5A/1PxmxLUfTWfu9hdwYcQtbQTkG+TdPfk1VLg5soObKnyLcGXeIt5Qvh7yilmgp8AVkabGsHJgFjtukNfq0JAvLXlq78aYZ0sIzhAPRe1mIplSk8wL75CuPCTlNIhre50ox9Jgn7lCvH5085pqUdaU2M7fmkjPPFsmn37ZY1CQKY69MSbY3v8D5cywilaBdksAAAAASUVORK5CYII=) center no-repeat;
				background-size:100% 100%;
				width: 160rpx;
				height: 35rpx;
				display: block;
				margin-bottom: 4rpx;
			};
			text:nth-child(2){
				font-size: 24rpx;
				color:#ccc
			}
			.iconfont{
				position: absolute;
				right: 20rpx;
				font-size: 24rpx;
				padding-right: 28rpx;
				color: #ff0036;
				line-height: 0rpx;
			};
			.iconfont:before {
			position: absolute;
			right: 0px;		
			}
		}
		.pintuan-goods-box{
			.pintuan-goods{
				width:163rpx;
				float:left;
				margin-right: 20rpx;
				.goods-name{
					display: block;
					font-weight: bold;
					display: -webkit-box;
					-webkit-box-orient: vertical;
					-webkit-line-clamp: 1;
					overflow: hidden;
					font-size:24rpx;
					margin-top: 8rpx;
				}
				.pintuan-price{							
					width: 100%;	
					text:nth-child(1){
						display:block;
						color:#ff0036;
						font-size: 26rpx;
					}
					text:nth-child(2){
						display:block;
						font-size: 24rpx;
						color:#898989;
						text-decoration: line-through;
					}
				};
				.goods-img{
					width:100%;
					height: 163rpx;
					overflow:hidden;
					border: 1rpx solid #ebebeb;
					padding: 1rpx;
					image{
						width: 100%;;
						height:100%;
					}
				}
			}
			.pintuan-goods:nth-child(4){
				margin-right: 0rpx;
			}
		}
		.pintuan-more{
			width:80rpx;
			height: 278rpx;
			background:#fe5775;	
			float: right;
			border-radius: 11px;
			position: relative;
			margin-top:10rpx;
			text:nth-child(1){
				position: absolute;
				color:#fff;	
				top: 20rpx;
				left: 32rpx;
				font-size: 24rpx;
				display: block;
				width: 1rpx;
				
			}
			.iconfont{
				background:#fff;
				color:#fe5775;
				border-radius:25px;
				position:relative;
				top: 215rpx;
				left: 32rpx;
				font-size: 26rpx;
			}
		}
	}
	
</style>
