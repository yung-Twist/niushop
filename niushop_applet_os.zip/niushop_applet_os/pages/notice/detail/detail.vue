<template>
	<view>
		<view class="notice-meta">
			<text class="notice-time">发表时间: {{ $util.timeStampTurnTime(info.create_time) }}</text>
		</view>
		<view class="notice-content"><rich-text :nodes="htmlNodes"></rich-text></view>
	</view>
</template>

<script>
import http from 'common/js/http.js';
import htmlParser from '@/common/js/html-parser';
export default {
	data() {
		return {
			title: '',
			info: {},
			htmlNodes: [],
			noticeId: ''
		};
	},
	onLoad(event) {
		this.noticeId = event.notice_id;
		this.getDetail();
	},
	mixins: [http],
	methods: {
		getDetail() {
			var data = {
				id: this.noticeId
			};
			this.sendRequest({
				url: 'System.Shop.shopNoticeInfo',
				data: data,
				success: res => {
					if (res.code == 0) {
						this.htmlNodes = htmlParser(res.data.notice_content);
						this.info = res.data;
						uni.setNavigationBarTitle({
							title: this.info.notice_title
						});
					}
				}
			});
		}
	}
};
</script>

<style lang="scss">
page {
	background: #fff;
}
.notice-meta {
	padding: 20rpx 40rpx;
	display: flex;
	flex-direction: row;
	justify-content: flex-start;
	color: $ns-text-color-gray;
}

.notice-text {
	font-size: 26rpx;
	line-height: 50rpx;
	margin: 0 20rpx;
}

.notice-author,
.notice-time {
	font-size: $ns-font-size-base;
	color: $ns-text-color-gray;
}

.notice-content {
	padding: 0 30rpx;
	overflow: hidden;
	font-size: $ns-font-size-base;
	margin-bottom: 30rpx;
}
</style>
