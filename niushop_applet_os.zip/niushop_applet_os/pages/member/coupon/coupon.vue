<template>
	<view :class="isIphoneX ? 'padding-bottom' : ''">
		<view class="cf-container ns-border-color-gray">
			<view class="tab">
				<view @click="getMemberCounponList(1)"><text :class="type == 1 ? 'ns-text-color active' : ''">未使用</text></view>
				<view @click="getMemberCounponList(2)"><text :class="type == 2 ? 'ns-text-color active' : ''">已使用</text></view>
				<view @click="getMemberCounponList(3)"><text :class="type == 3 ? 'ns-text-color active' : ''">已过期</text></view>
			</view>
		</view>
		<view class="com-content">
			<view class="coupon-item" v-for="(item, index) in list" :key="index">
				<view class="coupon-item-box" :class="{ 'completion-collection': type != 1 }">
					<view class="coupon-pic">
						<image v-if="type == 1" :src="$util.img('upload/uniapp/goods/coupon.png')" mode="aspectFit"></image>
						<image v-else :src="$util.img('upload/uniapp/goods/no-coupon.png')" mode="aspectFit"></image>
					</view>
					<view class="coupon-item-con">
						<view class="coupon-item-name">
							¥
							<text class="num">{{ item.money }}</text>
							满{{ item.at_least }}可用
						</view>
						<text class="coupon-item-desc">{{ item.start_time }} 至 {{ item.end_time }}</text>
					</view>
				</view>
				<view class="coupon-bottom">					
					<text v-if="item.range_type == 1" class="coupon-text">全场商品可使用</text>
					<text v-else-if="item.range_type == 0" class="coupon-text">仅限购买部分商品</text>
					<block v-if="item.state == 1">
						<navigator v-if="item.range_type == 1" url="/pages/goods/list/list" class="iconfont iconright ns-text-color">去使用</navigator>
						<navigator v-else-if="item.range_type == 0" :url="'/pages/goods/list/list?coupon_type_id=' + item.coupon_type_id" class="iconfont iconright ns-text-color">去使用</navigator>
					</block>					
				</view>
			</view>
			<view v-show="isEmpty" class="coupon-empty ns-text-color-gray">您还没有{{ typeName }}优惠券</view>
		</view>
		<ns-login ref="login" href="member_coupon"></ns-login>
	</view>
</template>

<script>
import http from 'common/js/http.js';
import nsLogin from 'components/ns-login/ns-login.vue';
export default {
	components: {
		nsLogin
	},
	data() {
		return {
			type: 0,
			list: [],
			isEmpty: false,
			typeName: '',
			isIphoneX: false //判断手机是否是iphoneX以上
		};
	},
	onLoad() {
		uni.getSystemInfo({
			success: res => {
				if (res.model.search('iPhone X') != -1) {
					this.isIphoneX = true;
				}
			}
		});
	},
	onShow() {
		var isLogin = false;
		// #ifdef H5
		getApp().checkLogin(() => {
			isLogin = true;
			setTimeout(() => {
				this.$refs.login.clickLogin();
			}, 100);
		});
		// #endif
		// #ifdef MP
		getApp().$vm.checkLogin(() => {
			isLogin = true;
			this.$refs.login.clickLogin();
		});
		// #endif

		if (isLogin) return;

		this.getMemberCounponList(1);
	},
	mixins: [http],
	methods: {
		getMemberCounponList(type) {
			this.list = [];
			this.type = type;
			if (this.type == 1) {
				this.typeName = '未使用';
			} else if (this.type == 2) {
				this.typeName = '已使用';
			} else if (this.type == 3) {
				this.typeName = '已过期';
			}

			this.sendRequest({
				url: 'System.Member.coupon',
				data: {
					type: this.type
				},
				success: res => {
					if (res.code == 0) {
						this.list = res.data;
						console.log(this.list)
						this.isEmpty = this.list.length == 0 ? true : false;
					}
				}
			});
		}
	}
};
</script>

<style lang="scss">
.padding-bottom {
	padding-bottom: 68rpx !important;
}
.coupon-item {
	margin-top: 30rpx;
	padding: 30rpx;
	padding-bottom: 10rpx;
	background-color: #fff;
	.coupon-item-box {
		&.completion-collection {
			background-color: lighten($ns-bg-color-gray, 5%);
			view {
				color: $ns-text-color-gray !important;
			}
		}
		&:after {
			content: '';
			position: absolute;
			top: -14rpx;
			left: 195rpx;
			z-index: 3;
			width: 30rpx;
			height: 30rpx;
			background-color: #fff;
			border-radius: 50%;
		}
		&:before {
			content: '';
			position: absolute;
			bottom: -14rpx;
			left: 195rpx;
			z-index: 3;
			width: 30rpx;
			height: 30rpx;
			background-color: #fff;
			border-radius: 50%;
		}
		position: relative;
		display: flex;
		align-items: center;
		justify-content: space-between;
		padding: 16rpx;
		border-radius: 12rpx;
		background-color: lighten($base-color, 45%);
		.coupon-item-con {
			width: 394rpx;
			margin-left: auto;
			padding-left: 70rpx;
			height: 156rpx;
			border-left: 1px dashed #fff;
			line-height: 1;
			font-size: $ns-font-size-base;
			text {
				overflow: hidden;
				white-space: nowrap;
				text-overflow: ellipsis;
				display: inherit;
			}
		}
		.coupon-item-name {
			margin-top: 14rpx;
			white-space: nowrap;
			overflow: hidden;
			text-overflow: ellipsis;
		}
		.num {
			margin-left: 4rpx;
			margin-right: 10rpx;
			font-size: $ns-font-size-lg + 12rpx;
			font-weight: 600;
			display: inline-block !important;
			overflow: initial !important;
		}
	}
	.coupon-bottom{
		padding-left: 10rpx;
		margin-top: 17rpx;
		padding: 9rpx 10rpx;
		border-top: 1rpx dashed #eee;
		overflow: hidden;
		.coupon-text{
			font-size: 26rpx;
		}
		.iconfont{
			display: inline-block;
			position: relative;
			float: right;
			font-size: 26rpx;
			padding-right: 35rpx;
		}
		.iconfont:before {
			position: absolute;
			right: 0px;		
		}
	}
}
.coupon-pic {
	width: 144rpx;
	height: 144rpx;
	margin-right: 30rpx;
	image {
		width: 144rpx;
		height: 144rpx;
	}
}

.active {
	border-bottom: 4rpx solid $base-color;
}
.content view,
.content text,
.content text {
	color: #fff;
}

.gray {
	background-color: $ns-text-color-gray;
}

.cf-container {
	background: #fff;
	overflow: hidden;
	border-bottom: 2rpx solid;
	margin-bottom: 20rpx;
}

.tab {
	display: flex;
	justify-content: space-between;
}

.tab > view {
	text-align: center;
	width: 33%;

	text {
		display: inline-block;
		line-height: 88rpx;
	}
}

.coupon-empty {
	text-align: center;
	line-height: 80rpx;
}
</style>
