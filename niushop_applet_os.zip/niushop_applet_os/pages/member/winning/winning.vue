<template>
	<view class="nc-winning-content">
		<template v-if="winningArr.length > 0">
			<image class="winning-pic" :src="$util.img('upload/default/winning_head.png')" mode="aspectFill"></image>

			<view v-for="(item, index) in winningArr" :key="index" class="winning-body">
				<view class="winning-item">
					<view class="winning-body-tit">
						<text>{{ item.name }}</text>
						<text v-if="item.type != 4" class="tit-time">{{ item.add_time }}</text>
					</view>
					<view class="winning-body-con">
						<text v-if="item.type == 1" class="label">积分</text>
						<text v-if="item.type == 2" class="label">优惠券</text>
						<text v-if="item.type == 3" class="label">红包</text>
						<text v-if="item.type == 4" class="label">赠品</text>
						<text class="desc">{{ item.remark }}</text>
					</view>
					<view v-if="item.type == 4 && item.is_use == 0" class="winning-body-operation">
						<text class="operation-time">{{ item.add_time }}</text>
						<navigator class="draw" :url="'/pages/member/receive_prize/receive_prize?gift_id=' + item.gift_id + '&record_id=' + item.associated_gift_record_id">
							领取
						</navigator>
					</view>
				</view>
			</view>
		</template>
		<view v-else class="empty">
			<view class="iconfont iconwenzhangchaxun"></view>
			<text class="ns-text-color-gray">暂无中奖记录！</text>
		</view>
		<loading-cover ref="loadingCover"></loading-cover>
	</view>
</template>

<script>
import http from 'common/js/http.js';
import loadingCover from '@/components/loading/loading.vue';
export default {
	components: {
		loadingCover
	},
	data() {
		return {
			winningArr: []
		};
	},
	onLoad() {
		this.initWinning();
	},
	mixins: [http],
	methods: {
		initWinning() {
			this.sendRequest({
				url: 'System.Member.winningRecordQuery',
				success: res => {
					let data = res.data;
					if (res.code == 0) {
						this.winningArr = data.data;
						for (let i = 0; i < this.winningArr.length; i++) {
							this.winningArr[i].add_time = this.$util.timeStampTurnTime(this.winningArr[i].add_time);
							this.winningArr[i].remark = this.winningArr[i].remark.slice(this.winningArr[i].remark.indexOf('】') + 1);
						}
					}
					if (this.$refs.loadingCover == undefined) return;
					this.$refs.loadingCover.hide();
				}
			});
		}
	}
};
</script>

<style lang="scss">
.nc-winning-content {
	padding: 20rpx 30rpx 30rpx;
}
.winning-pic {
	width: 690rpx;
	height: 290rpx;
}
.winning-item {
	margin-top: 20rpx;
	padding: 5px 0;
	background-color: #fff;
	border-radius: 10rpx;
	.winning-body-tit {
		padding-left: 30rpx;
		padding-right: 30rpx;
		display: flex;
		justify-content: space-between;
		align-items: center;
		height: 80rpx;
		font-size: $ns-font-size-lg;
		.tit-time {
			font-size: $ns-font-size-base;
			color: $ns-text-color-gray;
		}
	}
	.winning-body-con {
		display: flex;
		padding: 0 30rpx 24rpx;
		.label {
			padding: 1rpx 6rpx;
			margin-right: 16rpx;
			height: 32rpx;
			line-height: 32rpx;
			font-size: $ns-font-size-sm;
			color: $base-color;
			border: 1rpx solid $base-color;
			border-radius: 6rpx;
			white-space: nowrap;
		}
		.desc {
			font-size: $ns-font-size-base;
			line-height: 1.5;
			overflow: hidden;
			text-overflow: ellipsis;
			display: -webkit-box;
			-webkit-line-clamp: 2;
			-webkit-box-orient: vertical;
		}
	}
	.winning-body-operation {
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 0 30rpx;
		border-top: 1px solid $ns-border-color-gray;
		height: 90rpx;
		.operation-time {
			font-size: $ns-font-size-base;
			color: $ns-text-color-gray;
		}
		.draw {
			font-size: $ns-font-size-base;
			padding: 4rpx 16rpx;
			height: 40rpx;
			line-height: 40rpx;
			color: #fff;
			background-color: $base-color;
			border-radius: 10rpx;
		}
	}
}
</style>
