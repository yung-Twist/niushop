<template>
	<view class="group-buy-box" v-if="groupBuyList.length > 0">
		<view class="group-title">
			<text class="title-img" ></text>
			<text class="iconfont iconright"  @click="entryGrooupBuyList()" >查看更多</text>
		</view>
		<view class="group-buy-goods-box">
			<view class="goods-border" v-for="(item, index) in groupBuyList" :key="index">
				<view class="group-buy-goods">
					<view class="goods-img">
						<image :src="$util.img(item.picture.pic_cover_small)"></image>
					</view>
					<text class="goods-name">{{ item.goods_name }}</text>
					<view class="goods-price">
						<view class="yuan-price">
							原价:
							<text>{{ item.promotion_price }}</text>
						</view>
						<view class="group-price">
							团购价:
							<text>{{ item.group_price }}</text>
						</view>
					</view>
					<text class="get-detail" @click="entryGrooupBuyDetail(item.goods_id)">查看详情</text>
				</view>
			</view>		
		</view>
	</view>
</template>

<script>
import http from 'common/js/http.js';
export default{
	name : 'diy-group-buy',
	mixins: [http],
	data(){
		return {
			groupBuyList : [],
		}
	},
	created() {
		this.getgroupBuyList();
	},
	methods:{
		getgroupBuyList(){
			this.sendRequest({
				url: 'NsGroupBuy.GroupBuy.goodsList',
				data: {
					page_size : 2,
				},
				success: res => {
					let data = res.data;
					if(data.data.length > 0){
						this.groupBuyList = data.data;
					}
				}
			})
		},
		
		entryGrooupBuyDetail(goodsId){
			this.$util.redirectTo('/promotionpages/groupbuy/detail/detail', { goods_id: goodsId });
		},
		
		entryGrooupBuyList(){
			this.$util.redirectTo('/promotionpages/groupbuy/list/list');
		}	
	}
}
</script>

<style lang="scss">
.group-buy-box{
	overflow: hidden;
	margin-bottom:20rpx;
	.group-title{
		line-height: 1;
		padding: 20rpx;
		position: relative;
		.title-img{
			width: 160rpx;
			height: 35rpx;
			display: inline-block;
			margin-right: 20rpx;
			background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAPcAAAAzCAYAAABL9Z7xAAAKXElEQVR4nO2dT2gc1x3HP0+YBgLZ+FZqtCByaenmkPZSe6GgHpLIUEhLaqvQQ+1i6VSI1dyjrCBHS/GtWCJRL4WVU+KeLNND1cvKPtWhUWmhtII1KaUU1C209JLXw5vZrtcz835v5r2d2d35wCKvd3Z2dme+8/vzfr/3FDU1xWkLt+sFPYqapzgHfFT2QUyQu0B35LnP7/4AOAT6wu0/ABqWbX4EDIoc1ARoIfsdD6mGuOfmej+H/K47CxyPPff53dtAB9gFNi3brkSPLE6ovrABbgi3Owh6FHLm5npfKPsAZpA14FdkW+Wrgv3s+TmcoDSAy4LtBhjLXTNBzpV9ADNKC3gf41aP08RutQfAfd8HlcDb0SM0DeCzCXzOKN+jGmFAadTiDscKxgUcv8AkVvufGA/AJwfI8wE1M0At7rBcIZ+4m/i3qMfU4p4r6pg7LOPx6ApGuDU1wZFY7h4mfqk6bfwNc9yKHjZamCGtNMGOJ9UkVrumfKTnv9LMrVuutUYplfr652vvACxn7WNhd+sI2AZ2BB/ZwJ5Iq5kjtNZB918lcdssbxkexK8tryvkcexqwWMJQR4L1QQeCbabFo8vk8gIrGC8NBuHWusT0X7XN9HrtnKIIa8A3xFsd6rudPbjJ1US96wjLfaoOj8Rbnc36FFMlgGyBOdVpdSrWmvfxUc7WLzIiOujT2pxT4YGsBFo3y1MZdwkkBat9Hm6zHeq0Vr3lFI97NVt8SiH2CQLuIlM2KfA/uh/uIp7FTO8E4IXLa+/TLLbPg2u34DZKKhYxV4PD9UpNfXJJqby0MaaUuqB1trH+X4F+Y3i+vh/uIp7kfJqcxslfnaNYdrqyL2htT5RSnWR5U52PLnnHwLnBdsdRY+nqN3y8uhgr0LrA98I8Nl5CmQayMbo+1RryO8Yf17TNjJxNzHnt0go9i7GcktIDMtqcZeHxAsJ5cqHrCcPUV1XhFt4+h211n2l1C1k329VKfVQa50n97CM3B3fJ8FqQ12hVhYNZEMrD0MfSI0zu8iHPztKKcl5HmUJ+Fi47RkZydRa3OUgzR18GvQoapyJ4mipVW0AHyilJElIMPH1x8jibDDCPk170dUtP0ZW9LBGdla1z7NJl0Wy45mk90wrlwTbDDATNtRUDK31oVLqEFnFYRNToiwZ1dlBHmc/xrQVp+Iq7h72+KWFPSbZ5tlx0DZ2cU99vW9EmfF2jR82MedRYpXbSqkdrXVWgu1D4JrD5z8z9DVOiISabbhkwAwVOORAGm+PTwnlE+lNsoGsr7zKXlWQ3zFKrm0i6ysAk2AjReCuwu5gLHcmvsXdxD5UsOv5M6eNKswUKhW3NOu9xxyeV611Vyn1OvKGoCSBuwr7CDNMlshoM5TvhJqt7njAHF4EY0izp1WItyVWe949sZu4TYKxqpTa2f7dwybuwj4Dvivd2Ke4pVZ7Gmb0DIkkmVaFeFtaanqfOT6nUfbcdQrq1Rtf/topbsIG+BZG4CJ8uuW2qqTaahskbvmxYLvQNwBp99d20KMoGVtbprrTiUtTxfH352vvfCnHoVxHEGeP4kvcksRLlzm+w0dI4+1jTNIky4W/UPxwUmkjKzXtUc/LBgzjb7AIPKew32es40uCL3HbxrVhOubhDo3EJYf/iyZL3Ekzq/pCarWbVHMFj21KCG0igV8kITzNKWowos5Vo+5T3Fl0qe/w4BZvn5CdhW0R5gJuIvcwmlRvwsdS22u11huRBR8KvKCwrePZafgQtyTxMtNxmQPSeHv0bxqLBY8lDanVrioTzeskxeQ//ea3//T9l1pfbHzhuSIJ6zPgZwXe70XctothWq22ZM4qF6TWMB4Cs9WVuzYkSGhQzbneXCgraXsek/1+a/0rX18qurOF3a3/AD/HaGcPMz+bXUe7W8N/FhX3Kna3bFpj7Tc8788l3gbjXg5I94pCTFzhe5WTSTPppO0Spj3zDTwag4Xdrb+OPI17wztKqRNMJaBI6EXHuW1Wu4e8GKNqsZvtZN1z3J9E3OMre9qst8/fTFpqWmW8hn8JUw+fx1wXO8Bvgb9gClFCCXuceL68R0qpR0qpjlJqJa3rrIjllgyXSH/sePnbSvDkBxvvAc9ZNrvtuNs8zSK28e4Wfi1V0sKFZXMJWRmsy9roLixjLPMy8o4tZyyiTqKJuRmvAURW/VPMrLM9KCZuidW2ZS0/wj0WDc6F51+wCfsxKbNfpCD9jsOTJaSFv8aIqk7iKE3whQr/ljElpsHIIewkWtHjCdF5zOuWt7FfsDarLdnHKA8cts2NcNjitrrj5GiESH6F3G9VkA7LnVDNG1Min/37X/89+PPvDz75x9/+7knYieS13La2zj72H9tlyEXiBUySJaVU7CpK3GJpMs2VWRd32VbbN4+B2xeef2H/6ktfjf+vjfme3hOkecQtWTzeZrVbyL+My7Q2hZAWGyzsbq2PPJWIO9SUzFVLQvpklhZA2MeMWR+NvxDNb96L5lq7gfnO0mmZMskjbtvdVPJjS+e/HgBvUo32xzRsJ6Il2KYIvryCFvaFIcAkbSYx3CTtSquq1b4H/DL6a+3kitYY24gaUC4DLn3iibiKW9LWabPakn0MMK2Em4S9kIau/h+v/vg1yRsyYqS0sCH0Qgq+XPOXkXU17TIZT0piAKrUS36GscxiQScRtZB2gW40xHUZuEgOi57HctsmepPExj72kZt4/FJrPTwOvb75LsUu2rskX2hvU+z7vEi2gH255vcxw5G2C2gVM5NLyJvuCrLvVWan4SlGzJ9Ef53aMSWMCh1j1VuYm/DF6G/mjd1V3H2KjyX62EdhEmqCf2h7jyWz2SF54oKikzo2gD9kvO7Lcsf99rYx5bjYxWUIrolbLbzUHZ2ES36KEe9von/HzydO5LqfMGJElFJxvckiJkR7Er82SyuOvF7gvdcwpYRZ7Fs+I77ofc/QOiC7d9u2rrkLEnEj3CY0IXsWFmE4H9k+OXqpxYzUguck1SuUiLtqy8MkcYlise1bltfvYXpqH5Lttq5han8n6Zn4XPc7dgOnoXkkpNWOv/+TzK2qzWBWxC0lKeu+jL2s8DYmQXKL7DLZBmY0IdRa3Ds8HYu69FNLVy+RLnZXJi49C3mp+m9goztPywmllVfaYu1hqanWWrJO1CphMuTxog3tkYdU2D3kiadpGDcu0iBSpWKokOzNk7iTZl5dwj4D5XiDiOTCCjHhwZUC73UVw90CnxUaSfVjFlX+br7oAyezlFDL4oTkJn5brH3GWDIlmifrCtnWuY3J+B46HGMWktqANLq4iyEu95V2soVcHWWcop/VxeQpZrl09xBmK1uexgmmym3casczZ2SR1ta5jf3C7+BP3HkXs++SP/7fQx5eTNsabm8Cv2B2BX4As72Ebx9zYb9Kcrx5DftSqYmrKEb1wDbh+kxEuoq7hykUKpLYk/ZHu8T+VSEua57FRTLisXDOIVtadNqQFMocYVZwSOOM7BLCm5gqodA0cBOpz9rvDWS1600qUJjkSNyQFK/WOSsMz8P/ADFVkAGUoGh0AAAAAElFTkSuQmCC) center no-repeat;
			background-size: 100% 100%;
		};
		.iconfont{
			position: absolute;
			right: 20rpx;
			font-size: 24rpx;
			padding-right: 28rpx;
			color: #ff0036;
			line-height: 35rpx;
		};
		.iconfont:before {
		position: absolute;
		right: 0px;		
		}
	};
	.group-buy-goods-box{
		padding:0rpx 20rpx;
		margin-bottom: 20rpx;
		.goods-border{
			padding: 20rpx;
			border: 1rpx solid #e5e5e5;
			.group-buy-goods{
				position: relative;
				overflow: hidden;
				.goods-img{
					width:200rpx;
					height:200rpx;
					float: left;
					margin-right: 20rpx;
					image{
						width: 100%;
						height: 100%;
					}
				};
				.goods-name{
					display: -webkit-box;
					-webkit-box-orient: vertical;
					-webkit-line-clamp: 2;
					overflow: hidden;
					font-size:24rpx;
					font-weight: bold;
				};
				.goods-price{
					
					.yuan-price{
						font-size:24rpx;
						display:inline-block;
						text{
							text-decoration: line-through;
							color:#898989;
							margin-left: 10rpx;
							margin-right: 20rpx;
						}
					}
					.group-price{
						font-size:24rpx;
						display:inline-block;
						color:#FF0036;
						text{
							margin-left: 10rpx;
						}
					}
				};
				.get-detail{
					position: absolute;
					background: #FF0036;
					color: #fff;
					font-size: 22rpx;
					padding: 6rpx 10rpx;
					border-radius: 12rpx;
					right: 0rpx;
					bottom: 0rpx;
				}
			}		
		}
	}
}
</style>
