<template>
	<view class="payment-container">
		<scroll-view scroll-y="true">
			<!-- 收货地址 -->
			<block v-if="orderCollationData.is_virtual == 0">
				<view class="address-wrapper" v-if="address" @click="selectAddress">
					<view class="iconfont iconlocation"></view>
					<view class="address">
						<view class="clearfix">
							<text class="name">收货人信息：{{ address.consigner }}</text>
							<text class="tel">{{ address.mobile }}</text>
						</view>
						<view class="address-detail">收货地址：{{ address.address_info }}</view>
					</view>
				</view>
				<view class="address-empty" v-else @click="selectAddress">
					<view class="add-address-icon"></view>
					<text>新增收货地址</text>
				</view>
			</block>

			<!-- 订单商品信息 -->
			<view class="goods-wrap">
				<block v-if="orderCollationData.promotion_type == 4">
					<!-- 积分兑换订单 -->
					<view class="goods-item clearfix" v-for="(item, index) in goodsList" :key="index">
						<view class="goods-img"><img :src="$util.img(item.goods_picture_info.pic_cover_small)" /></view>
						<view class="goods-info">
							<view class="goods-name">{{ item.goods_name }}</view>
							<text class="sku-name ns-text-color-gray">{{ item.goods_sku_info.sku_name }}</text>
						</view>
						<view class="goods-buy-info">
							<block v-if="item.goods_info.point_exchange_type == 1">
								<view class="price ns-text-color">
									<text class="unit">￥</text>
									{{ item.sku_price }}
								</view>
								<view class="price ns-text-color">
									<text class="unit">+</text>
									{{ item.goods_info.point_exchange }}
									<text class="point">积分</text>
								</view>
							</block>
							<block v-else>
								<view class="price ns-text-color">
									{{ item.goods_info.point_exchange }}
									<text class="point">积分</text>
								</view>
							</block>
							<view class="buy-num ns-text-color-gray">x{{ item.num }}</view>
						</view>
					</view>
				</block>
				<block v-else-if="orderCollationData.order_type == 6">
					<!-- 预售订单 -->
					<view class="goods-item clearfix" v-for="(item, index) in goodsList" :key="index">
						<view class="goods-img"><img :src="$util.img(item.goods_picture_info.pic_cover_small)" /></view>
						<view class="goods-info">
							<view class="goods-name">{{ item.goods_name }}</view>
							<text class="sku-name ns-text-color-gray">{{ item.goods_sku_info.sku_name }}</text>
						</view>
						<view class="goods-buy-info">
							<view class="price ns-text-color">
								<text class="unit">￥</text>
								{{ item.presell_price }}
							</view>
							<view class="price ns-text-color">
								<text class="point ns-text-color-gray">尾款：</text>
								<text class="unit">￥</text>
								{{ tailMoney }}
							</view>
							<view class="buy-num ns-text-color-gray">x{{ item.num }}</view>
						</view>
					</view>
				</block>
				<block v-else>
					<view class="goods-item clearfix" v-for="(item, index) in goodsList" :key="index">
						<view class="goods-img"><img :src="$util.img(item.goods_picture_info.pic_cover_small)" /></view>
						<view class="goods-info">
							<view class="goods-name">{{ item.goods_name }}</view>
							<text class="sku-name ns-text-color-gray">{{ item.goods_sku_info.sku_name }}</text>
						</view>
						<view class="goods-buy-info">
							<view class="price ns-text-color">
								<text class="unit">￥</text>
								{{ item.sku_price }}
							</view>
							<view class="buy-num ns-text-color-gray">x{{ item.num }}</view>
						</view>
					</view>
				</block>
				<!-- 赠品 -->
				<view class="goods-item clearfix" v-for="(item, index) in giftList" :key="index">
					<view class="goods-img"><img :src="$util.img(item.goods_picture_info.pic_cover_small)" /></view>
					<view class="goods-info">
						<view class="goods-name">
							<view class="gift-mark ns-bg-color">赠品</view>
							<strong>{{ item.goods_name }}</strong>
						</view>
						<text class="sku-name ns-text-color-gray">{{ item.goods_sku_info.sku_name }}</text>
					</view>
					<view class="goods-buy-info">
						<view class="price ns-text-color">
							<text class="unit">￥</text>
							0.00
						</view>
						<view class="buy-num ns-text-color-gray">x{{ item.num }}</view>
					</view>
				</view>
			</view>

			<block v-if="orderCollationData.is_virtual == 1">
				<view class="order-list option-item">
					<view class="order-name"><text>手机号码</text></view>
					<input class="uni-input order-desc" value="" maxlength="11" type="number" v-model="orderData.user_telephone" confirm-type="done" placeholder="请输入手机号码" />
				</view>
			</block>
			<!-- 支付方式 -->
			<view class="order-list" :class="{ 'option-item': orderCollationData.is_virtual == 0 }" @click="showPopup('payType')">
				<label class="order-name">支付方式</label>
				<text class="order-desc ns-text-color-gray" v-if="payType.list.length">{{ payType.list[payType.index].type_name }}</text>
				<text class="order-desc ns-text-color-gray" v-else>店铺未配置支付方式</text>
				<text class="iconfont iconright ns-text-color-gray"></text>
			</view>
			<!-- 配送方式 -->
			<view class="order-list" @click="showPopup('deliveryService')" v-if="expressType.length">
				<view class="order-name"><text>配送服务</text></view>
				<view class="order-desc ns-text-color-gray">{{ expressService.title }}</view>
				<text class="iconfont iconright ns-text-color-gray"></text>
			</view>
			<!-- 优惠券 -->
			<view class="order-list" @click="showPopup('coupon')" v-if="couponList.list.length">
				<label class="order-name">优惠券</label>
				<text class="order-desc ns-text-color" v-if="couponList.index != -1">已使用1张，可抵扣￥{{ couponList.list[couponList.index].money }}</text>
				<text class="order-desc ns-text-color" v-if="couponList.index == -1">
					<view class="coupon-mark">有{{ couponList.list.length }}张券可用</view>
					去使用
				</text>
				<text class="iconfont iconright ns-text-color-gray"></text>
			</view>
			<!-- 积分抵现 -->
			<view class="order-list" v-if="orderCollationData.max_use_point > 0">
				<label class="order-name">积分抵现</label>
				<text class="ns-text-color order-desc">(本次最大可用{{ orderCollationData.max_use_point }}积分)</text>
				<input class="uni-input order-desc" value="" type="number" v-model="orderData.point" confirm-type="done" @blur="pointChange" />
			</view>
			<!-- 发票信息 -->
			<view class="order-list" @click="showPopup('invoice')" v-if="!orderCollationData.is_virtual && orderCollationData.invoice_info">
				<label class="order-name">发票信息</label>
				<text class="order-desc ns-text-color-gray">{{ isNeedInvoice ? '需要发票' : '不需要发票' }}</text>
				<text class="iconfont iconright ns-text-color-gray"></text>
			</view>
			<!-- 订单自定义表单 -->
			<!-- <view class="order-list">
				<label class="order-name">zch</label>
				<text class="order-desc ns-text-color-gray">添写信息</text>
				<text class="iconfont iconright ns-text-color-gray"></text>
			</view> -->
			<!-- 买家留言 -->
			<view class="order-list">
				<label class="order-name">买家留言</label>
				<input class="uni-input order-desc" type="text" placeholder="留言" v-model="orderData.buyer_message" />
			</view>
			<!-- 订单结算信息 -->
			<view class="buy-section" :class="isIphoneX ? 'padding-bottom' : ''">
				<view class="money-list">
					<view class="money-item" v-if="orderCollationData.order_type == 6">
						<text>付款</text>
						<view class="payment-mode">
							<view class="f-radio inline-block" @click="orderData.presell_info.is_full_payment = 0">
								<view class="inline-block iconfont" :class="orderData.presell_info.is_full_payment == 0 ? 'iconyuan_checked' : 'iconyuan_checkbox'"></view>
								<text>定金</text>
							</view>
							<view class="f-radio inline-block" @click="orderData.presell_info.is_full_payment = 1">
								<view class="inline-block iconfont" :class="orderData.presell_info.is_full_payment == 1 ? 'iconyuan_checked' : 'iconyuan_checkbox'"></view>
								<text>全款</text>
							</view>
						</view>
					</view>
					<view class="money-item">
						<text>商品金额</text>
						<text class="ns-text-color">￥{{ goodsMoney }}</text>
					</view>
					<view class="money-item" v-if="orderData.is_virtual == 0">
						<text>运费</text>
						<text class="ns-text-color">￥{{ shippingMoney }}</text>
					</view>
					<view class="money-item" v-if="taxMoney > 0">
						<text>税费</text>
						<text class="ns-text-color">￥{{ taxMoney }}</text>
					</view>
					<view class="money-item" v-if="couponMoney > 0">
						<text>优惠券</text>
						<text class="ns-text-color">-￥{{ couponMoney }}</text>
					</view>
					<view class="money-item" v-if="pointMoney > 0">
						<text>积分抵现</text>
						<text class="ns-text-color">-￥{{ pointMoney }}</text>
					</view>
					<view class="money-item" v-if="promotionMoney > 0">
						<text>优惠金额</text>
						<text class="ns-text-color">-￥{{ promotionMoney }}</text>
					</view>
					<block v-if="orderCollationData.promotion_type == 4">
						<view class="money-item">
							<text>兑换所需积分</text>
							<text class="ns-text-color">
								{{ orderCollationData.total_buy_point }}
								<text class="ns-font-size-sm">积分</text>
							</text>
						</view>
					</block>
				</view>
				<view class="total-price">
					<text>应付：</text>
					<text class="ns-text-color">￥{{ payMoney }}</text>
				</view>
				<button type="primary" class="submit-order-btn" @click="orderCreate">提交订单</button>
			</view>
		</scroll-view>
		<!-- 支付方式弹出框 -->
		<view @touchmove.prevent.stop>
			<uni-popup ref="payType" type="bottom" :custom="true" class="payment-method" v-if="payType.list">
				<view class="popup-content">
					<view class="popup-header">
						<text class="title">支付方式</text>
						<view class="iconfont iconclose" @click="closePopup('payType')"></view>
					</view>
					<view class="popup-body">
						<view class="pay-type-list">
							<view class="pay-type-item" v-for="(item, index) in payType.list" @click="selectPayType(item, index)" :key="index">
								<view class="iconfont" :class="orderData.pay_type == item.type_id ? 'iconyuan_checked' : 'iconyuan_checkbox'"></view>
								<text>{{ item.type_name }}</text>
							</view>
						</view>
					</view>
					<view class="popup-footer"><button type="primary" @click="closePopup('payType')">确定</button></view>
				</view>
			</uni-popup>
		</view>
		<!-- 优惠券选择弹出框 -->
		<view @touchmove.prevent.stop>
			<uni-popup ref="coupon" type="bottom" :custom="true" class="payment-method" v-if="couponList.list">
				<view class="popup-content">
					<view class="popup-header">
						<text class="title">优惠券</text>
						<view class="iconfont iconclose" @click="closePopup('coupon')"></view>
					</view>
					<view class="popup-body">
						<scroll-view scroll-y="true" class="coupon-list">
							<view class="coupon-wrapper">
								<view class="coupon-item" v-for="(item, index) in couponList.list" @click="selectCoupon(item, index)" :key="index">
									<view class="iconfont" :class="orderData.coupon_id == item.coupon_id ? 'iconyuan_checked' : 'iconyuan_checkbox'"></view>
									<view class="coupon-info clearfix">
										<view class="coupon-left-view">
											<view class="money">
												<strong>{{ parseInt(item.money) }}</strong>
											</view>
											<view class="at-last">{{ item.at_least > 0 ? '满' + item.at_least + '元可用' : '无门槛任意金额可用' }}</view>
										</view>
										<view class="coupon-right-view">
											<view class="limit ns-text-color-black">
												<view class="iconfont iconyouhuiquan"></view>
												<text v-if="item.range_type">全部商品可用</text>
												<text v-else>部分商品可用</text>
											</view>
											<view class="time-limit ns-text-color-gray">有效期至{{ $util.timeStampTurnTime(item.end_time) }}</view>
										</view>
									</view>
								</view>
							</view>
						</scroll-view>
					</view>
					<view class="popup-footer"><button type="primary" @click="closePopup('coupon')">确定</button></view>
				</view>
			</uni-popup>
		</view>
		<!-- 配送服务弹出框 -->
		<view @touchmove.prevent.stop>
			<uni-popup ref="deliveryService" type="bottom" :custom="true" class="payment-method" v-if="expressType.length">
				<view class="popup-content ns-bg-color-gray">
					<view class="popup-header">
						<text class="title">配送服务</text>
						<view class="iconfont iconclose" @click="closePopup('deliveryService')"></view>
					</view>
					<view class="popup-body">
						<scroll-view scroll-y="true" class="delivery-wrapper">
							<view class="title">
								<view class="iconfont icondeliver"></view>
								<text>配送方式</text>
							</view>
							<view class="shipping-type-list">
								<view
									class="type-item"
									v-for="(item, index) in expressType"
									@click="selectExpressType(item)"
									:class="{ active: item.type_id == orderData.shipping_info.shipping_type }"
									:key="index"
								>
									{{ item.type_name }}
								</view>
							</view>

							<view class="panel logistics" v-if="orderCollationData.express_company_list.length" v-show="orderData.shipping_info.shipping_type == 1">
								<view class="panel-title">物流公司</view>
								<view class="list">
									<view class="item" v-for="(item, index) in orderCollationData.express_company_list" @click="selectShippingCompany(item)" :key="index">
										<view class="iconfont" :class="orderData.shipping_info.shipping_company_id == item.co_id ? 'iconyuan_checked' : 'iconyuan_checkbox'"></view>
										<view class="cont">
											<view class="item-title">{{ item.company_name }}</view>
										</view>
									</view>
									<view class="item no-poadding-left" @click="showPopup('shippingTime')">
										<view class="cont">
											<view class="item-text ns-text-color-gray">
												配送时间：
												<text>{{ shippingTimeText }} {{ orderData.shipping_info.distribution_time_out }} 送达</text>
											</view>
										</view>
										<view class="iconfont iconwritefill"></view>
									</view>
								</view>
							</view>
							<view class="panel pickup-point" v-if="orderCollationData.pickup_point_list.length" v-show="orderData.shipping_info.shipping_type == 2">
								<view class="panel-title">自提点</view>
								<view class="list">
									<view class="item" v-for="(item, index) in orderCollationData.pickup_point_list" @click="selectPickupPoint(item)" :key="index">
										<view class="iconfont" :class="orderData.shipping_info.pick_up_id == item.id ? 'iconyuan_checked' : 'iconyuan_checkbox'"></view>
										<view class="cont">
											<view class="item-title">{{ item.name }}</view>
											<view class="item-text ns-text-color-gray">
												{{ item.province_name }} {{ item.city_name }} {{ item.district_name }} {{ item.address }}
											</view>
										</view>
									</view>
								</view>
							</view>
						</scroll-view>
					</view>
					<view class="popup-footer"><button type="primary" @click="closePopup('deliveryService')">确定</button></view>
				</view>
			</uni-popup>
		</view>
		<!-- 配送时间 -->
		<view @touchmove.prevent.stop>
			<uni-popup ref="shippingTime" type="bottom" :custom="true" class="payment-method">
				<view class="popup-content ns-bg-color-gray">
					<view class="popup-header">
						<text class="title">配送时间</text>
						<view class="iconfont iconclose" @click="closePopup('shippingTime')"></view>
					</view>
					<view class="popup-body">
						<scroll-view scroll-y="true" class="shipping-time-wrapper">
							<view class="tit">选择配送时间</view>
							<view class="time-list clearfix">
								<view
									:class="{ active: orderData.shipping_info.shipping_time == item.t }"
									v-for="(item, index) in shippingTimeList"
									@click="selectShippingTime(item)"
									:key="index"
								>
									{{ item.y }}-{{ item.m }}-{{ item.d }} {{ item.w }}
								</view>
							</view>
							<block v-if="orderCollationData.time_slot">
								<view class="tit">选择配送时间段</view>
								<view class="time-list clearfix">
									<view
										:class="{ active: orderData.shipping_info.distribution_time_out == item }"
										v-for="(item, index) in orderCollationData.time_slot"
										@click="selectShippingTimeOut(item)"
										:key="index"
									>
										{{ item }}
									</view>
								</view>
							</block>
						</scroll-view>
					</view>
				</view>
			</uni-popup>
		</view>
		<!-- 发票信息 -->
		<view @touchmove.prevent.stop>
			<uni-popup ref="invoice" type="bottom" :custom="true" class="payment-method">
				<view class="popup-content ns-bg-color-gray">
					<view class="popup-header">
						<text class="title">发票信息</text>
						<view class="iconfont iconclose" @click="closePopup('invoice')"></view>
					</view>
					<view class="popup-body">
						<scroll-view scroll-y="true" class="invoice-wrapper">
							<view class="available-invoice">
								<text>是否需要发票</text>
								<switch style="transform:scale(0.6)" @change="needInvoice" :checked="isNeedInvoice" />
							</view>

							<view class="invoice-form" v-if="isNeedInvoice">
								<view class="form-item">
									<view class="form-label">发票类型</view>
									<view class="f-cont">
										<view class="f-radio inline-block" @click="invoiceType = 1">
											<view class="inline-block iconfont" :class="invoiceType == 1 ? 'iconyuan_checked' : 'iconyuan_checkbox'"></view>
											<text>普票</text>
										</view>
										<view class="f-radio inline-block" @click="invoiceType = 2">
											<view class="inline-block iconfont" :class="invoiceType == 2 ? 'iconyuan_checked' : 'iconyuan_checkbox'"></view>
											<text>专票</text>
										</view>
									</view>
								</view>
								<view class="form-item">
									<view class="form-label">发票抬头</view>
									<view class="f-cont">
										<input class="uni-input" type="text" value="" maxlength="30" placeholder="请输入发票抬头" v-model="invoiceData.invoice_title" />
									</view>
								</view>
								<view class="form-item">
									<view class="form-label">纳税人识别号</view>
									<view class="f-cont">
										<input
											class="uni-input"
											type="text"
											value=""
											maxlength="30"
											placeholder="请输入纳税人识别号"
											v-model="invoiceData.taxpayer_identification_number"
										/>
									</view>
								</view>
								<block v-if="invoiceType == 2">
									<view class="form-item">
										<view class="form-label">开户银行</view>
										<view class="f-cont"><input class="uni-input" type="text" value="" placeholder="请输入开户银行" v-model="invoiceData.opening_bank" /></view>
									</view>
									<view class="form-item">
										<view class="form-label">银行账号</view>
										<view class="f-cont"><input class="uni-input" type="text" value="" placeholder="请输入银行账号" v-model="invoiceData.bank_account" /></view>
									</view>
									<view class="form-item">
										<view class="form-label">企业地址</view>
										<view class="f-cont">
											<input class="uni-input" type="text" value="" placeholder="请输入企业地址" v-model="invoiceData.business_address" />
										</view>
									</view>
									<view class="form-item">
										<view class="form-label">企业电话</view>
										<view class="f-cont"><input class="uni-input" type="text" value="" placeholder="请输入企业电话" v-model="invoiceData.business_tel" /></view>
									</view>
								</block>
								<block v-if="orderCollationData.invoice_info.order_invoice_content_list.length">
									<view class="form-item"><view class="form-label">发票内容</view></view>
									<view
										class="form-item"
										v-for="(item, index) in orderCollationData.invoice_info.order_invoice_content_list"
										@click="selectInvoiceContent(index)"
										:key="index"
									>
										<view class="f-cont">
											<view class="f-radio">
												<view class="inline-block iconfont" :class="invoiceData.invoice_content == index ? 'iconyuan_checked' : 'iconyuan_checkbox'"></view>
												<text>{{ item }}</text>
											</view>
										</view>
									</view>
								</block>
							</view>
						</scroll-view>
					</view>
					<view class="popup-footer"><button type="primary" @click="closePopup('invoice')">确定</button></view>
				</view>
			</uni-popup>
		</view>
		<loading-cover ref="loadingCover"></loading-cover>
		<ns-login ref="login" href="payment"></ns-login>
	</view>
</template>

<script>
import uniPopup from 'components/uni-popup/uni-popup.vue';
import http from 'common/js/http.js';
import payment from '../public/js/payment.js';
import loadingCover from '@/components/loading/loading.vue';
import nsLogin from 'components/ns-login/ns-login.vue';

export default {
	components: {
		uniPopup,
		loadingCover,
		nsLogin
	},
	data() {
		return {
			is_sub: false,
			isIphoneX: false, //判断手机是否是iphoneX以上
			orderCreateData: {},
			orderCollationData: {},
			// 收货地址
			address: {
				address_info: ''
			},
			goodsList: [], // 订单商品
			giftList: [], // 赠品
			couponList: {
				// 优惠券列表
				list: [],
				index: 0
			},
			payType: {
				// 支付方式
				list: [],
				index: 0
			},
			expressType: [], // 配送方式
			expressService: { title: '' },
			shippingTimeText: '工作日、双休日与节假日均可送货',
			orderData: {
				order_type: '',
				goods_sku_list: '',
				is_virtual: 0,
				buyer_ip: '',
				pay_type: 0,
				coupon_id: 0,
				promotion_type: 0,
				promotion_info: '',
				shipping_info: {
					shipping_type: 0,
					shipping_company_id: 0,
					pick_up_id: 0,
					shipping_time: 0,
					distribution_time_out: ''
				},
				buyer_message: '',
				point: 0,
				user_telephone: ''
			},
			shippingTimeList: [],
			taxMoney: '0.00', // 税费
			totalMoney: '0.00', // 订单总金额
			shippingMoney: '0.00', // 运费
			promotionMoney: '0.00', // 优惠金额
			goodsMoney: '0.00', // 商品总金额
			payMoney: '0.00', // 实际需支付
			pointMoney: '0.00', // 积分抵现金额
			couponMoney: '0.00', // 优惠券金额
			isNeedInvoice: false, // 是否需要发票
			invoiceType: 1,
			invoiceData: {
				invoice_title: '',
				taxpayer_identification_number: '',
				opening_bank: '',
				bank_account: '',
				business_address: '',
				business_tel: '',
				invoice_content: 0
			}
		};
	},
	onShow() {
		var isLogin = false;
		// #ifdef H5
		getApp().checkLogin(() => {
			isLogin = true;
			setTimeout(() => {
				this.$refs.login.clickLogin();
			}, 100);
		});
		// #endif
		// #ifdef MP
		getApp().$vm.checkLogin(() => {
			isLogin = true;
			this.$refs.login.clickLogin();
		});
		// #endif

		if (isLogin) return;

		this.getOrderData();

		/**
		 * 获取当前3日后7天的时间数据
		 */
		for (let i = 3; i < 10; i++) {
			this.shippingTimeList.push(this.$util.getDay(i));
		}
	},
	onLoad(){
		uni.getSystemInfo({
			success: res => {
				if (res.model.search('iPhone X') != -1) {
					this.isIphoneX = true;
				}
			}
		});
	},
	onUnload() {
		// uni.removeStorage({key: 'orderCreateData'});
	},
	mixins: [http, payment]
};
</script>

<style lang="scss">
@import '../public/css/payment.scss';
</style>
