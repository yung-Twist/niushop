<template>
	<view class="help">
		<view class="content">
			<view class="content-title">{{ title }}</view>
			<rich-text :nodes="htmlNodes"></rich-text>
		</view>
		<loading-cover ref="loadingCover"></loading-cover>
	</view>
</template>

<script>
import http from 'common/js/http.js';
import htmlParser from '@/common/js/html-parser';
import loadingCover from '@/components/loading/loading.vue';
export default {
	components: {
		loadingCover
	},
	data() {
		return {
			id: '',
			title: '',
			htmlNodes: ''
		};
	},
	onLoad(event) {
		this.id = event.id;
		this.sTabtap();
	},
	mixins: [http],
	methods: {
		sTabtap() {
			this.sendRequest({
				url: 'System.Shop.helpInfo',
				data: { id: this.id },
				success: res => {
					let content = res.data.data[0].content;
					this.title = res.data.data[0].title;
					this.htmlNodes = htmlParser(content);
					if (this.$refs.loadingCover == undefined) return;
					this.$refs.loadingCover.hide();
				}
			});
		}
	}
};
</script>

<style lang="scss">
page {
	background: #fff;
}
.help {
	height: 100%;
	box-sizing: border-box;
	padding-top: 20rpx;
	.content {
		padding: 0 30rpx;
		width: 100%;
		box-sizing: border-box;
		.content-title {
			text-align: center;
			padding: 20rpx 0;
			font-weight: bold;
			font-size: $ns-font-size-lg;
		}
	}
}
</style>
