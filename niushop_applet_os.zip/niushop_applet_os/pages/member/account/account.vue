<template>
	<view class="nc-info-list-content">
		<view class="info-list" v-for="(item, index) in listInfo" :key="index">
			<view class="info-item">
				<view class="info-item-content" @click="checkAccount(item.id)">
					<text>姓名：{{ item.realname }}</text>
				</view>
				<view class="info-item-operation">
					<text v-if="item.is_default != 1" @click="deleteAccount(item.id)">【删除】</text>
					<text @click="addAccount('edit', item.id)">【修改】</text>
				</view>
			</view>
			<view @click="checkAccount(item.id)">
				<view class="info-item">
					<view class="info-item-content">
						<text>账号类型：{{ item.account_type_name }}</text>
					</view>
				</view>
				<view class="info-item">
					<view class="info-item-content">
						<text>手机号码：{{ item.mobile }}</text>
					</view>
				</view>
				<view v-if="item.account_type == 1 || item.account_type == 3" class="info-item">
					<view class="info-item-content">
						<text>提现账号：{{ item.account_number }}</text>
					</view>
				</view>
				<view class="info-item" v-else-if="item.account_type == 2" style="display: none;"></view>
				<view class="info-item" v-else-if="item.account_type == 3">
					<view class="info-item-content">
						<text>支行信息：{{ item.branch_bank_name }}</text>
					</view>
				</view>
			</view>
		</view>
		<button class="add-account" type="primary" @click="addAccount('add')">新增账户</button>
	</view>
</template>

<script>
import http from 'common/js/http.js';
export default {
	data() {
		return {
			listInfo: [], //账号列表
			goback: '', // 返回页
			backparam: '' // 返回页参数
		};
	},
	mixins: [http],
	onLoad(option) {
		if (option.goback) this.goback = option.goback;
		if (option.backparam) this.backparam = JSON.parse(option.backparam);
	},
	onShow() {
		this.getListInfo();
	},
	methods: {
		/* 获取账户信息 */
		getListInfo() {
			this.sendRequest({
				url: 'System.Member.accountQuery',
				success: res => {
					this.listInfo = res.data;
				}
			});
		},
		checkAccount(id) {
			this.sendRequest({
				url: 'System.Member.modifyAccountDefault',
				data: { id: id },
				success: res => {
					if (res.data > 0) {
						if (this.goback) {
							var pages = getCurrentPages();
							for (let i = pages.length - 1; i > 0; i--) {
								if (this.goback == 'apply_withdrawal' && pages[i].route.indexOf('pages/member/apply_withdrawal/apply_withdrawal') > -1) {
									// 返回到余额提现
									//list->apply_withdrawal
									uni.navigateBack({
										delta: 1
									});
									break;
								}
								if (this.goback == 'apply_withdrawal' && pages[i].route.indexOf('distributionpages/to_withdraw/to_withdraw') > -1) {
									// 返回到推广提现
									//list->apply_withdrawal
									uni.navigateBack({
										delta: 1
									});
									break;
								}
							}
						} else {
							this.getListInfo();
							this.$util.showToast({ title: '修改默认地址成功' });
						}
					} else {
						this.$util.showToast({ title: res.message });
					}
				}
			});
		},
		/* 删除账户信息 */
		deleteAccount(id) {
			uni.showModal({
				title: '操作提示',
				content: '确定要删除该账户吗？',
				success: res => {
					if (res.confirm) {
						this.sendRequest({
							url: 'System.Member.deleteAccount',
							data: { id: id },
							success: res => {
								if (res.code == 0) {
									this.$util.showToast({ title: '删除成功' });
									this.getListInfo();
								} else {
									this.$util.showToast({ title: '删除失败' });
								}
							}
						});
					}
				}
			});
		},

		/* 增加或修改账户信息 */
		addAccount(type, id) {
			let data = {};
			if (this.goback) data.goback = this.goback;
			if (this.backparam) data.backparam = JSON.stringify(this.backparam);
			if (type == 'add') {
				this.$util.redirectTo('/pages/member/account_edit/account_edit', data);
			} else {
				data.id = id;
				this.$util.redirectTo('/pages/member/account_edit/account_edit', data);
			}
		}
	}
};
</script>

<style lang="scss">
page {
	overflow: hidden;
}
.nc-info-list-content {
	/* #ifdef H5*/
		height: 100vh;
	 /* #endif */ 
	/* #ifdef MP*/
		height: 100vh;
	 /* #endif */ 
	
	overflow-y: scroll;
}
.info-list {
	position: relative;
	margin-top: 20rpx;
	background-color: #fff;
	&:after {
		content: '';
		position: absolute;
		top: 0;
		left: 0;
		right: 0;
		height: 4rpx;
		background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAAAEBAMAAADfWWRjAAAAIVBMVEUAAAAyhPr/bm4zhPv/bm4zhfz/b28zhfz/cHAyg/r/bW0RhIYcAAAACXRSTlMA0dHDw1paS0u6tlG1AAAAPElEQVQI12NgW4UCljAwsM5EAZMZGBiYUBWtYGBgRFU0HaioC1WRAgNDJaoiAaAiL1RFCQwMlqiKAhgYAEHZS5OAMg/cAAAAAElFTkSuQmCC)
			repeat-x;
	}
	.info-item {
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: $ns-padding;
		height: 40rpx;
		border-bottom: 2rpx solid $ns-border-color-gray;
		font-size: $ns-font-size-base;
	}
}
.add-account {
	margin: 50rpx 50rpx;
}
</style>
