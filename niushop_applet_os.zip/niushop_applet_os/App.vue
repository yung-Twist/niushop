<script>
import http from 'common/js/http.js';
export default {
	mixins: [http],
	onLaunch: function() {
		// 隐藏原生tarbar
		uni.hideTabBar()
		// 当uni-app 初始化完成时触发（全局只触发一次）

		// #ifdef MP
		const updateManager = uni.getUpdateManager();
		updateManager.onCheckForUpdate(function(res) {
			// 请求完新版本信息的回调
		});

		updateManager.onUpdateReady(function(res) {
			uni.showModal({
				title: '更新提示',
				content: '新版本已经准备好，是否重启应用？',
				success(res) {
					if (res.confirm) {
						// 新的版本已经下载好，调用 applyUpdate 应用新版本并重启
						updateManager.applyUpdate();
					}
				}
			});
		});

		updateManager.onUpdateFailed(function(res) {
			// 新的版本下载失败
		});
		// #endif
	},
	onShow: function() {
		// 当 uni-app 启动，或从后台进入前台显示
		// #ifdef MP
		this.openAutoLogin();
		// #endif
	},
	onHide: function() {
		// 当 uni-app 从前台进入后台
	},
	methods: {
		/**
		 * 检测是否登录
		 * @param {function} callback 未登录时回调函数
		 */
		checkLogin(callback) {
			const token = uni.getStorageSync('token');
			if (!token) {
				// #ifdef H5
				if (this.$util.isWeiXin()) {
					const getUrlCode = function() {
						var url = location.search;
						var theRequest = new Object();
						if (url.indexOf('?') != -1) {
							var str = url.substr(1);
							var strs = str.split('&');
							for (var i = 0; i < strs.length; i++) {
								theRequest[strs[i].split('=')[0]] = strs[i].split('=')[1];
							}
						}
						return theRequest;
					};
					var urlParams = getUrlCode();
					if (urlParams.code == undefined || urlParams.code == '') {
						typeof callback == 'function' && callback();
					} 
				} else {
					typeof callback == 'function' && callback();
				}
				// #endif
				
				// #ifndef H5
				typeof callback == 'function' && callback();
				// #endif
			}
		},
		// #ifdef MP

		/**
		 * 获取openid
		 */
		getOpenid(callback) {
			// 获取服务商
			var provider = [];
			uni.getProvider({
				service: 'oauth',
				success: res => {
					provider = res.provider;
				}
			});
			if (provider[0] != undefined) {
				uni.login({
					provider: provider[0],
					timeout: 3000,
					scopes: 'auth_user',
					success: res => {
						if (res.errMsg == 'login:ok') {
							switch (provider[0]) {
								// 微信小程序
								case 'weixin':
									this.sendRequest({
										url: 'System.Login.getWechatBasicInfo',
										data: { code: res.code },
										success: res => {
											if (res.data != undefined) {
												var data = JSON.parse(res.data);
												if (data.errcode == undefined) {
													Object.assign(data, { provider: 'weixin' });
													if (callback) callback(data);
												} else {
													this.$util.showToast({title: data.errmsg});
												}
											}
										}
									});
									break;
							}
						} else {
							this.$util.showToast({
								title: res.errMsg
							});
						}
					}
				});
			}
		},
		
		/**
		 * 自动登录
		 */
		checkOpenidIsExits(data) {
			this.sendRequest({
				url: 'System.UniApp.checkOpenidIsExits',
				data: data,
				success: res => {
					if (res.data.is_bound) {
						uni.setStorage({
							key: 'token',
							data: res.data.token,
							success: () => {
								// #ifdef H5
								let url = window.location.href,
									domain = url.split('?')[0],
									hash = url.split('#')[1];
								location.href = domain + '#' + hash;
								// #endif

								var page = getCurrentPages().pop();
								if (page == undefined || page == null) return;
								page.onShow();
							}
						});
					}
				}
			});
		},

		init() {
			var data = uni.getStorageSync('bind_data');
			if (data) {
				this.checkOpenidIsExits(data);
			} else {
				this.getOpenid(params => {
					let data = {};
					if (params.provider) data.provider = params.provider;
					if (params.openid) data.openid = params.openid;
					if (params.unionid) data.unionid = params.unionid;
					Object.assign(data, params);
					this.checkOpenidIsExits(data);
				});
			}
		},
		
		/**
		 * 是否开启自动登录
		 */
		openAutoLogin(){
			this.sendRequest({
				url: 'System.Login.getRegisterAndVisitInfo',
				success: res => {
					if(res.data.is_login == 1){
						this.init();
					}
				}
			});
		}
		
		// #endif
	}
};
</script>

<style lang="scss">
/*每个页面公共css */
@import url('./common/css/iconfont');
@import url('./common/css/main.css');
@import "colorui/main.css";
@import "colorui/icon.css";
page{
	background-color: #F2F2F2;
	font-family:Microsoft YaHei;
	font-weight:400;
	color:#343434;
	padding-bottom: calc(var(--window-bottom) + 126upx);
}
</style>
