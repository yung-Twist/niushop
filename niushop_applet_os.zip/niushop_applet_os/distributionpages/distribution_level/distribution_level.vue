<template>
	<view>
		<view class="distribution-container" v-if="promoterInfo">
			<view class="member-head">
				<navigator class="user-info-box">
					<view class="face-img">
						<image :src="memberInfo.user_headimg ? $util.img(memberInfo.user_headimg) : $util.img('upload/uniapp/default_head.png')" mode="aspectFill"></image>
					</view>
					<view class="info">
						<text class="promoter-shop-name">{{ promoterInfo.promoter_shop_name }}</text>
						<view class="level-name">						
							<text>当前消费：<text>{{ user_consume }}</text>元</text>
						</view>
					</view>
				</navigator>
				
				<view class="distribution-level">
					<image :src="$util.img('upload/uniapp/icon-img.png')" class="distribution-img" mode="aspectFit"></image>
					<text class="distribution-level-name">{{ promoterInfo['promoter_level_info']['level_name'] }}</text>
					<view class="level-type" v-if="level_next_info">
						<view class="level-type-top">
							<text class="small-level">{{ promoterInfo['promoter_level_info']['level_name'] }}</text>
							<text class="next-level">{{ level_next_info['level_name'] }}</text>
						</view>
						<view class="level-type-in">
							<view :style="{width:percent + '%;'}"></view>
						</view>
						<view class="level-type-bottom">
							<text class="level-type-name">你还需{{ level_next_info.level_money - user_consume }}元</text>
							<text class="level-money">{{ level_next_info['level_money'] }}元</text>
						</view>
					</view>
					<view v-else class="no-level-next">
						您当前已经是最高等级
					</view>
				</view>
				
				<view class="triangle"></view>
			</view>
			<block v-for="(item, index) in promoter_level" :key="index" >
				<view class="level-text" v-if="item.level_money >= promoterInfo.promoter_level_info.level_money && index <= 2">
					<text class="level-title">{{ item['level_name'] }}</text>
					<view class="level-dis">
						<view >
							<text class="level-ratio">{{ item['level_0'] }}%</text>
							<text class="level-ratio-name">本店佣金比例</text>
						</view>
						<view>
							<text class="level-ratio">{{ item['level_1'] }}%</text>
							<text class="level-ratio-name">上级佣金比例</text>						
						</view>
						<view>
							<text class="level-ratio">{{ item['level_2'] }}%</text>
							<text class="level-ratio-name">上上级佣金比例</text>
						</view>
					</view>
				</view>
			</block>
			<view class="level-bottom">
				<view class="level-bottom-box">
					<view class="bottom-box-img">
						<image :src="$util.img('upload/uniapp/level-item-1.png')" mode="aspectFit"></image>
					</view>
					<view class="bottom-box-text">
						<text class="box-text-top">无门槛加入</text>
						<text class="box-text-bottom">零成本，不囤货，轻松获利</text>
					</view>
				</view>
				<view class="level-bottom-box">
					<view class="bottom-box-img">
						<image :src="$util.img('upload/uniapp/level-item-3.png')"></image>
					</view>
					<view class="bottom-box-text">
						<text class="box-text-top">多维度推广</text>
						<text class="box-text-bottom">店铺，商品二维码任选</text>
					</view>
				</view>
				<view class="level-bottom-box">
					<view class="bottom-box-img">
						<image :src="$util.img('upload/uniapp/level-item-2.png')"></image>
					</view>
					<view class="bottom-box-text">
						<text class="box-text-top">新增团队玩法</text>
						<text class="box-text-bottom">支持线上组队，奖励更多</text>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
import http from 'common/js/http.js';

export default {
	components: {
	},
	data() {
		return {
			memberInfo: {},
			promoterInfo: {
				background_img: '',
				promoter_level_info: ''
			},
			uid: 0,
			promoter_level: {},
			user_consume : 0,
			level_next_info : "",
			percent: 0
		};
	},
	onLoad(data) {},
	onShow() {
		this.getMemberInfo();
		this.getPromoterDetail();
		this.getCheckApplyPromoter();
	},
	mixins: [http],
	methods: {
		//获取用户信息
		getMemberInfo() {
			this.sendRequest({
				url: 'System.Member.memberInfo',
				success: res => {
					if (res.code == 0 && res.data) {
						this.memberInfo = res.data.user_info;
						this.uid = this.memberInfo.uid;
					}
				}
			});
		},
		//推广详情
		getPromoterDetail() {
			this.sendRequest({
				url: 'Nsfx.Distribution.promoterDetail',
				success: res => {
					if (res.code == 0) {
						
						this.promoterInfo = res.data;						
					}
				}
			});
		},
		
		getCheckApplyPromoter() {
			this.sendRequest({
				url: 'System.Distribution.checkApplyPromoter',
				success: res => {
					if (res.code == 0) {
						this.user_consume = res.data.user_consume;
						this.promoter_level = res.data.promoter_level;
						for (let i = 0; i < this.promoter_level.length; i++) {
							if(this.promoter_level[i]['level_money'] > this.promoterInfo.promoter_level_info.level_money){
								this.level_next_info = this.promoter_level[i];
								this.percent = (this.user_consume - this.promoterInfo.promoter_level_info.level_money) / (this.level_next_info.level_money -
									this.promoterInfo.promoter_level_info.level_money) * 100;
								break;
							}
						}
					}
				}
			});
		}
	}
}
</script>

<style lang="scss">
%flex-row-centered {
	display: flex;
	justify-content: space-around;
	align-items: center;
}

%flex-column-centered {
	display: flex;
	flex-direction: column;
	justify-content: center;
	align-items: center;
}

.member-head {
	padding: 70rpx 50rpx 35rpx;
	box-sizing: border-box;
	background-size: cover !important;
	background:#000;
	position: relative;
	.user-info-box {
		display: flex;
		align-items: flex-start;

		.face-img {
			box-sizing: content-box;
			width: 115rpx;
			height: 115rpx;
			border: 6rpx solid #fff;
			border-radius: 50%;
			overflow: hidden;

			image {
				width: 115rpx;
				height: 115rpx;
				vertical-align: middle;
			}
		}

		.info {
			max-width: 45%;
			margin-left: 20rpx;
			overflow: hidden;
			color: #c4a66c;
			.promoter-shop-name {
				display: block;
				max-width: 300rpx;
				overflow: hidden;
				text-overflow: ellipsis;
				white-space: nowrap;
				font-size: 36rpx;
				color: #c4a66c;
			}
			.level-name {
				color: #c4a66c;
				font-size:24rpx;
			}
		}
	}
	.distribution-level {
		text-align:center;
		position:relative;
		.distribution-img {
			width: 285rpx;
			height: 340rpx;
		}
		.distribution-level-name {
			position: absolute;
			color: #fff;
			top: 212rpx;
			width: 100%;
			left: 0;
			font-size: 30rpx;
		}
		.level-type {
			margin-top:-55rpx;
			.level-type-top {
				color:#c4a66c;
				overflow:hidden;
				font-size:24rpx;
				.small-level {
					float:left;
				}
				.next-level {
					float:right
				}
			}
			.level-type-in {
				background:#615244;
				overflow:hidden;
				margin: 14rpx 0rpx;
				border-radius:4rpx;
				width:100%;
				height:10rpx;
				view {
					float: left;
					height: 100%;
					font-size: 6rpx;
					line-height: 10rpx;
					background: linear-gradient(to right, #ad9171, #d8bc98);
					text-align: center;
					border-radius: 4rpx;
				}
			}
			.level-type-bottom {
				color:#c4a66c;
				overflow:hidden;
				font-size:24rpx;
				.level-type-name {
					float:left;
				}
				.level-money {
					float:right;
				}
			}
		}
		.no-level-next {
			width: 100%;
			font-size: 24rpx;
			text-align: center;
			color: #c4a66c;
			margin-top: -40rpx;
			opacity: 0.6;
		}
	}
	.triangle {
	    position: absolute;
	    bottom: -20rpx;
	    left: 48.5%;
	    width: 0px;
	    height: 0px;
	    border-top: 20rpx solid #2b2421;
	    border-left: 20rpx solid transparent;
	    border-right: 20rpx solid transparent;
	}
}
.level-text {
	margin-top :40rpx;
	padding:0rpx 30rpx;
	.level-title {
		display: block;
		padding: 12rpx 0rpx;
		font-size: 32rpx;
	}
	.level-dis {
		view {
			width: 170rpx;
			display: inline-block;
			padding: 20rpx;
			margin-right : 30rpx;
			background: #fff;
			.level-ratio {
				width: 100%;
				display: block;
				text-align: center;
				color: #f28c3d;
				font-weight: 600;
				font-size: 32rpx;
			}
			.level-ratio-name {
				width: 100%;
				display: block;
				text-align: center;
				font-size: 22rpx;
			}	
		}
		view:nth-child(3n) {
		    margin-right: 0;
		}
	}
}
.level-bottom {
	padding: 0rpx 30rpx;
	margin-top: 30rpx;
	margin-bottom: 80rpx;
	.level-bottom-box{		
		overflow: hidden;
		background: #fff;
		border-bottom: 2rpx solid #e0e0e0;
		.bottom-box-img {
			width: 100rpx;
			height: 140rpx;
			display: flex;
			justify-content: center;
			align-items: center;
			float: left;
			image {
				width:50rpx;
				height :50rpx
			}
		}
		.bottom-box-text {
			float:left;
			padding: 21rpx 0rpx;
			line-height: 54rpx;
			.box-text-top {
				display: block;
			}
			.box-text-bottom {
				display: block;
			}
		}
		
	}
}

</style>

