<template>
	<view>
		<view class="withdraw" v-if="withdrawList.length > 0">
			<view v-for="(item, index) in withdrawList" :key="index" class="ns-border-color-gray ns-padding">
				<view>
					<text>{{ item.bank_name }}</text>
					<text class="ns-text-color">¥{{ item.cash }}</text>
				</view>
				<view class="ns-text-color-gray">
					<text class="withdraw-text">{{ $util.timeStampTurnTime(item.ask_for_date) }}</text>
					<text class="ns-text-color">{{ item.status }}</text>
				</view>
			</view>
		</view>
		<uni-load-more :status="status" :content-text="contentText" v-if="withdrawList.length > 0 && pageCount > 1" />
		<view v-if="isEmpty && withdrawList.length == 0" class="empty">
			<view class="iconfont iconwenzhangchaxun"></view>
			<view class="ns-text-color-gray">您暂时还没有提现记录哦！</view>
		</view>
		<ns-login ref="login" href = 'withdrawal'></ns-login>
	</view>
</template>

<script>
import http from 'common/js/http.js';
import uniLoadMore from '@/components/uni-load-more/uni-load-more.vue';
import nsLogin from 'components/ns-login/ns-login.vue';
export default {
	components: {
		uniLoadMore,
		nsLogin
	},
	data() {
		return {
			withdrawList: [],
			isEmpty: false,
			pageIndex: 1,
			pageCount: 0,
			pageSize: 10,
			contentText: {
				contentdown: '上拉加载更多',
				contentrefresh: '加载中',
				contentnomore: '没有更多了'
			},
			status: 'loading',
			ident: false //防止初始化时，触发上拉加载
		};
	},
	onShow() {
		var isLogin = false;
		// #ifdef H5
		getApp().checkLogin(() => {
			isLogin = true;
			setTimeout(() => {
				this.$refs.login.clickLogin();
			}, 100);
		});
		// #endif
		// #ifdef MP
		getApp().$vm.checkLogin(() => {
			isLogin = true;
			this.$refs.login.clickLogin();
		});
		// #endif

		if (isLogin) return;

		this.getWithdrawList();
	},
	onPullDownRefresh() {
		this.getWithdrawList('refresh');
	},
	onReachBottom() {
		if (!this.ident) return;
		this.getWithdrawList();
	},
	mixins: [http],
	methods: {
		getWithdrawList(type = 'add') {
			if (type === 'add') {
				if (this.status === 'nomore') return;
				this.status = 'loading';
			} else {
				this.status = 'more';
			}
			if (type === 'refresh') {
				this.status = 'loading';
				this.pageIndex = 1;
				this.withdrawList = [];
			}

			var data = {
				page_size: this.pageSize,
				page_index: this.pageIndex
			};
			this.sendRequest({
				url: 'System.Member.withdrawRecordList',
				data: data,
				success: res => {
					this.ident = true;
					if (res.code == 0) {
						let list = res.data.data;
						this.pageCount = res.data.page_count;

						if (this.pageCount == 0) {
							this.status = 'nomore';
							this.isEmpty = true;
							this.contentText.contentnomore = '';
						} else {
							if (this.pageIndex < this.pageCount) {
								this.status = 'more';
							} else {
								this.status = 'nomore';
								this.contentText.contentnomore = '没有更多了';
							}
							this.isEmpty = false;

							if (list.length > 0) {
								if (type === 'refresh') {
									this.withdrawList = list;
								} else {
									this.withdrawList = this.withdrawList.concat(list);
								}
								this.pageIndex++;
							}
						}
					}

					if (type === 'refresh') {
						uni.stopPullDownRefresh();
					}
				}
			});
		}
	}
};
</script>

<style lang="scss">
.no-more {
	view {
		text-align: center;
		line-height: 1;
	}

	.iconfont {
		font-size: 220rpx;
		color: $ns-text-color-gray;
	}
}

.withdraw > view {
	border-bottom: 2rpx solid;
	background: #fff;
	padding: $ns-padding;
}

.withdraw > view > view {
	display: flex;
	justify-content: space-between;
}

.withdraw-text {
	width: 60%;
}

.empty {
	text-align: center;
}
</style>
