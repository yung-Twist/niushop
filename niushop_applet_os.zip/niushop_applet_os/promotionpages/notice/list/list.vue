<template>
	<view>
		<view class="uni-list" v-if="listData.length > 0">
			<view class="uni-list-cell" hover-class="uni-list-cell-hover" v-for="(value, key) in listData" :key="key" @click="goDetail(value)">
				<view class="uni-media-list-body">
					<view class="uni-media-list-text-top">{{ value.notice_title }}</view>
					<view class="uni-media-list-text-bottom">
						<text>{{ $util.timeStampTurnTime(value.create_time) }}</text>
					</view>
				</view>
			</view>
		</view>
		<uni-load-more :status="status" v-if="listData.length > 0 && pageCount > 1" />
		<view v-if="isEmpty && listData.length == 0" class="empty">
			<view class="iconfont iconwenzhangchaxun"></view>
			<view class="ns-text-color-gray">暂无公告</view>
		</view>
	</view>
</template>

<script>
import http from 'common/js/http.js';
import uniLoadMore from '@/components/uni-load-more/uni-load-more.vue';

export default {
	components: {
		uniLoadMore
	},
	data() {
		return {
			listData: [],
			pageIndex: 1,
			pageCount: 0,
			pageSize: 10,
			status: 'loading',
			isEmpty: false,
			ident: false //防止初始化时，触发上拉加载
		};
	},

	onLoad() {
		this.getList();
	},
	onPullDownRefresh() {
		this.getList('refresh');
	},
	onReachBottom() {
		if (!this.ident) return;
		this.getList();
	},
	mixins: [http],
	methods: {
		getList(type = 'add') {
			if (type == 'refresh') {
				this.status = 'loading';
				this.pageIndex = 1;
				this.listData = [];
			}
			var data = {
				page_size: this.pageSize,
				page_index: this.pageIndex
			};
			this.sendRequest({
				url: 'System.Shop.shopNoticeList',
				data: data,
				success: res => {
					this.ident = true;
					if (res.code == 0) {
						var data = res.data;
						let list = data.data;
						this.pageCount = res.data.page_count;
						if (this.pageCount == 0) {
							this.status = 'nomore';
							this.isEmpty = true;
						} else {
							if (this.pageIndex < this.pageCount) {
								this.status = 'more';
							} else {
								this.status = 'nomore';
							}
							this.isEmpty = false;
							if (list.length > 0) {
								if (type === 'refresh') {
									this.listData = list;
								} else {
									this.listData = this.listData.concat(list);
								}
								this.pageIndex++;
							}
						}
					}

					if (type == 'refresh') {
						uni.stopPullDownRefresh();
					}
				}
			});
		},
		goDetail: function(e) {
			this.$util.redirectTo('/promotionpages/notice/detail/detail', { notice_id: e.id });
		}
	}
};
</script>

<style lang="scss">
.uni-media-list-body {
	height: auto;
	justify-content: space-around;
	padding: $ns-padding;
}

.uni-media-list-text-top {
	height: 74rpx;
	font-size: $ns-font-size-base;
	overflow: hidden;
}

.uni-media-list-text-bottom {
	display: flex;
	flex-direction: row;
	justify-content: space-between;
	color: $ns-text-color-gray;
	font-size: $ns-font-size-base;
}
</style>
