<template>
	<scroll-view scroll-y="true" class="page-wrap" :class="isIphoneX ? 'padding-bottom' : ''" @scrolltolower="scrolltolower">
		<!-- 头部轮播 -->
		<view v-if="advs.length > 0" class="carousel-section">
			<swiper class="carousel" circular autoplay="true">
				<swiper-item v-for="(item, index) in advs" :key="index" class="carousel-item">
					<image :src="$util.img(item.adv_image)" @click="redirectTo(item.adv_url)"></image>
				</swiper-item>
			</swiper>
		</view>
		<!-- 商品列表 -->
		<view class="index-content" v-if="goodsList.length > 0">
			<view class="goods" v-for="(item, index) in goodsList" :key="index">
				<navigator :url="'/promotionpages/groupbuy/detail/detail?goods_id=' + item.goods_id">
					<image :src="$util.img(item.picture.pic_cover_small)" mode="widthFix"></image>
				</navigator>
				<view class="price-wrap">
					<navigator :url="'/promotionpages/groupbuy/detail/detail?goods_id=' + item.goods_id">
						<view class="title">{{ item.goods_name }}</view>
					</navigator>
					<view class="price ns-margin-top">
						<view>
							<text class="price-icon ns-text-color uni-bold">¥</text>
							<text class="price-num ns-text-color uni-bold">{{ item.group_price }}</text>
						</view>
						<view class="group">团购价</view>
					</view>
				</view>
			</view>
		</view>
		<!-- 上滑组件 -->
		<uni-load-more :status="status" v-if="goodsList.length > 0 && pageCount > 1" :content-text="contentText" />
		<!-- 数据为空 -->
		<view v-if="isEmpty && goodsList.length == 0" class="empty">
			<view class="iconfont iconwenzhangchaxun"></view>
			<view class="ns-text-color-gray">没有找到您想要的商品...</view>
			<button type="primary" @click="goIndex()">去首页逛逛吧</button>
		</view>
		<loading-cover ref="loadingCover"></loading-cover>
	</scroll-view>
</template>

<script>
import http from 'common/js/http.js';
import uniLoadMore from '@/components/uni-load-more/uni-load-more.vue';
import loadingCover from '@/components/loading/loading.vue';
export default {
	components: {
		loadingCover,
		uniLoadMore
	},
	data() {
		return {
			advs: [],
			goodsList: [],
			pageIndex: 1,
			pageCount: 0,
			pageSize: 5,
			status: 'loading',
			contentText: {
				contentrefresh: '加载中',
				contentdown: '上拉加载更多',
				contentnomore: '没有更多了'
			},
			isEmpty: false,
			ident: false, //防止初始化时，触发上拉加载
			isIphoneX: false //判断手机是否是iphoneX以上
		};
	},
	onLoad() {
		uni.getSystemInfo({
			success: res => {
				if (res.model.search('iPhone X') != -1) {
					this.isIphoneX = true;
				}
			}
		});
		this.getGoodsList();
		this.getAdvDetail();
	},
	mixins: [http],
	methods: { 
		getGoodsList() {
			if (this.status == 'nomore') return;
			this.sendRequest({
				url: 'NsGroupBuy.GroupBuy.goodsList',
				data: {
					page_index: this.pageIndex,
					page_size: this.pageSize
				},
				success: res => {
					this.ident = true;
					if (res.code == 0) {
						let list = res.data.data;
						this.pageCount = res.data.page_count;

						if (this.pageCount == 0) {
							this.status = 'nomore';
							this.isEmpty = true;
							this.contentText.contentnomore = '';
						} else {
							if (this.pageIndex < this.pageCount) {
								this.status = 'more';
							} else {
								this.status = 'nomore';
								this.contentText.contentnomore = '没有更多了';
							}
							this.isEmpty = false;

							if (list.length > 0) {
								this.goodsList = this.goodsList.concat(list);
								this.pageIndex++;
							}
						}
						if (this.$refs.loadingCover == undefined) return;
						this.$refs.loadingCover.hide();
					}
				}
			});
		},
		//获取广告位详情
		getAdvDetail() {
			this.sendRequest({
				url: 'System.Shop.advDetail',
				data: {
					ap_keyword: 'APPLET_GROUP_BAY_SWIPER',
					export_type: 'data'
				},
				success: res => {
					if (res.data != null) {
						this.advs = res.data.advs;
					}
				}
			});
		},
		//去首页
		goIndex() {
			this.$util.redirectTo('/pages/index/index/index', {}, 'tabbar');
		},
		redirectTo(link) {
			if (link == null || link == '') return;
			if (link.is_tabbar == 1) {
				this.$util.redirectTo(link.url, {}, 'tabbar');
			} else {
				this.$util.redirectTo(link.url);
			}
		},
		scrolltolower(){
			if (!this.ident) return;
			this.getGoodsList();
		}
	}
};
</script>

<style lang="scss">
page{
	overflow: hidden;
}
.page-wrap {
	height: 100vh;
	background: $page-color-base;
	padding: 0 20rpx;
	box-sizing: border-box;
}
.padding-bottom {
	padding-bottom: 68rpx !important;
}
.uni-bold {
	font-weight: bold;
}
/* 头部 轮播图 */
.carousel-section {
	position: relative;
	padding-top: 20rpx;

	.titleNview-placing {
		height: var(--status-bar-height);
		padding-top: 88rpx;
		box-sizing: content-box;
	}

	.titleNview-background {
		position: absolute;
		top: 0;
		left: 0;
		width: 100%;
		height: 426rpx;
		transition: 0.4s;
	}
}

.carousel {
	width: 100%;
	height: 350rpx;

	.carousel-item {
		width: 100%;
		height: 100%;
		overflow: hidden;
	}

	image {
		width: 100%;
		height: 100%;
		border-radius: 10rpx;
	}
}

.index-content {
	margin-top: 20rpx;
	.goods {
		width: 100%;
		display: flex;
		margin-bottom: 20rpx;
		background: #ffffff;
		border-radius: $ns-border-radius;
		overflow: hidden;
		padding: 20rpx;
		box-sizing: border-box;
		margin-bottom: 20rpx;
		image {
			width: 200rpx;
		}
		.price-wrap {
			display: flex;
			flex-flow: column;
			justify-content: space-between;
			.title {
				overflow: hidden;
				text-overflow: ellipsis;
				display: -webkit-box;
				-webkit-line-clamp: 2;
				-webkit-box-orient: vertical;
				line-height: 1.5;
				padding: 0 $ns-padding;
			}
			.price {
				display: flex;
				justify-content: space-between;
				align-items: center;
				padding: 0 $ns-padding;
				.group {
					height: 36rpx;
					border: 2rpx solid $base-color;
					border-radius: 100rpx;
					color: $base-color;
					padding: 0 16rpx;
					line-height: 36rpx;
				}
				.price-icon {
					font-size: $ns-font-size-sm;
				}
				.price-num {
					font-size: 36rpx;
				}
			}
		}
	}
}
</style>
