<template>
	<view>
		<view class="coupon-sec-body" :class="isIphoneX ? 'padding-bottom' : ''">
			<view class="coupon-list">
				<view class="coupon-item" v-for="(item, index) in couponList" :key="index" @click="jumpGetCoupon(item.coupon_type_id)">
					<view class="coupon-item-box" :class="{ 'completion-collection': item.surplus_percentage <= 0 }">
						<view class="coupon-pic">
							<image v-if="item.surplus_percentage > 0" :src="$util.img('upload/uniapp/goods/coupon.png')" mode="aspectFit"></image>
							<image v-else :src="$util.img('upload/uniapp/goods/no-coupon.png')" mode="aspectFit"></image>
						</view>
						<view class="coupon-item-con">
							<view class="coupon-item-name">
								¥
								<text class="num">{{ item.money }}</text>
								满{{ item.at_least }}可用
							</view>
							<text class="coupon-item-desc">{{ item.coupon_name }}(&nbsp;全场商品可使用&nbsp;)</text>
						</view>
						<view v-if="item.surplus_percentage > 0" class="coupon-item-operation">
							<text>立即领取</text>
						</view>
						<view v-else class="coupon-item-operation">
							<text>领取完成</text>
						</view>
					</view>
				</view>
				<uni-load-more :status="status" v-if="couponList.length > 0 && pageCount > 1" />
			</view>
			<loading-cover ref="loadingCover"></loading-cover>
			<view v-if="isEmpty && couponList.length == 0" class="empty">
				<view class="iconfont iconwenzhangchaxun"></view>
				<text class="ns-text-color-gray">暂无优惠券</text>
				<button type="primary" @click="goIndex()">去首页逛逛吧</button>
			</view>
		</view>
	</view>
</template>

<script>
import http from 'common/js/http.js';
import uniLoadMore from '@/components/uni-load-more/uni-load-more.vue';
import loadingCover from '@/components/loading/loading.vue';
export default {
	components: {
		uniLoadMore,
		loadingCover
	},
	data() {
		return {
			isEmpty: false,
			couponList: [],
			pageIndex: 1,
			status: 'loading',
			pageCount: 0,
			indent: false, //防止初始化数据时，触发上拉加载
			isIphoneX: false //判断手机是否是iphoneX以上
		};
	},
	onReachBottom() {
		if (!this.indent) return;
		this.getCouponList();
	},
	onLoad() {
		uni.getSystemInfo({
			success: res => {
				if (res.model.search('iPhone X') != -1) {
					this.isIphoneX = true;
				}
			}
		});
	},
	onShow() {
		this.getCouponList('refresh');
	},
	mixins: [http],
	methods: {
		/**
		 * 初始化数据
		 */
		getCouponList(type = '') {
			if (type == 'refresh') {
				this.status = 'loading';
				this.couponList = [];
				this.pageIndex = 1;
			}
			if (this.status == 'nomore') return;
			this.sendRequest({
				url: 'System.Goods.couponList',
				data: {
					page_index: this.pageIndex
				},
				success: res => {
					this.indent = true;
					if (res.code == 0) {
						let list = res.data.data;
						this.pageCount = res.data.page_count;

						if (this.pageCount == 0) {
							this.status = 'nomore';
							this.isEmpty = true;
						} else {
							if (this.pageIndex < this.pageCount) {
								this.status = 'more';
							} else {
								this.status = 'nomore';
							}
							this.isEmpty = false;

							if (list.length > 0) {
								if (type === 'refresh') {
									this.couponList = list;
								} else {
									this.couponList = this.couponList.concat(list);
								}
								this.pageIndex++;
							}
						}
					}
					if (this.$refs.loadingCover == undefined) return;
					this.$refs.loadingCover.hide();
				}
			});
		},
		//去首页
		goIndex() {
			this.$util.redirectTo('/pages/index/index/index', {}, 'tabbar');
		},
		jumpGetCoupon(id) {
			this.$util.redirectTo('/pages/goods/coupon_receive/coupon_receive', { coupon_type_id: id });
		}
	}
};
</script>

<style lang="scss">
.coupon-item {
	margin-top: 30rpx;
	padding: 30rpx;
	background-color: #fff;
	.coupon-item-box {
		&.completion-collection {
			background-color: $ns-bg-color-gray;
			view {
				color: #999 !important;
			}
		}
		&:after {
			content: '';
			position: absolute;
			top: -14rpx;
			left: 514rpx;
			z-index: 3;
			width: 30rpx;
			height: 30rpx;
			background-color: #fff;
			border-radius: 50%;
		}
		&:before {
			content: '';
			position: absolute;
			bottom: -14rpx;
			left: 514rpx;
			z-index: 3;
			width: 30rpx;
			height: 30rpx;
			background-color: #fff;
			border-radius: 50%;
		}
		position: relative;
		display: flex;
		align-items: center;
		justify-content: space-between;
		padding: 16rpx;
		border-radius: 12rpx;
		background-color: lighten($base-color, 45%);
		.coupon-item-con {
			width: 316rpx;
			margin-right: auto;
			padding-right: 20rpx;
			height: 156rpx;
			border-right: 1px dashed #fff;
			line-height: 1;
			font-size: $ns-font-size-base;
			text {
				overflow: hidden;
				white-space: nowrap;
				text-overflow: ellipsis;
				display: inherit;
			}
		}
		.coupon-item-operation {
			margin-right: 10rpx;
			color: $base-color;
			font-size: $ns-font-size-base;
		}
		.coupon-item-name {
			margin-top: 14rpx;
			white-space: nowrap;
			overflow: hidden;
			text-overflow: ellipsis;
		}
		.num {
			margin-left: 4rpx;
			margin-right: 10rpx;
			font-size: $ns-font-size-lg + 12rpx;
			font-weight: 600;
			display: inline-block !important;
			overflow: initial !important;
		}
	}
}
.padding-bottom {
	padding-bottom: 68rpx !important;
}
.coupon-pic {
	width: 144rpx;
	height: 144rpx;
	margin-right: 30rpx;
	image {
		width: 144rpx;
		height: 144rpx;
	}
}
</style>
