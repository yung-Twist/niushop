<template>
	<view class="mine">
		<view class="mine-header">
			<!-- 个人信息 -->
			<view class="mine-userInfo" v-if="token">
				<view class="mine-userInfo-left" >
					<!-- <open-data type="userNickName"></open-data> -->
					<view>{{memberInfo.user_name}}</view>
					<navigator v-if="memberLevelInfo.level_info.level_name" url="/pages/member/level/level"  class="mine-userInfo-menberType">{{memberLevelInfo.level_info.level_name}}</navigator>
				</view>
				
				<navigator url="/pages/member/info/info" v-if="token" class="mine-userInfo-setting">
					<image src="http://daiwu668.dianaikeji.com/bgimg/setting.png" mode=""></image>
				</navigator>
			</view>
			<view class="mine-userInfo-nologin" v-if="!token" @click="clickLogin">
				<view class="nologin-text">立即登录</view>
				<view class="nologin-tip text-gray">登录体验更多功能</view>
			</view>
			<view class="userInfo-phone" v-if="token">{{memberInfo.user_tel}}</view>
			<view class="userInfo-avatar" >
				<open-data type="userAvatarUrl" v-if="token"></open-data>
				<image :src="$util.img('upload/uniapp/default_head.png')" v-else></image>
			</view>
			<view class="userInfo-assets">
				<view class="userInfo-assets-item" @click="redirectToLink('/pages/member/balance/balance')">
					<view class="assets-item-num">{{token ? memberAccountInfo.balance : 0}}</view>
					<view class="assets-item-text">余额</view>
				</view>
				<view class="userInfo-assets-item" @click="redirectToLink('/pages/member/point/point')">
					<view class="assets-item-num">{{token ? memberAccountInfo.point : 0}}</view>
					<view class="assets-item-text">积分</view>
				</view>
				<view class="userInfo-assets-item" @click="redirectToLink('/pages/member/coupon/coupon')">
					<view class="assets-item-num">{{token ? couponNum : 0}}</view>
					<view class="assets-item-text">优惠券</view>
				</view>
			</view>
		</view>
		<view class="mine-content">
			<!-- 我的订单 -->
			<view class="mine-order">
				<view class="mine-order-title" @click="redirectToLink('/pages/order/list/list')">
					<text>我的订单</text>
					<image src="http://daiwu668.dianaikeji.com/bgimg/right.png" mode="" @click="toOrderList"></image>
				</view>
				<view class="mine-order-type-wrap">
					<view class="mine-order-type-item">
						<view class="order-type-image">
							<image src="http://daiwu668.dianaikeji.com/bgimg/waitpay.png" mode=""></image>
							<view class="order-type-badge" v-if="orderNum.waitPay > 0">{{orderNum.waitPay}}</view>
						</view>
						<view class="order-type-text">待付款</view>
					</view>
					<view class="mine-order-type-item">
						<view class="order-type-image">
							<image src="http://daiwu668.dianaikeji.com/bgimg/waitsend.png" mode=""></image>
							<view class="order-type-badge" v-if="orderNum.readyDelivery > 0">{{orderNum.readyDelivery}}</view>
						</view>
						<view class="order-type-text">待发货</view>
					</view>
					<view class="mine-order-type-item">
						<view class="order-type-image">
							<image src="http://daiwu668.dianaikeji.com/bgimg/waitreceipt.png" mode=""></image>
							<view class="order-type-badge" v-if="orderNum.waitDelivery > 0">{{orderNum.waitDelivery}}</view>
						</view>
						<view class="order-type-text">待收货</view>
					</view>
					<view class="mine-order-type-item">
						<view class="order-type-image">
							<image src="http://daiwu668.dianaikeji.com/bgimg/waitevaluation.png" mode=""></image>
							<!-- <view class="order-type-badge" v-if="item.badge > 0">{{item.badge}}</view> -->
						</view>
						<view class="order-type-text">待评价</view>
					</view>
					<view class="mine-order-type-item">
						<view class="order-type-image">
							<image src="http://daiwu668.dianaikeji.com/bgimg/refund.png" mode=""></image>
							<view class="order-type-badge" v-if="orderNum.refunding > 0">{{orderNum.refunding}}</view>
						</view>
						<view class="order-type-text">退款/售后</view>
					</view>
				</view>
			</view>
			<!-- 常用工具 -->
			<view class="mine-commontools">
				<view class="commontools-title">
					<image class="commontools-title-bg" src="http://daiwu668.dianaikeji.com/bgimg/Common%20tools.png"></image>
					<view class="commontools-title-text">
						<view class="title-line"></view>
						<view class="title-point"></view>
						<view class="title-text">常用工具</view>
						<view class="title-point"></view>
						<view class="title-line"></view>
					</view>
				</view>
				<!-- 常用工具列表 -->
				<view class="tools-list">
					<view class="tools-item" v-for="(item, index) in toolList" :key="index" :style="{background:item.bgColor}" @click="toToolsPage(item)">
						<image :src="item.iconPath" mode=""></image>
						<text>{{item.name}}</text>
					</view>
				</view>
			</view>
			<view class="block" style="height: 10vh;"></view>
		</view>
		<Tarbar :route="route" />

		<ns-login ref="login" href="member_index"></ns-login>
	</view>
</template>
<script>
	import http from 'common/js/http.js';
	import uniGrid from '@/components/uni-grid/uni-grid.vue';
	import uniGridItem from '@/components/uni-grid-item/uni-grid-item.vue';
	import uniPopup from 'components/uni-popup/uni-popup.vue';
	import nsLogin from 'components/ns-login/ns-login.vue';
	import Tarbar from '@/components/Tarbar'
	let than;
	export default {
		components: {
			uniGrid,
			uniGridItem,
			uniPopup,
			nsLogin,
			Tarbar
		},
		data() {
			return {
				bottom_info: {},
				copyrightLoad: '',
				token: '',
				memberInfo: {},
				memberLevelInfo: {
					level_info: {
						level_name: ''
					}
				},
				couponNum: 0,
				memberAccountInfo: {
					balance: '0.00',
					point: 0
				},
				addonIsExit: {},
				isVerification: false,
				code: '',
				orderNum: {
					waitPay: 0, //待付款
					readyDelivery: 0, //待发货
					waitDelivery: 0, //待收货
					refunding: 0 // 退款中
				},
				//推广商信息
				promoterInfo: null,
				shopConfig: null,
				entranceManage: [],
				route: null,
				toolList: [{
						id: 1,
						name: '签到',
						iconPath: 'http://daiwu668.dianaikeji.com/bgimg/sign.png',
						bgColor: '#94B5ED',
						route: '/pages/member/signin/signin'
					},
					{
						id: 2,
						name: '收藏',
						iconPath: 'http://daiwu668.dianaikeji.com/bgimg/star.png',
						bgColor: '#D4E2F8',
						route: '/pages/member/collection/collection'
						// route: '/pages/mine/favorites/favorites'
					},
					{
						id: 3,
						name: '个人资料',
						iconPath: 'http://daiwu668.dianaikeji.com/bgimg/userInfo.png',
						bgColor: '#D5D6F0',
						route: '/pages/member/info/info'
					},
					{
						id: 4,
						name: '收货地址',
						iconPath: 'http://daiwu668.dianaikeji.com/bgimg/address.png',
						bgColor: '#D4E2F8',
						route: '/pages/member/address/address'
						// route: '/pages/mine/addressList/addressList'
					},
					{
						id: 5,
						name: '积分商城',
						iconPath: 'http://daiwu668.dianaikeji.com/bgimg/integralstore.png',
						bgColor: '#94B5ED',
						route: '/pages/mine/addressList/addressList'
					},
					{
						id: 6,
						name: '我的拼团',
						iconPath: 'http://daiwu668.dianaikeji.com/bgimg/mygroup.png',
						bgColor: '#F5E6E3',
						route: '/promotionpages/pintuan/spelllist/spelllist'
					},
					{
						id: 7,
						name: '我的秒杀',
						iconPath: 'http://daiwu668.dianaikeji.com/bgimg/mysecond.png',
						bgColor: '#D5D6F0',
						route: '#'
					},
					{
						id: 8,
						name: '我的砍价',
						iconPath: 'http://daiwu668.dianaikeji.com/bgimg/mybargain.png',
						bgColor: '#D4E2F8',
						route: '/promotionpages/bargain/bargain/bargain'
					},
					{
						id: 9,
						name: '客服中心',
						iconPath: 'http://daiwu668.dianaikeji.com/bgimg/service.png',
						bgColor: '#D5D6F0',
						route: '/pages/mine/addressList/addressList'
					},
					{
						id: 10,
						name: '百科',
						iconPath: 'http://daiwu668.dianaikeji.com/bgimg/baike.png',
						bgColor: '#D4E2F8',
						route: '/pages/mine/encyclopedia/encyclopedia'
					},
					{
						bgColor: '#94B5ED'
					},
					{
						bgColor: '#D4E2F8'
					}

				]
			};
		},
		mixins: [http],
		onLoad(option) {
			this.getCopyright();
			this.checkVerification();
			this.getWapEntranceManage();

			if (option.code) this.code = option.code;
			than = this;
			let routes = getCurrentPages();
			this.route = routes[routes.length - 1].route
		},
		//下拉刷新
		onPullDownRefresh() {
			this.refresh();
		},
		onShow() {
			this.refresh();
		},
		methods: {
			// 请求数据
			async refresh() {
				this.token = uni.getStorageSync('token');
				if (this.token) this.getMemberInfo();
				else this.initInfo();

				let res = await this.sendRequest({
					url: 'System.Config.addonIsExit',
					async: false
				});

				if (res.code == 0) {
					this.addonIsExit = res.data;
					if (this.token && this.addonIsExit.is_exit_fx) {
						this.getPromoterDetail();
						this.getShopConfig();
					}
				}
			},

			/**
			 * 个人中心入口栏目
			 */
			getWapEntranceManage() {
				this.sendRequest({
					url: 'System.Config.wapEntrance',
					data: {
						port: 2
					},
					success: res => {
						if (res.code == 0) {
							this.entranceManage = res.data;
							// console.log(this.entranceManage)
						}
					}
				});
			},

			/**
			 * 初始化数据
			 */
			initInfo() {
				this.couponNum = 0;
				this.memberAccountInfo = {
					balance: '0.00',
					point: 0
				};
				this.orderNum = {
					waitPay: 0, //待付款
					readyDelivery: 0, //待发货
					waitDelivery: 0, //待收货
					refunding: 0 // 退款中
				};
				this.promoterInfo = null;
				this.shopConfig = null;
				this.isVerification = false;
				this.addonIsExit = {};
				this.memberInfo = {};
				this.memberLevelInfo = {
					level_info: {
						level_name: ''
					}
				};
				uni.stopPullDownRefresh();
			},
			/**
			 * 订单数量
			 */
			getOrderNum() {
				this.sendRequest({
					url: 'System.Order.orderCount',
					data: {
						order_status: 0
					},
					success: res => {
						if (res.code == 0) {
							this.orderNum.waitPay = res.data;
						}
					}
				});
				this.sendRequest({
					url: 'System.Order.orderCount',
					data: {
						order_status: 1
					},
					success: res => {
						if (res.code == 0) {
							this.orderNum.readyDelivery = res.data;
						}
					}
				});
				this.sendRequest({
					url: 'System.Order.orderCount',
					data: {
						order_status: 2
					},
					success: res => {
						if (res.code == 0) {
							this.orderNum.waitDelivery = res.data;
						}
					}
				});
				this.sendRequest({
					url: 'System.Order.orderCount',
					data: {
						order_status: -1
					},
					success: res => {
						if (res.code == 0) {
							this.orderNum.refunding = res.data;
						}
					}
				});
			},
			/**
			 * 检测是否登录
			 */
			redirectToLink(url) {
				var isLogin = true;
				// #ifdef MP
				getApp().$vm.checkLogin(() => {
					isLogin = false;
					this.clickLogin();
				});
				// #endif
				// #ifdef H5
				getApp().checkLogin(() => {
					isLogin = false;
					this.clickLogin();
				});
				// #endif
				if (isLogin) this.$util.redirectTo(url);
			},
			/**
			 * 版权信息
			 */
			getCopyright() {
				this.sendRequest({
					url: 'System.Config.copyRight',
					success: res => {
						this.copyrightLoad = res.data.is_load;
						this.bottom_info = res.data.bottom_info;
					}
				});
			},
			/**
			 * 获取用户核销身份
			 */
			checkVerification() {
				this.sendRequest({
					url: 'System.Order.checkVerification',
					success: res => {
						if (res.data != null) {
							this.isVerification = true;
						}
					}
				});
			},
			/**
			 * 获取用户信息
			 */
			getMemberInfo() {
				this.sendRequest({
					url: 'System.Member.memberInfo',
					success: res => {
						if (res.code == 0 && res.data) {
							this.memberInfo = res.data.user_info;
							this.memberLevelInfo.level_id = res.data.member_level;
							this.getMemberLevelInfo();
							this.getMemberCoupon();
							this.getMemberAccountInfo();
							this.getOrderNum();
						}
					}
				});
			},
			/**
			 * 获取会员等级信息
			 */
			getMemberLevelInfo() {
				this.sendRequest({
					url: 'System.Member.memberLevel',
					data: {
						level_id: this.memberLevelInfo.level_id
					},
					success: res => {
						if (res.code == 0) {
							this.memberLevelInfo.level_info = res.data;
						}
					}
				});
			},
			/**
			 * 获取会员优惠券数量
			 */
			getMemberCoupon() {
				this.sendRequest({
					url: 'System.Member.couponNum',
					data: {
						level_id: this.memberLevelInfo.level_id
					},
					success: res => {
						if (res.code == 0) {
							this.couponNum = res.data;
						}
					}
				});
			},
			/**
			 * 获取会员账户信息
			 */
			getMemberAccountInfo() {
				this.sendRequest({
					url: 'System.Member.memberAccount',
					success: res => {
						if (res.code == 0) {
							this.memberAccountInfo = res.data;
							uni.stopPullDownRefresh();
						}
					}
				});
			},
			clickLogin() {
				this.$refs.login.clickLogin();
			},
			/**
			 * 获取推广商信息
			 */
			getPromoterDetail() {
				this.sendRequest({
					url: 'Nsfx.Distribution.promoterDetail',
					success: res => {
						if (res.code == 0) {
							this.promoterInfo = res.data;
						} else {
							this.promoterInfo = null;
						}
					}
				});
			},
			/**
			 * 店铺推广设置
			 */
			getShopConfig() {
				this.sendRequest({
					url: 'System.Distribution.shopConfig',
					success: res => {
						if (res.code == 0) {
							this.shopConfig = res.data;
						}
					}
				});
			},
			toast(msg) {
				this.$util.showToast({
					title: msg
				});
			},
			toToolsPage(item) {
				uni.navigateTo({
					url: item.route
				})
			},
			toOrderList() {
				uni.navigateTo({
					url: '/pages/mine/order/order'
				})
			}
		}
	};
</script>
<style lang="scss">
	.mine {
		position: relative;

		.mine-header {
			width: 750upx;
			height: 720upx;
			background: url('http://daiwu668.dianaikeji.com/bgimg/minebg.png') no-repeat;
			background-size: 100% 100%;
			.mine-userInfo {
				padding: 30upx 28upx 0 62upx;
				display: flex;
				flex-direction: row;
				align-items: center;
				justify-content: space-between;

				.mine-userInfo-left {
					display: flex;
					flex-direction: row;
					align-items: center;
					font-size: 40upx;
					font-weight: bold;
					color: #333333;
					line-height: 40upx;

					.mine-userInfo-menberType {
						background: #2A6CDC;
						border-radius: 20upx;
						font-size: 22upx;
						color: #FFFFFF;
						font-weight: 400;
						line-height: 44upx;
						padding: 0 20upx;
						margin-left: 24upx;
					}
				}

				.mine-userInfo-setting {
					image {
						width: 40upx;
						height: 40upx;
					}
				}
			}
			.mine-userInfo-nologin{
				padding: 30upx;
				.nologin-text{
					font-size: 50upx;
				}
				.mologin-tip{
					font-size: 24upx;
				}
			}
			.userInfo-phone {
				padding-left: 62upx;
				font-size: 28upx;
				font-weight: 400;
				color: #666666;
				margin-top: 20upx;
			}

			.userInfo-avatar {
				margin-left: 50upx;
				margin-top: 38upx;
				width: 180upx;
				height: 180upx;
				border-radius: 50%;
				border: 4upx solid #2A6CDC;
				overflow: hidden;

				image {
					width: 100%;
					height: 100%;
				}
			}

			.userInfo-assets {
				padding: 0 80upx;
				display: flex;
				flex-direction: row;
				justify-content: space-between;
				align-items: center;
				margin-top: 30upx;

				.userInfo-assets-item {
					display: flex;
					flex-direction: column;
					align-items: center;

					.assets-item-num {
						font-size: 48upx;
						color: #2A6CDC;
					}

					.assets-item-text {
						font-size: 24upx;
						color: #333333;
						margin-top: 10upx;
					}
				}
			}
		}

		.mine-content {
			position: absolute;
			top: 520upx;
			width: 100vw;
			padding: 30upx;

			.mine-order {
				width: 100%;
				height: 262upx;
				background: #2A6CDC;
				box-shadow: 0 10upx 20upx 0upx rgba(42, 108, 220, 0.3);
				border-radius: 10upx;

				.mine-order-title {
					display: flex;
					flex-direction: row;
					align-items: center;
					justify-content: space-between;

					text {
						font-size: 28upx;
						color: #FFFFFF;
						margin-left: 56upx;
					}

					image {
						width: 40upx;
						height: 40upx;
						margin: 18upx;
					}
				}

				.mine-order-type-wrap {
					display: flex;
					flex-direction: row;
					justify-content: space-around;
					align-items: center;
					padding: 30upx 0;
					margin-top: 30upx;

					.mine-order-type-item {
						display: flex;
						flex-direction: column;
						justify-content: center;
						align-items: center;

						.order-type-image {
							width: 56upx;
							height: 56upx;
							position: relative;

							image {
								width: 100%;
								height: 100%;
							}

							.order-type-badge {
								width: 30upx;
								height: 30upx;
								position: absolute;
								right: -10upx;
								top: -10upx;
								background: #FFFFFF;
								border-radius: 50%;
								font-size: 20upx;
								color: #2A6CDC;
								line-height: 30upx;
								text-align: center;
							}
						}

						.order-type-text {
							font-size: 24upx;
							color: #FFFFFF;
							margin-top: 14upx;
						}
					}
				}
			}

			.mine-commontools {
				width: 100%;

				.commontools-title {
					width: 690upx;
					height: 220upx;
					background: rgba(148, 181, 237, 1);
					box-shadow: 0upx 10upx 20upx 0upx rgba(42, 108, 220, 0.3);
					border-radius: 30upx;
					margin: 40upx 0;
					position: relative;

					.commontools-title-bg {
						position: absolute;
						width: 659upx;
						height: 74upx;
						left: 15upx;
						top: 73upx;
					}

					.commontools-title-text {
						position: absolute;
						width: 659upx;
						height: 74upx;
						left: 15upx;
						top: 73upx;
						display: flex;
						flex-direction: row;
						align-items: center;
						justify-content: center;

						.title-line {
							width: 45upx;
							height: 6upx;
							background: $main-color;
							margin: 0 25upx;
						}

						.title-point {
							width: 14upx;
							height: 14upx;
							background: $main-color;
							border-radius: 50%;
						}

						.title-text {
							font-size: 51upx;
							font-weight: bold;
							font-style: italic;
							color: $main-color;
							margin: 0 50upx;
						}
					}
				}

				.tools-list {
					width: 690upx;
					display: grid;
					grid-template-columns: repeat(3, 230upx);
					grid-template-rows: repeat(4, 230upx);
					background: rgba(212, 226, 248, 1);
					box-shadow: 1upx 10upx 20upx 0upx rgba(42, 108, 220, 0.3);
					border-radius: 30upx;
					overflow: hidden;

					.tools-item {
						display: flex;
						flex-direction: column;
						justify-content: center;
						align-items: center;

						image {
							width: 70upx;
							height: 70upx;
						}

						text {
							font-size: 24upx;
							color: rgba(52, 52, 52, 1);
						}
					}
				}
			}
		}
	}
</style>
