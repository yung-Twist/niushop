<template>
	<view>
		<view class="brand-body" :class="isIphoneX ? 'padding-bottom' : ''">
			<!-- 头部轮播 -->
			<view class="carousel-section" v-if="swiperList.length > 0 && goodsBrandList.length > 0">
				<!-- 背景色区域 -->
				<view class="titleNview-background"></view>
				<swiper class="carousel" circular autoplay="true">
					<swiper-item v-for="(item, index) in swiperList" :key="index" class="carousel-item">
						<image :src="$util.img(item.adv_image)" @click="redirectTo(item.adv_url)" />
					</swiper-item>
				</swiper>
			</view>
			<view class="brand-container" v-if="goodsBrandList.length > 0">
				<navigator :url="'/pages/goods/list/list?brand_id=' + item.brand_id" v-for="(item, index) in goodsBrandList" :key="index" class="brand-item">
					<view class="brand-ad">
						<image :src="item.brand_ads != '' ? $util.img(item.brand_ads) : $util.img('upload/uniapp/brand_default.png')" class="pic" mode="aspectFit"></image>
					</view>
					<view class="brand-info">
						<view class="brand-pic"><image :src="item.brand_pic != '' ? $util.img(item.brand_pic) : $util.img('upload/uniapp/default_goods.png')"></image></view>
						<view class="brand-name ns-font-size-base">{{ item.brand_name }}</view>
						<view class="brand-desc ns-text-color-gray ns-font-size-sm">{{ item.describe }}</view>
					</view>
				</navigator>
			</view>
			<uni-load-more :status="status" :content-text="contentText" v-if="goodsBrandList.length > 0 && pageCount > 1" />
			<!-- 数据为空 -->
			<view v-if="isEmpty && goodsBrandList.length == 0" class="empty">
				<view class="iconfont iconwenzhangchaxun"></view>
				<view class="ns-text-color-gray">Sorry！没有找到您想要的商品…</view>
				<button type="primary" @click="goIndex()">去首页逛逛吧</button>
			</view>
		</view>
	</view>
</template>

<script>
import http from 'common/js/http.js';
import uniLoadMore from '@/components/uni-load-more/uni-load-more.vue';

export default {
	components: {
		uniLoadMore
	},
	data() {
		return {
			swiperList: [],
			goodsBrandList: [],
			pageIndex: 1,
			pageCount: 0,
			isEmpty: false,
			status: 'loading',
			contentText: {
				contentdown: '上拉加载更多',
				contentrefresh: '加载中',
				contentnomore: '没有更多了'
			},
			ident: false, //防止初始化时，触发上拉加载
			isIphoneX: false //判断手机是否是iphoneX以上
		};
	},
	onLoad() {
		uni.getSystemInfo({
			success: res => {
				if (res.model.search('iPhone X') != -1) {
					this.isIphoneX = true;
				}
			}
		});
		this.getSwiperList();
		this.getGoodsBrandList();
	},
	onReachBottom() {
		if (!this.ident) return;
		this.getGoodsBrandList();
	},
	mixins: [http],
	methods: {
		getSwiperList() {
			this.sendRequest({
				url: 'System.Shop.advDetail',
				data: {
					ap_keyword: 'APPLET_BRAND_SWIPER',
					export_type: 'data'
				},
				success: res => {
					if (res.code == 0) {
						let list = res.data.advs;
						this.swiperList = list;
					}
				}
			});
		},
		redirectTo(link) {
			if (link == null || link == '') return;
			if (link.is_tabbar == 1) {
				this.$util.redirectTo(link.url, {}, 'tabbar');
			} else {
				this.$util.redirectTo(link.url);
			}
		},
		goIndex() {
			this.$util.redirectTo('/pages/index/index/index', {}, 'tabbar');
		},
		getGoodsBrandList() {
			if (this.status == 'nomore') return;
			this.sendRequest({
				url: 'System.Goods.goodsBrandList',
				data: {
					page_index: this.pageIndex,
					condition: JSON.stringify({
						brand_recommend: 1
					}),
					order: 'sort desc'
				},
				success: res => {
					this.ident = true;
					if (res.code == 0) {
						let list = res.data.data;
						this.pageCount = res.data.page_count;

						if (this.pageCount == 0) {
							this.status = 'nomore';
							this.isEmpty = true;
							this.contentText.contentnomore = '';
						} else {
							if (this.pageIndex < this.pageCount) {
								this.status = 'more';
							} else {
								this.status = 'nomore';
								this.contentText.contentnomore = '没有更多了';
							}
							this.isEmpty = false;

							if (list.length > 0) {
								this.goodsBrandList = this.goodsBrandList.concat(list);
								this.pageIndex++;
							}
						}
					}
				}
			});
		}
	}
};
</script>

<style lang="scss">
page {
	background: $page-color-base;
}
.padding-bottom {
	padding-bottom: 68rpx !important;
}
/* 头部 轮播图 */
.carousel-section {
	position: relative;
	padding-top: 20rpx;
	margin-bottom: 20rpx;
	.titleNview-placing {
		height: var(--status-bar-height);
		padding-top: 88rpx;
		box-sizing: content-box;
	}

	.titleNview-background {
		position: absolute;
		top: 0;
		left: 0;
		width: 100%;
		height: 426rpx;
		transition: 0.4s;
	}
}

.carousel {
	width: 100%;
	height: 350rpx;
	.carousel-item {
		width: 100%;
		height: 100%;
		overflow: hidden;
	}
	image {
		width: 100%;
		height: 100%;
		border-radius: 10rpx;
	}
}
.brand-container .brand-item {
	background: #fff;
	border-radius: $ns-border-radius;
	overflow: hidden;
	margin-bottom: 20rpx;
}

.brand-container .brand-ad {
	width: 750rpx;
	height: 230rpx;
	margin-bottom: 20rpx;
	overflow: hidden;
	image {
		width: 750rpx;
		height: 230rpx;
	}
}
.brand-container .brand-ad .recommend-icon {
	background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyZpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMDY3IDc5LjE1Nzc0NywgMjAxNS8wMy8zMC0yMzo0MDo0MiAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTUgKFdpbmRvd3MpIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOkI5ODIzMjQ5ODFDNjExRTlCQTRBOUE4Rjg5QzdBOTY0IiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOkI5ODIzMjRBODFDNjExRTlCQTRBOUE4Rjg5QzdBOTY0Ij4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6Qjk4MjMyNDc4MUM2MTFFOUJBNEE5QThGODlDN0E5NjQiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6Qjk4MjMyNDg4MUM2MTFFOUJBNEE5QThGODlDN0E5NjQiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz5i9QneAAAEwElEQVR42uSZS2xMYRTHjzH6mE7VozpKkJQNwUY1WJB2S8qCRIKlR22IZwihG1JF2GjCRrEQjwTxiA1WSFkWaSqNdIVpqbYzrTHK9z+d77rGmOl93zv3JDeddjrS3/+c8z/n+4zrrl76i/wbjQE/w4vneMDP8HgR8DO87QIEKipcBW+rAICf1nKBJu7d4xp4RNCujAP+R1cX9Z856xp4ywWY2NBAhYsX8WvAf9l/gF9PaT5Fic5OGrx4yVF4y1ugv6WFguXl/PQ1n1bgJ1RVUfzOXcfhLa0A2fNDbW38fUH1EgrV1jJ8tGEnBefNIxJP4vlzx+BNFwDQAEu+f6/0vLrs1fDTTp6g72/fUo81AowJ3nQB0PMldbWU7OnJCY9ICKHk+yODMeprbLQV3nQPQM9zuc+eTfGnT7kiMsEP3LtHI/E4Jd69U96Xn7UTHjHOrMOQ7HlkHtkMhEuocOFCBk2Hjz98RJVXWmno9WsaLz6H90c+f7Yd3rQWUMPLsi8X3yPS4bEH4PchTHF1NX3atdsxeNNaILRu7T89j8xi/MmQ8IhJ+/exTyS6u2my2AwNrsi64U0TINH+5h/D6z1ylLNcVFfHo07Cqz0BD2Lq6WZH4HULoM4YdnuUN34W2rhRgUsKg0OWSzesV35fDY+yxxN7/JiK5s/XUwWG4XV5QOT2LXb52LNnlPz4kUrr6yl66DDDxK9f50fGSCxGBXPmsD8AGusvNkLZ8wUrVlDZpk30TXxGow+YAq9pCqgzhLIOrVpJhQsWMLzc5sLbtvKKK2EmHTvG0wChzjz7hqiWyQ07/vIGu+E1tQCyGN6ymQGCM2ewg6PEk6llBq2AbPKKqwqAwx9gkvg3pJCoFIjnJLwmAYZElotFyQIUZd+b+sPlGV+2gqwGCfozlfFMImg8B5gOr6kF0K+R8+dGF5sUKEAirZd53EEQ2f8wu0A4TD0pl1eHzrXXEvisJgjgouXLlBIFMO/4Hz786XnREoFQiOc53H74yROe8bLfM4Ucl26AzyoA4MuEUSGGX7yksh3ble0NWVRPAHn6q7x5g0VSm53Bg46l8FkFkJmHCADFuf4HdnyR8eKaGv4aFS4vqwH9jfGYXu7ZqsFp+JwmiMwj64BFxhMdHdwCvU1N/HNccKhBsddLY0xfetwIn9MEKx89pO/t7QyPSsDCMnj1Gq+uA+L11IMHWQh54gMojDFTK7gRPucmGN2zl1daGRABoxAb3rA40kb7vo3e7AiRlOUnddDxArzm+wBsdqVrVtPA/QeKqWFaQAR59+eFstd9GJowt2p05AkR5H9wwAQxCWCMeLwEr0mAoDix4WDzVUwHeAHaIV0EuRt4Bd7QlRjv/iljlCMTIqk9w+3whi5E+lOVgB0B4Ait8LNetTkKb/hGKDh9uu6bHDfAGxIA8358JDK6Cnsw84Y9wKk7PFe1gNfh7RTAlfB2CeBaeDsEcDW81QK4Ht5KATwBb5UAnoG3QgBPwZstgOfgzRTAk/BmCeBZeDME8DS8UQE8D29EgLyA1ytA3sDrESCv4LUKkHfwWgTIS/ixCpC38GMRIK/hcwmQ9/DZBPAF/P8E8A18JgF8BZ8ugO/g1QL4El4K4Ft4xG8BBgDgn6LXgmy7bgAAAABJRU5ErkJggg==);
	background-size: contain;
	width: 80rpx;
	height: 80rpx;
	position: absolute;
	z-index: 5;
	top: 0;
	left: 0;
}

.brand-container .brand-info {
	height: 140rpx;
	padding-left: 160rpx;
	position: relative;
}

.brand-container .brand-info .brand-pic {
	width: 120rpx;
	height: 120rpx;
	position: absolute;
	left: 20rpx;
	top: 0rpx;
	line-height: 120rpx;
}

.brand-container .brand-info .brand-pic image {
	width: 100%;
	height: 100%;
	border-radius: 100%;
}

.brand-container .brand-info .brand-name {
	margin-bottom: 10rpx;
	line-height: 40rpx;
	white-space: nowrap;
	overflow: hidden;
}

.brand-container .brand-info .brand-desc {
	overflow: hidden;
	text-overflow: ellipsis;
	word-break: break-all;
	word-wrap: break-word;
	display: -webkit-box;
	-webkit-line-clamp: 2;
	-webkit-box-orient: vertical;
}
</style>
