import Vue from 'vue'
import App from './App'
import Util from './common/js/util.js'
import MescrollUni from "@/components/mescroll-uni/mescroll-uni.vue"


Vue.config.productionTip = false

Vue.component("mescroll-uni", MescrollUni);

Vue.prototype.$util = Util;

App.mpType = 'app'

const app = new Vue({
	...App
})
app.$mount()
