<template>
		<view v-if="live.length > 0" class="uni-padding-wrap uni-common-mt">
			<view>
				<view class="clearfix live-title">
					<text>{{value.title}}</text>
					<navigator url="/promotionpages/live/list/list">查看更多</navigator>
				</view>	
				<scroll-view class="scroll-view_H clearfix" scroll-x="true" @scroll="scroll" scroll-left="0">
					<view v-for="(item, index) in live" :key="index" class="scroll-view-item_H clearfix">
						<view  @click="entryRoom(item.room_id, item.live_status)" class="swiper-item">
							<image :src="$util.img(item['cover_img'])" class="live-cover-img"></image>
							<view class="clearfix live-type">
								<image :src="$util.img('upload/uniapp/have_in.gif')" mode="" v-if="item.live_status == 101"></image>
								<image :src="$util.img('upload/uniapp/no-start.png')" mode="" v-else></image>
								{{ item.status_zh }}
							</view>
							<view class="live-mask"></view>
						</view>
						<view class="live-right-box">
							<text class="live-right-name" @click="entryRoom(item.room_id, item.live_status)">{{ item.name }}</text>
							<view class="clearfix live-anchor_name" @click="entryRoom(item.room_id, item.live_status)">
								<view>
									<image :src="$util.img(item['anchor_img'])"></image>
								</view>								
								{{ item.anchor_name }}
							</view>
							<view class="live-goods-list">
								<block v-for="(items, indexs) in item.goods" :key="indexs">
									<navigator :url="items.url" v-if="indexs == 0" class="clearfix goods-box">
										<image :src="$util.img(items['cover_img'])"></image>
										<view></view>
										<text>¥{{ items.price }}</text>										
									</navigator>
									<navigator :url="items.url"  v-if="indexs == 1" class="clearfix goods-boy">
										<image :src="$util.img(items['cover_img'])"></image>
										<view></view>
										<text class="goods-num">{{ item.goods_total }}件</text>	
										<text class="goods-text">商品</text>
									</navigator>									
								</block>								
							</view>
						</view>						
					</view>
					
				</scroll-view>						
			</view>
		</view>
</template>

<script>
import http from 'common/js/http.js';
export default{
	name: 'diy-live-broadcast',
	mixins: [http],
	props: {
		value: {
		}
	},
	data(){
		return {
			scrollTop: 0,
			old: {
				scrollTop: 0
			},
			live : [],
		}
	},
	created() {
		this.getLiveList();
	},
	methods: {
		scroll: function(e) {
			this.old.scrollTop = e.detail.scrollTop
		},
		
		getLiveList (){
			this.sendRequest({
				url: 'NsWxappLive.Room.roomList',
				data: { is_recommend: 1},
				success: res => {
					//101
					let data = res.data;
					if (data != null) {
						this.live = data.data;
					} 
				}
			});
		},

		entryRoom(roomId, live_status){
			// #ifdef MP-WEIXIN

			if(live_status == 103){
				this.$util.redirectTo('/promotionpages/live/playback/playback', { id: roomId });
			}else{
				let customParams = { path: 'pages/index/index/index'};
				wx.navigateTo({
					url: `plugin-private://wx2b03c6e691cd7370/pages/live-player-plugin?room_id=${roomId}&custom_params=${encodeURIComponent(JSON.stringify(customParams))}`
				})
			}			
			// #endif
		},
	}
}
</script>

<style lang="scss">
.uni-padding-wrap{
	background:#fff;
	margin-top:0px;
}
.live-title{
	height:36px;
	line-height:49px;
	text{
		font-size:16px;
		border-left:3px solid #f46029;
		padding-left:5px;
		font-weight:bold
	};
	navigator{
		margin:0px;
		padding:0px;
		display:inline-block;
		float:right;
		background:#fff;
		color:#f46029;
		font-size:14px;
		font-weight:bold
	}
}
.swiper-item{
	width:120px;
	height:100%;
	line-height: 100px;
	position:relative;
	float: left;
	border-radius: 9px;
	overflow: hidden;
	.live-cover-img{
		width:100%;
		height:100%
	};
	.live-type{
		position: absolute;
		top:5px;
		left:6px;
		background:rgba(0,0,0,0.2);
		width: 60px;
		height: 18px;
		line-height: 18px;
		border-radius:22px;
		font-size: 11px;
		color:#fff;
		overflow: hidden;
		overflow: hidden;
		text-overflow:ellipsis;
		white-space: nowrap;
		z-index: 100;
		image{
			height:18px;
			width: 18px;
			float:left
		}
	};
	.live-mask{
		position: absolute;
		top:0px;
		width:100%;
		height: 100%;
		background: rgba(0, 0, 0, 0.1);
	}
}
.live-right-box{
	float:right;
	width:115px;
	text-align:center;
	height:100%
}
.live-right-name{
	margin-top:7px;
	display:inline-block;
	font-size:13px;
	font-weight:bold;
	width:100%;
	text-align:left;
	overflow: hidden;
	text-overflow:ellipsis;
	white-space: nowrap
}
.live-anchor_name{
	font-size:11px;
	color:#8d8d8d;
	font-weight:bold;
	line-height:20px;
	text-align:left;
	display:flex;
	align-items:flex-end;
	overflow: hidden;
	text-overflow:ellipsis;
	white-space: nowrap;
	view{
		height:20px;
		width: 20px;
		float:left;
		margin-right: 5px;
		border-radius: 30px;
		overflow: hidden;
		image{
			width: 100%;
			height: 100%
		}
	}
}
.live-goods-list{
	margin-top:4px
}
.goods-box{
	position: relative;
	width: 50px;
	height: 50px;
	float: left;
	padding: 0px;
	margin: 0px;
	image{
		height:100%;
		width: 100%;
		float:left;
	};
	view{
		position: absolute;
		width:100%;
		height:100%;
		background:rgba(0,0,0,0.3);
		width:100%
	};
	text{
		position: absolute;
		color:#fff;
		font-size: 10px;
		font-weight:bold;
		left:0px;
		bottom:0px;
		width:100%
	}
}
.goods-boy{
	position: relative;
	width: 50px;
	height: 50px;
	float: left;
	padding:0px;
	margin:0px;
	margin-left: 5px;
	image{
		height:100%;
		width: 100%;
		float:left
	};
	view{
		position: absolute;
		width:100%;
		height:100%;
		background:rgba(0,0,0,0.3);
		width:100%
	};
	.goods-num{
		position: absolute;
		color:#fff;
		font-size: 10px;
		font-weight:bold;
		left:0px;
		bottom:22px;
		width:100%
	};
	.goods-text{
		position: absolute;
		color:#fff;
		font-size: 10px;
		font-weight:bold;
		left:15px;
		bottom:6px
	}
}
.scroll-view_H{
	height: 135px;
	margin-top: 15px;
}


.scroll-Y {
	height: 300upx;
}

.scroll-view_H {
	white-space: nowrap;
	width: 100%;
}

.scroll-view-item {
	height: 300upx;
	line-height: 300upx;
	text-align: center;
	font-size: 36upx;
}

.scroll-view-item_H {
	display: inline-block;
	line-height: 300upx;
	text-align: center;
	font-size: 36upx;	
	width: 245px;
	height: 120px;
	border:1px solid #ececec;
	border-radius: 9px;
	background:#fff;
	padding:0px;
	margin:0px;
	margin-right: 10px
}
.clearfix:after{
   content:".";/*加一段内容*/
   display:block;/*让生成的元素以块级元素显示，占满剩余空间*/
   height:0;/*避免生成的内容破坏原有布局高度*/
   clear:both;/*清除浮动*/
   visibility:hidden;/*让生成的内容不可见*/
  }
</style>
